package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.item.LocomotoraItem;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(LocomotoraMod.MODID);

    public static final DeferredItem<LocomotoraItem> SCOTSMAN = registrar(TipoLocomotora.SCOTSMAN);
    public static final DeferredItem<LocomotoraItem> F7 = registrar(TipoLocomotora.F7);
    public static final DeferredItem<LocomotoraItem> V200 = registrar(TipoLocomotora.V200);
    public static final DeferredItem<LocomotoraItem> MALLARD = registrar(TipoLocomotora.MALLARD);
    public static final DeferredItem<LocomotoraItem> BIG_BOY = registrar(TipoLocomotora.BIG_BOY);
    public static final DeferredItem<LocomotoraItem> GS4 = registrar(TipoLocomotora.GS4);
    public static final DeferredItem<LocomotoraItem> BR01 = registrar(TipoLocomotora.BR01);
    public static final DeferredItem<LocomotoraItem> PANNIER = registrar(TipoLocomotora.PANNIER);
    public static final DeferredItem<LocomotoraItem> HST = registrar(TipoLocomotora.HST);
    public static final DeferredItem<LocomotoraItem> DELTIC = registrar(TipoLocomotora.DELTIC);
    public static final DeferredItem<LocomotoraItem> SD40 = registrar(TipoLocomotora.SD40);
    public static final DeferredItem<LocomotoraItem> ES44 = registrar(TipoLocomotora.ES44);
    public static final DeferredItem<LocomotoraItem> DD51 = registrar(TipoLocomotora.DD51);
    public static final DeferredItem<LocomotoraItem> CLASS08 = registrar(TipoLocomotora.CLASS08);

    /** Combustible de las locomotoras diésel. */
    public static final DeferredItem<Item> BIDON_DIESEL = ITEMS.register("bidon_diesel",
            () -> new Item(new Item.Properties().stacksTo(16)));

    private static DeferredItem<LocomotoraItem> registrar(TipoLocomotora tipo) {
        return ITEMS.register("locomotora_" + tipo.id(),
                () -> new LocomotoraItem(new Item.Properties().stacksTo(1), tipo));
    }

    public static DeferredItem<LocomotoraItem> porTipo(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> SCOTSMAN;
            case F7 -> F7;
            case V200 -> V200;
            case MALLARD -> MALLARD;
            case BIG_BOY -> BIG_BOY;
            case GS4 -> GS4;
            case BR01 -> BR01;
            case PANNIER -> PANNIER;
            case HST -> HST;
            case DELTIC -> DELTIC;
            case SD40 -> SD40;
            case ES44 -> ES44;
            case DD51 -> DD51;
            case CLASS08 -> CLASS08;
        };
    }

    private ModItems() {
    }
}
