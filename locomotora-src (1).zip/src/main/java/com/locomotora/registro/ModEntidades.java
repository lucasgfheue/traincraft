package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntidades {
    public static final DeferredRegister<EntityType<?>> ENTIDADES =
            DeferredRegister.create(Registries.ENTITY_TYPE, LocomotoraMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SCOTSMAN = registrar(TipoLocomotora.SCOTSMAN);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> F7 = registrar(TipoLocomotora.F7);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> V200 = registrar(TipoLocomotora.V200);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> MALLARD = registrar(TipoLocomotora.MALLARD);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BIG_BOY = registrar(TipoLocomotora.BIG_BOY);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GS4 = registrar(TipoLocomotora.GS4);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BR01 = registrar(TipoLocomotora.BR01);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> PANNIER = registrar(TipoLocomotora.PANNIER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HST = registrar(TipoLocomotora.HST);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DELTIC = registrar(TipoLocomotora.DELTIC);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SD40 = registrar(TipoLocomotora.SD40);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ES44 = registrar(TipoLocomotora.ES44);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DD51 = registrar(TipoLocomotora.DD51);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS08 = registrar(TipoLocomotora.CLASS08);

    private static DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> registrar(TipoLocomotora tipo) {
        String nombre = "locomotora_" + tipo.id();
        return ENTIDADES.register(nombre, () -> EntityType.Builder
                .<LocomotoraEntity>of((tipoEntidad, level) -> new LocomotoraEntity(tipoEntidad, level, tipo), MobCategory.MISC)
                // Ancho de vagoneta para que encaje en los rieles; necesita 2 bloques de alto libres
                .sized(0.98F, 1.4F)
                // Altura del asiento del maquinista en la cabina
                .passengerAttachments(tipo.alturaAsiento())
                .clientTrackingRange(12)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    public static DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> porTipo(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> SCOTSMAN;
            case F7 -> F7;
            case V200 -> V200;
            case MALLARD -> MALLARD;
            case BIG_BOY -> BIG_BOY;
            case GS4 -> GS4;
            case BR01 -> BR01;
            case PANNIER -> PANNIER;
            case HST -> HST;
            case DELTIC -> DELTIC;
            case SD40 -> SD40;
            case ES44 -> ES44;
            case DD51 -> DD51;
            case CLASS08 -> CLASS08;
        };
    }

    private ModEntidades() {
    }
}
