package com.locomotora.cliente;

import com.locomotora.LocomotoraMod;
import com.locomotora.cliente.modelos.DatosModelo;
import com.locomotora.cliente.modelos.ModeloBR01;
import com.locomotora.cliente.modelos.ModeloBigBoy;
import com.locomotora.cliente.modelos.ModeloClass08;
import com.locomotora.cliente.modelos.ModeloDD51;
import com.locomotora.cliente.modelos.ModeloDeltic;
import com.locomotora.cliente.modelos.ModeloES44;
import com.locomotora.cliente.modelos.ModeloF7;
import com.locomotora.cliente.modelos.ModeloGS4;
import com.locomotora.cliente.modelos.ModeloHST;
import com.locomotora.cliente.modelos.ModeloMallard;
import com.locomotora.cliente.modelos.ModeloPannier;
import com.locomotora.cliente.modelos.ModeloSD40;
import com.locomotora.cliente.modelos.ModeloScotsman;
import com.locomotora.cliente.modelos.ModeloV200;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.registro.ModEntidades;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Parte del mod que solo se carga en el cliente (gráficos). */
@Mod(value = LocomotoraMod.MODID, dist = Dist.CLIENT)
public class LocomotoraCliente {

    public LocomotoraCliente(IEventBus modEventBus, ModContainer contenedor) {
        modEventBus.addListener(LocomotoraCliente::registrarRenderers);
        modEventBus.addListener(LocomotoraCliente::registrarModelos);
    }

    public static DatosModelo datosDe(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> ModeloScotsman.DATOS;
            case F7 -> ModeloF7.DATOS;
            case V200 -> ModeloV200.DATOS;
            case MALLARD -> ModeloMallard.DATOS;
            case BIG_BOY -> ModeloBigBoy.DATOS;
            case GS4 -> ModeloGS4.DATOS;
            case BR01 -> ModeloBR01.DATOS;
            case PANNIER -> ModeloPannier.DATOS;
            case HST -> ModeloHST.DATOS;
            case DELTIC -> ModeloDeltic.DATOS;
            case SD40 -> ModeloSD40.DATOS;
            case ES44 -> ModeloES44.DATOS;
            case DD51 -> ModeloDD51.DATOS;
            case CLASS08 -> ModeloClass08.DATOS;
        };
    }

    private static void registrarRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerEntityRenderer(ModEntidades.porTipo(tipo).get(), contexto -> new LocomotoraRenderer(contexto, datos));
        }
    }

    private static void registrarModelos(EntityRenderersEvent.RegisterLayerDefinitions event) {
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerLayerDefinition(datos.capa(), datos.fabricaCapa());
        }
    }
}
