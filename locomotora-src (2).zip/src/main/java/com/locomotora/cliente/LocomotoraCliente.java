package com.locomotora.cliente;

import com.locomotora.LocomotoraMod;
import com.locomotora.cliente.modelos.DatosModelo;
import com.locomotora.cliente.modelos.ModeloBR01;
import com.locomotora.cliente.modelos.ModeloBR9F;
import com.locomotora.cliente.modelos.ModeloBigBoy;
import com.locomotora.cliente.modelos.ModeloClass08;
import com.locomotora.cliente.modelos.ModeloD51;
import com.locomotora.cliente.modelos.ModeloDD51;
import com.locomotora.cliente.modelos.ModeloDeltic;
import com.locomotora.cliente.modelos.ModeloES44;
import com.locomotora.cliente.modelos.ModeloF7;
import com.locomotora.cliente.modelos.ModeloGS4;
import com.locomotora.cliente.modelos.ModeloGarratt;
import com.locomotora.cliente.modelos.ModeloHST;
import com.locomotora.cliente.modelos.ModeloHiawatha;
import com.locomotora.cliente.modelos.ModeloJupiter;
import com.locomotora.cliente.modelos.ModeloMallard;
import com.locomotora.cliente.modelos.ModeloMerchant;
import com.locomotora.cliente.modelos.ModeloNWJ;
import com.locomotora.cliente.modelos.ModeloP36;
import com.locomotora.cliente.modelos.ModeloPannier;
import com.locomotora.cliente.modelos.ModeloRocket;
import com.locomotora.cliente.modelos.ModeloSD40;
import com.locomotora.cliente.modelos.ModeloScotsman;
import com.locomotora.cliente.modelos.ModeloT1;
import com.locomotora.cliente.modelos.ModeloV200;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.registro.ModEntidades;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Parte del mod que solo se carga en el cliente (gráficos). */
@Mod(value = LocomotoraMod.MODID, dist = Dist.CLIENT)
public class LocomotoraCliente {

    public LocomotoraCliente(IEventBus modEventBus, ModContainer contenedor) {
        modEventBus.addListener(LocomotoraCliente::registrarRenderers);
        modEventBus.addListener(LocomotoraCliente::registrarModelos);
    }

    public static DatosModelo datosDe(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> ModeloScotsman.DATOS;
            case F7 -> ModeloF7.DATOS;
            case V200 -> ModeloV200.DATOS;
            case MALLARD -> ModeloMallard.DATOS;
            case BIG_BOY -> ModeloBigBoy.DATOS;
            case GS4 -> ModeloGS4.DATOS;
            case BR01 -> ModeloBR01.DATOS;
            case PANNIER -> ModeloPannier.DATOS;
            case HST -> ModeloHST.DATOS;
            case DELTIC -> ModeloDeltic.DATOS;
            case SD40 -> ModeloSD40.DATOS;
            case ES44 -> ModeloES44.DATOS;
            case DD51 -> ModeloDD51.DATOS;
            case CLASS08 -> ModeloClass08.DATOS;
            case ROCKET -> ModeloRocket.DATOS;
            case JUPITER -> ModeloJupiter.DATOS;
            case HIAWATHA -> ModeloHiawatha.DATOS;
            case T1 -> ModeloT1.DATOS;
            case NWJ -> ModeloNWJ.DATOS;
            case MERCHANT -> ModeloMerchant.DATOS;
            case BR9F -> ModeloBR9F.DATOS;
            case D51 -> ModeloD51.DATOS;
            case P36 -> ModeloP36.DATOS;
            case GARRATT -> ModeloGarratt.DATOS;
        };
    }

    private static void registrarRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerEntityRenderer(ModEntidades.porTipo(tipo).get(), contexto -> new LocomotoraRenderer(contexto, datos));
        }
    }

    private static void registrarModelos(EntityRenderersEvent.RegisterLayerDefinitions event) {
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerLayerDefinition(datos.capa(), datos.fabricaCapa());
        }
    }
}
