package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "N&W J" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloNWJ {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("nwj"), "main"),
            LocomotoraMod.id("textures/entity/nwj.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -40.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -40.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -40.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -22.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -22.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -22.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -4.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -4.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, -4.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi3_0", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, 14.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi3_1", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, 14.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi3_2", DatosModelo.RUEDA, 8.0F, 0.0F, 0.0F, 0.0F, 14.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 8.0F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 8.0F, 3.0F, 0.0F, -48.0F, -4.0F, -11.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 8.0F, 3.0F, 0.0F, -48.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -40.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -40.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -40.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -22.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -22.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -22.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd3_0", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, 14.0F, -8.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd3_1", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, 14.0F, -8.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd3_2", DatosModelo.RUEDA, 8.0F, 0.0F, 1.5707963267948966F, 0.0F, 14.0F, -8.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 8.0F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 8.0F, 3.0F, 1.5707963267948966F, -48.0F, -4.0F, -11.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 8.0F, 3.0F, 1.5707963267948966F, -48.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -88.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -88.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -88.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -76.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -76.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -76.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -88.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -88.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -88.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -76.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -76.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -76.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 38.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 38.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 38.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 38.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 38.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 38.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 74.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 74.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 74.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 156.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 156.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 156.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 168.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 168.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 168.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 180.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 180.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 180.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 74.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 74.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 74.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 156.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 156.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 156.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 168.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 168.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 168.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 180.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 180.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 180.0F, -4.5F, 1.0471975511965976F, "tender")),
            ModeloNWJ::crearCapa,
            16.0F,
            ModeloNWJ::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -82.0F, 44.0F),
                new DatosModelo.Segmento("tender", 86.0F, 168.0F)));

    private ModeloNWJ() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g1);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
        escalas3(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, -6.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(816, 304).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-40.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, -6.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(822, 304).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-22.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, -6.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(500, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(828, 304).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-4.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi3_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, -6.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(834, 304).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(14.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmi3_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(14.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi3_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, -6.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, -6.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(14.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(444, 311).addBox(-40.0F, -11.5F, -7.5F, 54.0F, 1.0F, 1.0F).texOffs(492, 294).addBox(-41.5F, -12.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(500, 294).addBox(-23.5F, -12.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(508, 294).addBox(-5.5F, -12.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(516, 294).addBox(12.5F, -12.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(664, 311).addBox(-48.0F, -0.5F, -0.5F, 48.0F, 1.0F, 1.0F).texOffs(524, 294).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-4.0F, -11.0F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(520, 261).addBox(-53.40615826801394F, -9.5F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(980, 311).addBox(-61.90615826801394F, -8.5F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(860, 311).addBox(-58.90615826801394F, -6.5F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(890, 311).addBox(-58.90615826801394F, -10.5F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(942, 193).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(590, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.0F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(970, 193).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(634, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(0, 207).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(678, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(28, 207).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(722, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(766, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(384, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.0F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(772, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(406, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(778, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(428, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(784, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(450, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(790, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(472, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.0F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(796, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(494, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(802, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(516, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(808, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(538, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, 4.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(530, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(840, 304).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-40.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, 4.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(540, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(846, 304).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-22.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, 4.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(550, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(852, 304).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-4.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd3_0", CubeListBuilder.create().texOffs(420, 172).addBox(-8.0F, -8.0F, 4.0F, 16.0F, 16.0F, 2.0F).texOffs(304, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(560, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(858, 304).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(14.0F, -8.0F, 0.0F));
        g.addOrReplaceChild("rmd3_1", CubeListBuilder.create().texOffs(338, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(468, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(14.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd3_2", CubeListBuilder.create().texOffs(372, 238).addBox(-7.5F, -2.0F, 4.0F, 15.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 172).addBox(-2.0F, -7.5F, 4.0F, 4.0F, 15.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(14.0F, -8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(554, 311).addBox(-40.0F, -11.5F, 6.5F, 54.0F, 1.0F, 1.0F).texOffs(532, 294).addBox(-41.5F, -12.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(540, 294).addBox(-23.5F, -12.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(548, 294).addBox(-5.5F, -12.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(556, 294).addBox(12.5F, -12.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(762, 311).addBox(-48.0F, -0.5F, -0.5F, 48.0F, 1.0F, 1.0F).texOffs(564, 294).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-4.0F, -11.0F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(570, 261).addBox(-53.40615826801394F, -9.5F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(1002, 311).addBox(-61.90615826801394F, -8.5F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(920, 311).addBox(-58.90615826801394F, -6.5F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(950, 311).addBox(-58.90615826801394F, -10.5F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(56, 207).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(766, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.0F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(84, 207).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(810, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(112, 207).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(854, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(140, 207).addBox(-70.90615826801394F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(898, 193).addBox(-70.90615826801394F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(814, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(560, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.0F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(820, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(582, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(826, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(604, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(832, 207).addBox(-71.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(626, 207).addBox(-71.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(838, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(648, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.0F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(844, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(670, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(850, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(692, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(856, 207).addBox(-59.40615826801394F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(714, 207).addBox(-59.40615826801394F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(862, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(920, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(580, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-88.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(942, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-88.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(964, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-88.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(862, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(920, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(590, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-76.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(942, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-76.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(964, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-76.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(862, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(920, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(600, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-88.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(942, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-88.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(964, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-88.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(862, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(920, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-76.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(942, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-76.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(964, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-76.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(168, 207).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(532, 256).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(736, 207).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(620, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(38.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(556, 256).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 207).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(580, 256).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(756, 207).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti1_0", CubeListBuilder.create().texOffs(168, 207).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(532, 256).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(736, 207).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(630, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti1_1", CubeListBuilder.create().texOffs(556, 256).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 207).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti1_2", CubeListBuilder.create().texOffs(580, 256).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(756, 207).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(168, 207).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(532, 256).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(736, 207).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(640, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(38.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(556, 256).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 207).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(580, 256).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(756, 207).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd1_0", CubeListBuilder.create().texOffs(168, 207).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(532, 256).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(736, 207).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(650, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd1_1", CubeListBuilder.create().texOffs(556, 256).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 207).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd1_2", CubeListBuilder.create().texOffs(580, 256).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(756, 207).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(604, 172).addBox(-92.0F, -17.0F, 2.0F, 150.0F, 13.0F, 1.0F).texOffs(0, 193).addBox(-92.0F, -17.0F, -3.0F, 150.0F, 13.0F, 1.0F).texOffs(0, 138).addBox(26.0F, -34.0F, -10.0F, 14.0F, 14.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(156, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(0, 0).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offset(0.0F, -30.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(202, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(156, 0).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -30.0F, 0.0F, 0.2243994752564138F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(248, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(312, 0).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -30.0F, 0.0F, 0.4487989505128276F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(294, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(468, 0).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -30.0F, 0.0F, 0.6731984257692414F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(340, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(624, 0).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -30.0F, 0.0F, 0.8975979010256552F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(386, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(780, 0).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -30.0F, 0.0F, 1.121997376282069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_6", CubeListBuilder.create().texOffs(432, 69).addBox(-80.0F, -31.0F, -3.5F, 16.0F, 62.0F, 7.0F).texOffs(0, 69).addBox(-80.0F, -3.5F, -31.0F, 16.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -30.0F, 0.0F, 1.3463968515384828F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(480, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -39.553713775179574F, 1.0764450180136709F, 3.0293950617145F, -0.000695364563699499F, -0.006171571369501172F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(536, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -39.70183336859321F, 1.0931340880603944F, 3.0293950617145002F, -0.000695364563699499F, -0.006171571369501172F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(592, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -39.849952962006846F, 1.109823158107118F, 3.0293950617145007F, -0.0006953645636995083F, -0.006171571369501172F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(648, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -39.99807255542048F, 1.1265122281538416F, 3.0293950617144993F, -0.0006953645636994989F, -0.006171571369501319F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(704, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -39.07465067365752F, 3.1753576059948583F, 2.8049994529824276F, -0.0020512264814121673F, -0.005862110287662288F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(760, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -39.21534293216384F, 3.224587956475399F, 2.8049994529824263F, -0.0020512264814121304F, -0.005862110287662288F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(816, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -39.35603519067016F, 3.273818306955939F, 2.8049994529824263F, -0.002051226481412177F, -0.005862110287662437F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(872, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -39.49672744917648F, 3.3230486574364795F, 2.804999452982428F, -0.002051226481412149F, -0.005862110287662437F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(928, 266).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -38.14054669491704F, 5.11504450447281F, 2.580602653470262F, -0.0033042346020571F, -0.005258702619732588F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(0, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -38.266756721194824F, 5.194347520046032F, 2.580602653470264F, -0.003304234602057026F, -0.005258702619732588F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(56, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -38.39296674747261F, 5.273650535619254F, 2.5806026534702635F, -0.0033042346020570813F, -0.005258702619732735F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(112, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -38.5191767737504F, 5.352953551192476F, 2.580602653470262F, -0.0033042346020570813F, -0.005258702619732735F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(168, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -36.79824171293072F, 6.798241712930717F, 2.3562041332090637F, -0.004391558432995914F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(224, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -36.90364080925522F, 6.903640809255224F, 2.356204133209064F, -0.004391558432995858F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(280, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -37.00903990557973F, 7.009039905579732F, 2.356204133209064F, -0.0043915584329958955F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(336, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -37.11443900190424F, 7.114439001904238F, 2.356204133209064F, -0.004391558432995914F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(392, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -35.11504450447282F, 8.140546694917045F, 2.1318037030301378F, -0.0052586739123251505F, -0.0033042802898256367F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(448, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -35.19434752004603F, 8.26675672119483F, 2.1318037030301373F, -0.005258673912325095F, -0.0033042802898254884F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(504, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -35.273650535619254F, 8.392966747472613F, 2.131803703030136F, -0.0052586739123251505F, -0.0033042802898254884F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(560, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -35.35295355119248F, 8.519176773750395F, 2.131803703030136F, -0.0052586739123251505F, -0.0033042802898256367F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(616, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -33.17535760599486F, 9.074650673657523F, 1.907401552047429F, -0.00586209795502274F, -0.002051261726337073F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(672, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -33.2245879564754F, 9.215342932163841F, 1.9074015520474288F, -0.005862097955022666F, -0.002051261726336925F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(728, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -33.273818306955945F, 9.356035190670159F, 1.9074015520474294F, -0.005862097955022777F, -0.002051261726336925F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(784, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -33.32304865743648F, 9.496727449176477F, 1.9074015520474297F, -0.00586209795502274F, -0.002051261726337073F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(840, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -31.076445018013672F, 9.553713775179572F, 1.6829982102163625F, -0.006171569877406582F, -0.0006953778065300761F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(896, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -31.093134088060395F, 9.701833368593208F, 1.6829982102163628F, -0.006171569877406509F, -0.0006953778065300761F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(952, 270).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -31.10982315810712F, 9.849952962006844F, 1.6829982102163628F, -0.006171569877406619F, -0.0006953778065300761F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(0, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -31.126512228153842F, 9.998072555420482F, 1.6829982102163628F, -0.006171569877406582F, -0.0006953778065300761F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(56, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -28.923554981986328F, 9.553713775179572F, 1.4585944433734306F, -0.006171569877406582F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(112, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -28.906865911939605F, 9.701833368593208F, 1.4585944433734301F, -0.006171569877406509F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(168, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -28.89017684189288F, 9.849952962006844F, 1.4585944433734304F, -0.006171569877406619F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(224, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -28.873487771846158F, 9.998072555420482F, 1.4585944433734304F, -0.006171569877406582F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(280, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -26.824642394005146F, 9.074650673657525F, 1.2341911015423646F, -0.00586209795502274F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(336, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -26.775412043524604F, 9.215342932163843F, 1.2341911015423648F, -0.005862097955022666F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(392, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -26.72618169304406F, 9.356035190670159F, 1.2341911015423648F, -0.005862097955022777F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(448, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -26.67695134256352F, 9.496727449176479F, 1.2341911015423648F, -0.00586209795502274F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(504, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -24.88495549552719F, 8.140546694917049F, 1.009788950559657F, -0.0052586739123251505F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(560, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -24.80565247995397F, 8.266756721194831F, 1.009788950559657F, -0.005258673912325095F, 0.0033042802898254884F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(616, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -24.72634946438075F, 8.392966747472615F, 1.0097889505596567F, -0.0052586739123251505F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(672, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -24.647046448807526F, 8.519176773750399F, 1.009788950559657F, -0.0052586739123251505F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(728, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -23.201758287069282F, 6.79824171293072F, 0.785388520380731F, -0.0043915584329958955F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(784, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -23.096359190744778F, 6.9036408092552275F, 0.7853885203807307F, -0.004391558432995858F, 0.004391600780935214F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(840, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -22.990960094420274F, 7.0090399055797326F, 0.7853885203807304F, -0.0043915584329958955F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(896, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -22.885560998095766F, 7.11443900190424F, 0.7853885203807304F, -0.004391558432995914F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(952, 274).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -21.85945330508295F, 5.115044504472812F, 0.5609900001195287F, -0.0033042346020570813F, 0.0052587026197326615F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(0, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -21.733243278805173F, 5.194347520046033F, 0.5609900001195287F, -0.003304234602057026F, 0.005258702619732513F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(56, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -21.607033252527387F, 5.273650535619255F, 0.5609900001195296F, -0.0033042346020570813F, 0.005258702619732735F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(112, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -21.480823226249605F, 5.352953551192477F, 0.5609900001195296F, -0.0033042346020570813F, 0.005258702619732588F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(168, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -20.925349326342477F, 3.1753576059948614F, 0.3365932006073672F, -0.0020512264814121673F, 0.005862110287662362F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(224, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -20.784657067836157F, 3.2245879564754016F, 0.33659320060736775F, -0.0020512264814121304F, 0.005862110287662288F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(280, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -20.64396480932984F, 3.273818306955942F, 0.33659320060736747F, -0.002051226481412177F, 0.005862110287662437F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(336, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -20.503272550823525F, 3.3230486574364826F, 0.3365932006073672F, -0.002051226481412158F, 0.005862110287662288F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(392, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -20.446286224820426F, 1.076445018013674F, 0.11219759187529342F, -0.0006953645636994995F, 0.006171571369501172F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(448, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -20.298166631406794F, 1.0931340880603975F, 0.11219759187529292F, -0.0006953645636994995F, 0.006171571369501172F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(504, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -20.150047037993154F, 1.1098231581071212F, 0.11219759187529244F, -0.0006953645636995087F, 0.006171571369501172F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(560, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -20.00192744457952F, 1.1265122281538449F, 0.11219759187529271F, -0.0006953645636995086F, 0.0061715713695012445F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(616, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -20.446286224820426F, -1.0764450180136698F, -0.1121975918752936F, 0.0006953645636995078F, 0.006171571369501172F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(672, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -20.298166631406794F, -1.0931340880603932F, -0.11219759187529312F, 0.0006953645636994894F, 0.006171571369501172F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(728, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -20.150047037993154F, -1.1098231581071167F, -0.11219759187529263F, 0.0006953645636995078F, 0.006171571369501172F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(784, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -20.001927444579522F, -1.1265122281538402F, -0.11219759187529293F, 0.0006953645636995077F, 0.0061715713695012445F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(840, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -20.925349326342477F, -3.175357605994857F, -0.3365932006073658F, 0.002051226481412158F, 0.005862110287662288F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(896, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -20.784657067836157F, -3.224587956475397F, -0.3365932006073663F, 0.0020512264814121395F, 0.005862110287662362F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(952, 278).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -20.643964809329837F, -3.2738183069559375F, -0.336593200607366F, 0.002051226481412158F, 0.005862110287662362F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(0, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -20.50327255082352F, -3.3230486574364777F, -0.33659320060736575F, 0.002051226481412177F, 0.005862110287662362F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(56, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -21.85945330508295F, -5.115044504472808F, -0.5609900001195287F, 0.0033042346020570627F, 0.005258702619732588F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(112, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -21.73324327880517F, -5.19434752004603F, -0.5609900001195282F, 0.0033042346020570445F, 0.0052587026197326615F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(168, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -21.607033252527383F, -5.273650535619251F, -0.5609900001195283F, 0.0033042346020570627F, 0.0052587026197326615F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(224, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -21.480823226249598F, -5.352953551192472F, -0.5609900001195284F, 0.0033042346020570813F, 0.0052587026197326615F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(280, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -23.201758287069282F, -6.798241712930714F, -0.7853885203807307F, 0.0043915584329958955F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(336, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -23.09635919074477F, -6.903640809255221F, -0.7853885203807305F, 0.004391558432995858F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(392, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -22.990960094420267F, -7.009039905579728F, -0.7853885203807301F, 0.0043915584329958955F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(448, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -22.885560998095755F, -7.114439001904236F, -0.7853885203807298F, 0.0043915584329958955F, 0.004391600780935361F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(504, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -24.884955495527183F, -8.140546694917042F, -1.0097889505596556F, 0.0052586739123251505F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(560, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -24.80565247995396F, -8.266756721194827F, -1.0097889505596556F, 0.005258673912325132F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(616, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -24.72634946438074F, -8.39296674747261F, -1.0097889505596556F, 0.0052586739123251505F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(672, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -24.647046448807522F, -8.519176773750395F, -1.0097889505596558F, 0.0052586739123251505F, 0.0033042802898255626F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(728, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -26.82464239400513F, -9.074650673657521F, -1.2341911015423634F, 0.005862097955022777F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(784, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -26.77541204352459F, -9.21534293216384F, -1.2341911015423639F, 0.005862097955022703F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(840, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -26.726181693044055F, -9.356035190670157F, -1.234191101542364F, 0.005862097955022777F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(896, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -26.676951342563513F, -9.496727449176475F, -1.2341911015423639F, 0.00586209795502274F, 0.002051261726336999F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(952, 282).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -28.923554981986324F, -9.55371377517957F, -1.4585944433734297F, 0.006171569877406619F, 0.0006953778065301501F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(0, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -28.906865911939597F, -9.701833368593206F, -1.4585944433734297F, 0.006171569877406509F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(56, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -28.890176841892874F, -9.849952962006842F, -1.45859444337343F, 0.006171569877406619F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(112, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -28.87348777184615F, -9.998072555420482F, -1.45859444337343F, 0.006171569877406582F, 0.0006953778065300761F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(168, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -31.07644501801367F, -9.553713775179572F, -1.6829982102163628F, 0.006171569877406582F, -0.0006953778065301501F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(224, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -31.093134088060395F, -9.701833368593208F, -1.6829982102163628F, 0.006171569877406509F, -0.0006953778065299281F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(280, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -31.109823158107115F, -9.849952962006844F, -1.6829982102163628F, 0.006171569877406619F, -0.0006953778065302241F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(336, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -31.126512228153842F, -9.998072555420482F, -1.6829982102163625F, 0.006171569877406582F, -0.0006953778065300761F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(392, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -33.175357605994854F, -9.074650673657525F, -1.9074015520474288F, 0.00586209795502274F, -0.0020512617263372212F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(448, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -33.224587956475396F, -9.215342932163843F, -1.9074015520474281F, 0.005862097955022703F, -0.002051261726336777F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(504, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -33.27381830695593F, -9.35603519067016F, -1.907401552047428F, 0.005862097955022777F, -0.0020512617263372212F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(560, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -33.32304865743648F, -9.496727449176479F, -1.9074015520474281F, 0.00586209795502274F, -0.002051261726337073F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(616, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -35.11504450447281F, -8.140546694917047F, -2.131803703030136F, 0.005258673912325169F, -0.0033042802898256367F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(672, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -35.19434752004603F, -8.266756721194831F, -2.131803703030137F, 0.005258673912325113F, -0.0033042802898253405F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(728, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -35.273650535619254F, -8.392966747472613F, -2.1318037030301378F, 0.0052586739123251505F, -0.0033042802898256367F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(784, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -35.35295355119247F, -8.519176773750397F, -2.131803703030138F, 0.0052586739123251505F, -0.0033042802898256367F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(840, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -36.79824171293072F, -6.798241712930719F, -2.3562041332090637F, 0.004391558432995914F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(896, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -36.90364080925522F, -6.903640809255226F, -2.356204133209063F, 0.00439155843299584F, -0.004391600780935214F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(952, 286).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -37.009039905579726F, -7.0090399055797326F, -2.3562041332090615F, 0.004391558432995914F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(0, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -37.11443900190423F, -7.114439001904239F, -2.3562041332090615F, 0.0043915584329958955F, -0.004391600780935361F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(56, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -38.14054669491704F, -5.1150445044728166F, -2.5806026534702635F, 0.0033042346020570813F, -0.005258702619732588F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(112, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -38.266756721194824F, -5.194347520046038F, -2.580602653470263F, 0.003304234602057026F, -0.005258702619732735F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(168, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -38.39296674747261F, -5.27365053561926F, -2.580602653470263F, 0.0033042346020571F, -0.005258702619732588F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(224, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -38.519176773750395F, -5.352953551192481F, -2.580602653470263F, 0.0033042346020570627F, -0.005258702619732735F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(280, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -39.07465067365752F, -3.175357605994869F, -2.804999452982426F, 0.002051226481412177F, -0.005862110287662437F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(336, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -39.215342932163836F, -3.224587956475409F, -2.804999452982426F, 0.0020512264814121304F, -0.005862110287662288F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(392, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -39.356035190670156F, -3.2738183069559494F, -2.8049994529824263F, 0.002051226481412177F, -0.005862110287662437F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(448, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -39.496727449176475F, -3.32304865743649F, -2.804999452982425F, 0.002051226481412158F, -0.005862110287662437F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(504, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.0F, -39.553713775179574F, -1.0764450180136775F, -3.0293950617144985F, 0.0006953645636995089F, -0.006171571369501319F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(560, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.0F, -39.701833368593206F, -1.093134088060401F, -3.029395061714499F, 0.0006953645636994998F, -0.006171571369501023F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(616, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -39.84995296200684F, -1.1098231581071247F, -3.0293950617144993F, 0.0006953645636995089F, -0.006171571369501319F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(672, 290).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -39.99807255542048F, -1.1265122281538484F, -3.0293950617145F, 0.0006953645636995089F, -0.006171571369501319F));
        g.addOrReplaceChild("skyline", CubeListBuilder.create().texOffs(302, 193).addBox(-78.0F, -40.0F, -5.0F, 110.0F, 3.0F, 10.0F).texOffs(342, 229).addBox(-78.0F, -43.0F, -2.0F, 110.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("skyline_cantoi_0", CubeListBuilder.create().texOffs(0, 307).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -40.46352549156242F, -4.9265847744427305F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_1", CubeListBuilder.create().texOffs(222, 307).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -41.34520337000113F, -4.640110266005152F, -2.0420352248333677F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_2", CubeListBuilder.create().texOffs(444, 307).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -42.09520337000113F, -4.095203370001131F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_3", CubeListBuilder.create().texOffs(666, 307).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -42.64011026600515F, -3.3452033700011308F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_4", CubeListBuilder.create().texOffs(0, 309).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -42.92658477444273F, -2.463525491562421F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_0", CubeListBuilder.create().texOffs(222, 309).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -40.46352549156242F, 4.9265847744427305F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_1", CubeListBuilder.create().texOffs(444, 309).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -41.34520337000113F, 4.640110266005152F, 2.0420352248333677F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_2", CubeListBuilder.create().texOffs(666, 309).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -42.09520337000113F, 4.095203370001131F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_3", CubeListBuilder.create().texOffs(0, 311).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -42.64011026600515F, 3.3452033700011308F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_4", CubeListBuilder.create().texOffs(222, 311).addBox(-55.0F, -1.0F, -0.5F, 110.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -42.92658477444273F, 2.463525491562421F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_tapaa", CubeListBuilder.create().texOffs(718, 138).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 20.0F), PartPose.offset(-78.0F, -40.0F, -5.0F));
        g.addOrReplaceChild("skyline_tapab", CubeListBuilder.create().texOffs(760, 138).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 20.0F), PartPose.offset(31.0F, -40.0F, -5.0F));
        g.addOrReplaceChild("nariz_0", CubeListBuilder.create().texOffs(710, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -39.799989349923926F, 1.1041936110457071F, 0.11188794083249536F, 0.008376326977429599F, 3.067180303114747F));
        g.addOrReplaceChild("nariz_1", CubeListBuilder.create().texOffs(280, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -39.500524150448655F, 1.0704519866230546F, 0.1091788315923944F, 0.025912042224661615F, 2.9094870002666395F));
        g.addOrReplaceChild("nariz_2", CubeListBuilder.create().texOffs(298, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -38.89735974590102F, 1.0024916799195724F, 0.10253236097553826F, 0.045642111758843036F, 2.7242129724683646F));
        g.addOrReplaceChild("nariz_3", CubeListBuilder.create().texOffs(604, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -37.9781856878746F, 0.8989256365218206F, 0.08930296050650544F, 0.06801522157858346F, 2.4923486975869866F));
        g.addOrReplaceChild("nariz_4", CubeListBuilder.create().texOffs(620, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -36.710361507477415F, 0.7560761588400207F, 0.06650111370454821F, 0.09043477897533861F, 2.206210184145637F));
        g.addOrReplaceChild("nariz_5", CubeListBuilder.create().texOffs(44, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -34.99575511027744F, 0.5628864152959626F, 0.0357630881822614F, 0.10637015789392983F, 1.8958361397745644F));
        g.addOrReplaceChild("nariz_6", CubeListBuilder.create().texOffs(0, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -32.00407412667691F, 0.22580492363043525F, 0.006293398207508929F, 0.11202383711533692F, 1.6270344790373377F));
        g.addOrReplaceChild("nariz_7", CubeListBuilder.create().texOffs(730, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -39.30857696272696F, 3.257211954768307F, 0.33572534142999827F, 0.024711182853536497F, 3.070898903658511F));
        g.addOrReplaceChild("nariz_8", CubeListBuilder.create().texOffs(316, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -39.02412819881114F, 3.157679027441655F, 0.32811275287409775F, 0.07650283791306166F, 2.9207416054121667F));
        g.addOrReplaceChild("nariz_9", CubeListBuilder.create().texOffs(334, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -38.451208976102734F, 2.957205920886848F, 0.3092885998272739F, 0.13500060230488786F, 2.7429469640295947F));
        g.addOrReplaceChild("nariz_10", CubeListBuilder.create().texOffs(636, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -37.57812614348238F, 2.651701024563691F, 0.2712249392993511F, 0.2018482936831762F, 2.5169428568602235F));
        g.addOrReplaceChild("nariz_11", CubeListBuilder.create().texOffs(652, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -36.37387596146304F, 2.230315660816729F, 0.20395386470240084F, 0.2696624299084755F, 2.230961752312824F));
        g.addOrReplaceChild("nariz_12", CubeListBuilder.create().texOffs(60, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -34.74524708859148F, 1.6604337706159702F, 0.11065869514109801F, 0.31854517248196257F, 1.9117252301765764F));
        g.addOrReplaceChild("nariz_13", CubeListBuilder.create().texOffs(20, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.903581481680554F, 0.666091969141228F, 0.019542438516184014F, 0.336052986056603F, 1.6299966086565936F));
        g.addOrReplaceChild("nariz_14", CubeListBuilder.create().texOffs(750, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -38.3503936573865F, 5.246900090146177F, 0.5597352915228072F, 0.039812627783585304F, 3.07815518114502F));
        g.addOrReplaceChild("nariz_15", CubeListBuilder.create().texOffs(352, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -38.09522477780749F, 5.0865668565049935F, 0.5486773692045152F, 0.12342805219079357F, 2.9428486004373826F));
        g.addOrReplaceChild("nariz_16", CubeListBuilder.create().texOffs(370, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -37.58127929906725F, 4.763633508764311F, 0.5209342395218685F, 0.2185420675475985F, 2.7803331175673334F));
        g.addOrReplaceChild("nariz_17", CubeListBuilder.create().texOffs(668, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -36.79806771075694F, 4.2715090506947435F, 0.4631216541579319F, 0.32883974791909565F, 2.567512240122907F));
        g.addOrReplaceChild("nariz_18", CubeListBuilder.create().texOffs(684, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -35.71777765975274F, 3.5927178225729355F, 0.35561386297100356F, 0.4435425229154262F, 2.284195359548964F));
        g.addOrReplaceChild("nariz_19", CubeListBuilder.create().texOffs(76, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -34.2567925634573F, 2.6747200433096787F, 0.1969383994827907F, 0.5287986119714376F, 1.9474109843036227F));
        g.addOrReplaceChild("nariz_20", CubeListBuilder.create().texOffs(40, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.7076353125287F, 1.072978381961439F, 0.035082371306527846F, 0.5600180384098516F, 1.6367709829212793F));
        g.addOrReplaceChild("nariz_21", CubeListBuilder.create().texOffs(770, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -36.97348674585736F, 6.973486745857362F, 0.7839950454317893F, 0.05292441362549801F, 3.088593963381855F));
        g.addOrReplaceChild("nariz_22", CubeListBuilder.create().texOffs(388, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -36.760392983729695F, 6.7603929837296945F, 0.77164106810481F, 0.16436717080219612F, 2.9749590212959074F));
        g.addOrReplaceChild("nariz_23", CubeListBuilder.create().texOffs(406, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -36.33119262131108F, 6.331192621311081F, 0.7400614639048851F, 0.2922950651208648F, 2.8359417803073024F));
        g.addOrReplaceChild("nariz_24", CubeListBuilder.create().texOffs(700, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -35.67712577675549F, 5.677125776755489F, 0.6715005023413645F, 0.44362464736731166F, 2.6463830229836396F));
        g.addOrReplaceChild("nariz_25", CubeListBuilder.create().texOffs(716, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -34.77496611082219F, 4.774966110822189F, 0.5338387894847206F, 0.6069425223523466F, 2.374038116210153F));
        g.addOrReplaceChild("nariz_26", CubeListBuilder.create().texOffs(92, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -33.55488468437359F, 3.5548846843735937F, 0.30747129083415253F, 0.7348960113908652F, 2.0130871946406783F));
        g.addOrReplaceChild("nariz_27", CubeListBuilder.create().texOffs(60, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.426061178342565F, 1.4260611783425658F, 0.055798211052347786F, 0.7838382038081361F, 1.6497479695611925F));
        g.addOrReplaceChild("nariz_28", CubeListBuilder.create().texOffs(790, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -35.24690009014618F, 8.350393657386496F, 1.0085327028125708F, 0.06338713598943688F, 3.101699867045698F));
        g.addOrReplaceChild("nariz_29", CubeListBuilder.create().texOffs(424, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -35.086566856504994F, 8.095224777807486F, 0.9973283509042397F, 0.1972121015760235F, 3.0157120195000857F));
        g.addOrReplaceChild("nariz_30", CubeListBuilder.create().texOffs(442, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -34.763633508764315F, 7.581279299067247F, 0.9681260600547433F, 0.3522875024471051F, 2.90849467662273F));
        g.addOrReplaceChild("nariz_31", CubeListBuilder.create().texOffs(732, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -34.271509050694746F, 6.798067710756939F, 0.9017729355486257F, 0.5397998168305248F, 2.755603566985258F));
        g.addOrReplaceChild("nariz_32", CubeListBuilder.create().texOffs(748, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -33.592717822572936F, 5.717777659752743F, 0.7548553285311153F, 0.7518283511925242F, 2.513613839363769F));
        g.addOrReplaceChild("nariz_33", CubeListBuilder.create().texOffs(108, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -32.67472004330968F, 4.256792563457299F, 0.4679300127206913F, 0.9321466577724369F, 2.1325698095884142F));
        g.addOrReplaceChild("nariz_34", CubeListBuilder.create().texOffs(80, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.072978381961438F, 1.707635312528699F, 0.08866156741572778F, 1.0073179322215617F, 1.6755620086360334F));
        g.addOrReplaceChild("nariz_35", CubeListBuilder.create().texOffs(810, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -33.25721195476831F, 9.308576962726956F, 1.2333213230726914F, 0.07067213071320619F, 3.1168196187936994F));
        g.addOrReplaceChild("nariz_36", CubeListBuilder.create().texOffs(460, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -33.15767902744165F, 9.024128198811145F, 1.225526110260309F, 0.22019441448298754F, 3.063193111301796F));
        g.addOrReplaceChild("nariz_37", CubeListBuilder.create().texOffs(478, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -32.95720592088685F, 8.45120897610274F, 1.2048789522706234F, 0.39481639550481334F, 2.995262645425839F));
        g.addOrReplaceChild("nariz_38", CubeListBuilder.create().texOffs(764, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -32.65170102456369F, 7.578126143482377F, 1.156028666534955F, 0.6100887287095865F, 2.8944767431046423F));
        g.addOrReplaceChild("nariz_39", CubeListBuilder.create().texOffs(780, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -32.23031566081673F, 6.373875961463041F, 1.0362891733147443F, 0.8653848537697313F, 2.718151226267571F));
        g.addOrReplaceChild("nariz_40", CubeListBuilder.create().texOffs(124, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -31.660433770615974F, 4.745247088591481F, 0.7369332874681667F, 1.108503024580813F, 2.36310120894477F));
        g.addOrReplaceChild("nariz_41", CubeListBuilder.create().texOffs(100, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -30.666091969141227F, 1.9035814816805547F, 0.15829235495501373F, 1.229763602384364F, 1.7385863728201438F));
        g.addOrReplaceChild("nariz_42", CubeListBuilder.create().texOffs(830, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -31.10419361104571F, 9.79998934992393F, 1.4582839381640593F, 0.07440973517020037F, 3.1331930833885284F));
        g.addOrReplaceChild("nariz_43", CubeListBuilder.create().texOffs(496, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -31.070451986623056F, 9.500524150448655F, 1.4554935429354243F, 0.23202630658064616F, 3.114966945530167F));
        g.addOrReplaceChild("nariz_44", CubeListBuilder.create().texOffs(514, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -31.002491679919572F, 8.897359745901015F, 1.4480345184525036F, 0.41691792787328835F, 3.091671228436443F));
        g.addOrReplaceChild("nariz_45", CubeListBuilder.create().texOffs(796, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -30.89892563652182F, 7.978185687874598F, 1.4299544650359304F, 0.6474901773387081F, 3.0562801064038148F));
        g.addOrReplaceChild("nariz_46", CubeListBuilder.create().texOffs(812, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -30.75607615884002F, 6.710361507477409F, 1.3824356272143656F, 0.9298617191200201F, 2.9899758237469163F));
        g.addOrReplaceChild("nariz_47", CubeListBuilder.create().texOffs(140, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -30.562886415295964F, 4.99575511027744F, 1.2298260535265357F, 1.2293817773348634F, 2.8189283535270238F));
        g.addOrReplaceChild("nariz_48", CubeListBuilder.create().texOffs(120, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -30.225804923630434F, 2.0040741266769126F, 0.4602317260009721F, 1.4455013710822069F, 2.0341673171163026F));
        g.addOrReplaceChild("nariz_49", CubeListBuilder.create().texOffs(850, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -28.89580638895429F, 9.79998934992393F, 1.6833087154257338F, 0.07440973517020037F, -3.1331930833885284F));
        g.addOrReplaceChild("nariz_50", CubeListBuilder.create().texOffs(532, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -28.929548013376944F, 9.500524150448653F, 1.6860991106543692F, 0.23202630658064619F, -3.1149669455301665F));
        g.addOrReplaceChild("nariz_51", CubeListBuilder.create().texOffs(550, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -28.997508320080428F, 8.897359745901015F, 1.6935581351372895F, 0.41691792787328824F, -3.0916712284364434F));
        g.addOrReplaceChild("nariz_52", CubeListBuilder.create().texOffs(828, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -29.10107436347818F, 7.978185687874598F, 1.711638188553863F, 0.6474901773387081F, -3.0562801064038148F));
        g.addOrReplaceChild("nariz_53", CubeListBuilder.create().texOffs(844, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -29.24392384115998F, 6.710361507477409F, 1.7591570263754275F, 0.9298617191200201F, -2.9899758237469163F));
        g.addOrReplaceChild("nariz_54", CubeListBuilder.create().texOffs(156, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -29.437113584704036F, 4.99575511027744F, 1.9117666000632576F, 1.2293817773348634F, -2.8189283535270238F));
        g.addOrReplaceChild("nariz_55", CubeListBuilder.create().texOffs(140, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -29.774195076369562F, 2.0040741266769126F, 2.681360927588821F, 1.4455013710822069F, -2.0341673171163026F));
        g.addOrReplaceChild("nariz_56", CubeListBuilder.create().texOffs(870, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -26.74278804523169F, 9.308576962726958F, 1.908271330517101F, 0.07067213071320624F, -3.1168196187936994F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("nariz_57", CubeListBuilder.create().texOffs(568, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -26.842320972558348F, 9.024128198811145F, 1.916066543329484F, 0.2201944144829881F, -3.0631931113017954F));
        g.addOrReplaceChild("nariz_58", CubeListBuilder.create().texOffs(586, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -27.042794079113154F, 8.45120897610274F, 1.936713701319169F, 0.3948163955048131F, -2.9952626454258393F));
        g.addOrReplaceChild("nariz_59", CubeListBuilder.create().texOffs(860, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -27.348298975436308F, 7.578126143482377F, 1.9855639870548392F, 0.6100887287095866F, -2.894476743104641F));
        g.addOrReplaceChild("nariz_60", CubeListBuilder.create().texOffs(876, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -27.76968433918327F, 6.373875961463041F, 2.105303480275048F, 0.8653848537697313F, -2.7181512262675724F));
        g.addOrReplaceChild("nariz_61", CubeListBuilder.create().texOffs(172, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -28.339566229384026F, 4.745247088591481F, 2.404659366121626F, 1.108503024580813F, -2.3631012089447703F));
        g.addOrReplaceChild("nariz_62", CubeListBuilder.create().texOffs(160, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -29.333908030858773F, 1.903581481680555F, 2.9833002986347794F, 1.229763602384364F, -1.7385863728201438F));
        g.addOrReplaceChild("nariz_63", CubeListBuilder.create().texOffs(890, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -24.753099909853823F, 8.3503936573865F, 2.1330599507772234F, 0.06338713598943711F, -3.1016998670456974F));
        g.addOrReplaceChild("nariz_64", CubeListBuilder.create().texOffs(604, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -24.91343314349501F, 8.095224777807488F, 2.144264302685554F, 0.1972121015760235F, -3.015712019500086F));
        g.addOrReplaceChild("nariz_65", CubeListBuilder.create().texOffs(622, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -25.236366491235692F, 7.581279299067248F, 2.17346659353505F, 0.35228750244710527F, -2.90849467662273F));
        g.addOrReplaceChild("nariz_66", CubeListBuilder.create().texOffs(892, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -25.72849094930526F, 6.798067710756942F, 2.2398197180411685F, 0.5397998168305251F, -2.7556035669852563F));
        g.addOrReplaceChild("nariz_67", CubeListBuilder.create().texOffs(908, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -26.407282177427067F, 5.717777659752745F, 2.3867373250586765F, 0.7518283511925246F, -2.513613839363771F));
        g.addOrReplaceChild("nariz_68", CubeListBuilder.create().texOffs(188, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -27.32527995669032F, 4.2567925634573F, 2.6736626408691015F, 0.9321466577724373F, -2.1325698095884147F));
        g.addOrReplaceChild("nariz_69", CubeListBuilder.create().texOffs(180, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.927021618038562F, 1.7076353125286994F, 3.0529310861740653F, 1.0073179322215617F, -1.6755620086360334F));
        g.addOrReplaceChild("nariz_70", CubeListBuilder.create().texOffs(910, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -23.02651325414264F, 6.973486745857364F, 2.3575976081580015F, 0.05292441362549801F, -3.0885939633818555F));
        g.addOrReplaceChild("nariz_71", CubeListBuilder.create().texOffs(640, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -23.239607016270305F, 6.760392983729696F, 2.3699515854849817F, 0.16436717080219612F, -2.9749590212959074F));
        g.addOrReplaceChild("nariz_72", CubeListBuilder.create().texOffs(658, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -23.66880737868892F, 6.331192621311082F, 2.4015311896849068F, 0.292295065120865F, -2.8359417803073033F));
        g.addOrReplaceChild("nariz_73", CubeListBuilder.create().texOffs(924, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -24.322874223244515F, 5.6771257767554895F, 2.4700921512484273F, 0.4436246473673125F, -2.6463830229836387F));
        g.addOrReplaceChild("nariz_74", CubeListBuilder.create().texOffs(940, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -25.225033889177812F, 4.774966110822191F, 2.6077538641050717F, 0.6069425223523474F, -2.374038116210153F));
        g.addOrReplaceChild("nariz_75", CubeListBuilder.create().texOffs(204, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -26.445115315626406F, 3.5548846843735955F, 2.8341213627556407F, 0.7348960113908655F, -2.0130871946406788F));
        g.addOrReplaceChild("nariz_76", CubeListBuilder.create().texOffs(200, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.573938821657435F, 1.4260611783425663F, 3.0857944425374453F, 0.7838382038081364F, -1.6497479695611925F));
        g.addOrReplaceChild("nariz_77", CubeListBuilder.create().texOffs(930, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -21.649606342613502F, 5.246900090146178F, 2.5818573620669882F, 0.03981262778358507F, -3.078155181145021F));
        g.addOrReplaceChild("nariz_78", CubeListBuilder.create().texOffs(676, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -21.904775222192512F, 5.086566856504994F, 2.5929152843852794F, 0.12342805219079342F, -2.9428486004373826F));
        g.addOrReplaceChild("nariz_79", CubeListBuilder.create().texOffs(694, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -22.418720700932752F, 4.763633508764312F, 2.6206584140679254F, 0.21854206754759822F, -2.780333117567334F));
        g.addOrReplaceChild("nariz_80", CubeListBuilder.create().texOffs(956, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -23.20193228924306F, 4.271509050694744F, 2.678470999431862F, 0.32883974791909554F, -2.5675122401229067F));
        g.addOrReplaceChild("nariz_81", CubeListBuilder.create().texOffs(972, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -24.282222340247255F, 3.592717822572936F, 2.78597879061879F, 0.4435425229154263F, -2.2841953595489626F));
        g.addOrReplaceChild("nariz_82", CubeListBuilder.create().texOffs(220, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -25.743207436542697F, 2.674720043309679F, 2.944654254107002F, 0.5287986119714381F, -1.9474109843036234F));
        g.addOrReplaceChild("nariz_83", CubeListBuilder.create().texOffs(220, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.292364687471302F, 1.0729783819614394F, 3.1065102822832653F, 0.5600180384098519F, -1.6367709829212793F));
        g.addOrReplaceChild("nariz_84", CubeListBuilder.create().texOffs(950, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -20.691423037273044F, 3.25721195476831F, 2.8058673121597932F, 0.024711182853536812F, -3.0708989036585104F));
        g.addOrReplaceChild("nariz_85", CubeListBuilder.create().texOffs(712, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -20.975871801188855F, 3.157679027441658F, 2.8134799007156945F, 0.07650283791306159F, -2.9207416054121684F));
        g.addOrReplaceChild("nariz_86", CubeListBuilder.create().texOffs(730, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -21.54879102389726F, 2.957205920886851F, 2.832304053762519F, 0.13500060230488795F, -2.7429469640295947F));
        g.addOrReplaceChild("nariz_87", CubeListBuilder.create().texOffs(988, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -22.421873856517625F, 2.651701024563694F, 2.8703677142904422F, 0.20184829368317628F, -2.5169428568602226F));
        g.addOrReplaceChild("nariz_88", CubeListBuilder.create().texOffs(1004, 256).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -23.626124038536958F, 2.230315660816731F, 2.937638788887392F, 0.269662429908476F, -2.230961752312824F));
        g.addOrReplaceChild("nariz_89", CubeListBuilder.create().texOffs(236, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -25.25475291140852F, 1.660433770615972F, 3.0309339584486943F, 0.31854517248196385F, -1.9117252301765768F));
        g.addOrReplaceChild("nariz_90", CubeListBuilder.create().texOffs(240, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.096418518319446F, 0.6660919691412288F, 3.1220502150736094F, 0.3360529860566033F, -1.6299966086565936F));
        g.addOrReplaceChild("nariz_91", CubeListBuilder.create().texOffs(970, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -20.200010650076074F, 1.1041936110457105F, 3.0297047127572965F, 0.008376326977429599F, -3.067180303114747F));
        g.addOrReplaceChild("nariz_92", CubeListBuilder.create().texOffs(748, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -20.499475849551345F, 1.070451986623058F, 3.032413821997398F, 0.02591204222466177F, -2.9094870002666386F));
        g.addOrReplaceChild("nariz_93", CubeListBuilder.create().texOffs(766, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -21.102640254098986F, 1.0024916799195756F, 3.039060292614256F, 0.045642111758842724F, -2.7242129724683655F));
        g.addOrReplaceChild("nariz_94", CubeListBuilder.create().texOffs(0, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -22.021814312125404F, 0.8989256365218232F, 3.0522896930832872F, 0.06801522157858386F, -2.4923486975869857F));
        g.addOrReplaceChild("nariz_95", CubeListBuilder.create().texOffs(16, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -23.28963849252259F, 0.756076158840023F, 3.0750915398852445F, 0.09043477897533901F, -2.2062101841456374F));
        g.addOrReplaceChild("nariz_96", CubeListBuilder.create().texOffs(252, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -25.004244889722557F, 0.5628864152959643F, 3.105829565407532F, 0.10637015789392999F, -1.8958361397745642F));
        g.addOrReplaceChild("nariz_97", CubeListBuilder.create().texOffs(260, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -27.99592587332309F, 0.22580492363043594F, 3.1352992553822845F, 0.11202383711533727F, -1.6270344790373377F));
        g.addOrReplaceChild("nariz_98", CubeListBuilder.create().texOffs(990, 238).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -20.200010650076074F, -1.104193611045706F, -3.029704712757298F, -0.008376326977429599F, -3.067180303114747F));
        g.addOrReplaceChild("nariz_99", CubeListBuilder.create().texOffs(784, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -20.499475849551345F, -1.0704519866230535F, -3.032413821997399F, -0.025912042224661695F, -2.9094870002666378F));
        g.addOrReplaceChild("nariz_100", CubeListBuilder.create().texOffs(802, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -21.102640254098986F, -1.0024916799195713F, -3.0390602926142556F, -0.045642111758842724F, -2.7242129724683655F));
        g.addOrReplaceChild("nariz_101", CubeListBuilder.create().texOffs(32, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -22.021814312125404F, -0.8989256365218197F, -3.0522896930832877F, -0.06801522157858346F, -2.4923486975869866F));
        g.addOrReplaceChild("nariz_102", CubeListBuilder.create().texOffs(48, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -23.289638492522588F, -0.75607615884002F, -3.075091539885245F, -0.09043477897533854F, -2.206210184145637F));
        g.addOrReplaceChild("nariz_103", CubeListBuilder.create().texOffs(268, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -25.00424488972256F, -0.5628864152959621F, -3.105829565407532F, -0.10637015789392983F, -1.8958361397745644F));
        g.addOrReplaceChild("nariz_104", CubeListBuilder.create().texOffs(280, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -27.99592587332309F, -0.22580492363043503F, -3.1352992553822845F, -0.11202383711533682F, -1.6270344790373377F));
        g.addOrReplaceChild("nariz_105", CubeListBuilder.create().texOffs(0, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -20.69142303727304F, -3.257211954768306F, -2.805867312159794F, -0.024711182853536733F, -3.0708989036585104F));
        g.addOrReplaceChild("nariz_106", CubeListBuilder.create().texOffs(820, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -20.975871801188852F, -3.1576790274416537F, -2.8134799007156954F, -0.07650283791306159F, -2.9207416054121667F));
        g.addOrReplaceChild("nariz_107", CubeListBuilder.create().texOffs(838, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -21.54879102389726F, -2.957205920886847F, -2.8323040537625195F, -0.1350006023048877F, -2.7429469640295947F));
        g.addOrReplaceChild("nariz_108", CubeListBuilder.create().texOffs(64, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -22.42187385651762F, -2.6517010245636903F, -2.8703677142904422F, -0.2018482936831762F, -2.5169428568602235F));
        g.addOrReplaceChild("nariz_109", CubeListBuilder.create().texOffs(80, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -23.626124038536958F, -2.230315660816728F, -2.9376387888873916F, -0.2696624299084759F, -2.2309617523128233F));
        g.addOrReplaceChild("nariz_110", CubeListBuilder.create().texOffs(284, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -25.254752911408517F, -1.6604337706159695F, -3.0309339584486947F, -0.31854517248196323F, -1.9117252301765768F));
        g.addOrReplaceChild("nariz_111", CubeListBuilder.create().texOffs(300, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.096418518319446F, -0.6660919691412278F, -3.1220502150736094F, -0.3360529860566029F, -1.6299966086565936F));
        g.addOrReplaceChild("nariz_112", CubeListBuilder.create().texOffs(20, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -21.649606342613502F, -5.246900090146173F, -2.5818573620669865F, -0.03981262778358491F, -3.0781551811450214F));
        g.addOrReplaceChild("nariz_113", CubeListBuilder.create().texOffs(856, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -21.904775222192512F, -5.086566856504991F, -2.5929152843852794F, -0.12342805219079357F, -2.9428486004373817F));
        g.addOrReplaceChild("nariz_114", CubeListBuilder.create().texOffs(874, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -22.418720700932752F, -4.7636335087643085F, -2.620658414067926F, -0.2185420675475982F, -2.780333117567334F));
        g.addOrReplaceChild("nariz_115", CubeListBuilder.create().texOffs(96, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -23.201932289243057F, -4.271509050694741F, -2.678470999431863F, -0.3288397479190952F, -2.5675122401229067F));
        g.addOrReplaceChild("nariz_116", CubeListBuilder.create().texOffs(112, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -24.282222340247255F, -3.5927178225729333F, -2.785978790618791F, -0.4435425229154255F, -2.284195359548962F));
        g.addOrReplaceChild("nariz_117", CubeListBuilder.create().texOffs(300, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -25.743207436542697F, -2.6747200433096774F, -2.9446542541070024F, -0.5287986119714375F, -1.947410984303623F));
        g.addOrReplaceChild("nariz_118", CubeListBuilder.create().texOffs(320, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.292364687471302F, -1.0729783819614385F, -3.1065102822832653F, -0.5600180384098515F, -1.6367709829212793F));
        g.addOrReplaceChild("nariz_119", CubeListBuilder.create().texOffs(40, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -23.026513254142635F, -6.973486745857358F, -2.3575976081580032F, -0.05292441362549758F, -3.0885939633818555F));
        g.addOrReplaceChild("nariz_120", CubeListBuilder.create().texOffs(892, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -23.239607016270305F, -6.760392983729691F, -2.369951585484982F, -0.16436717080219626F, -2.9749590212959074F));
        g.addOrReplaceChild("nariz_121", CubeListBuilder.create().texOffs(910, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -23.668807378688918F, -6.331192621311077F, -2.401531189684907F, -0.2922950651208647F, -2.8359417803073033F));
        g.addOrReplaceChild("nariz_122", CubeListBuilder.create().texOffs(128, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -24.32287422324451F, -5.677125776755486F, -2.470092151248428F, -0.4436246473673119F, -2.646383022983639F));
        g.addOrReplaceChild("nariz_123", CubeListBuilder.create().texOffs(144, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -25.22503388917781F, -4.774966110822187F, -2.607753864105073F, -0.6069425223523464F, -2.3740381162101523F));
        g.addOrReplaceChild("nariz_124", CubeListBuilder.create().texOffs(316, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -26.445115315626406F, -3.5548846843735924F, -2.834121362755641F, -0.7348960113908646F, -2.0130871946406783F));
        g.addOrReplaceChild("nariz_125", CubeListBuilder.create().texOffs(340, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.573938821657435F, -1.4260611783425654F, -3.0857944425374457F, -0.7838382038081357F, -1.6497479695611923F));
        g.addOrReplaceChild("nariz_126", CubeListBuilder.create().texOffs(60, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -24.753099909853816F, -8.350393657386494F, -2.1330599507772243F, -0.06338713598943704F, -3.1016998670456966F));
        g.addOrReplaceChild("nariz_127", CubeListBuilder.create().texOffs(928, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -24.913433143495002F, -8.095224777807484F, -2.1442643026855546F, -0.19721210157602304F, -3.0157120195000866F));
        g.addOrReplaceChild("nariz_128", CubeListBuilder.create().texOffs(946, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -25.236366491235685F, -7.581279299067245F, -2.1734665935350517F, -0.352287502447105F, -2.9084946766227286F));
        g.addOrReplaceChild("nariz_129", CubeListBuilder.create().texOffs(160, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -25.728490949305254F, -6.798067710756938F, -2.2398197180411685F, -0.5397998168305247F, -2.7556035669852577F));
        g.addOrReplaceChild("nariz_130", CubeListBuilder.create().texOffs(176, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -26.407282177427057F, -5.717777659752741F, -2.3867373250586783F, -0.751828351192524F, -2.513613839363769F));
        g.addOrReplaceChild("nariz_131", CubeListBuilder.create().texOffs(332, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -27.325279956690316F, -4.256792563457298F, -2.6736626408691024F, -0.9321466577724363F, -2.132569809588414F));
        g.addOrReplaceChild("nariz_132", CubeListBuilder.create().texOffs(360, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -28.927021618038562F, -1.7076353125286985F, -3.0529310861740657F, -1.0073179322215606F, -1.6755620086360334F));
        g.addOrReplaceChild("nariz_133", CubeListBuilder.create().texOffs(80, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -26.74278804523168F, -9.308576962726953F, -1.9082713305171022F, -0.07067213071320637F, -3.116819618793699F));
        g.addOrReplaceChild("nariz_134", CubeListBuilder.create().texOffs(964, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -26.842320972558333F, -9.024128198811141F, -1.9160665433294846F, -0.22019441448298707F, -3.063193111301796F));
        g.addOrReplaceChild("nariz_135", CubeListBuilder.create().texOffs(982, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -27.04279407911314F, -8.451208976102738F, -1.9367137013191704F, -0.39481639550481323F, -2.9952626454258384F));
        g.addOrReplaceChild("nariz_136", CubeListBuilder.create().texOffs(192, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -27.3482989754363F, -7.578126143482375F, -1.9855639870548398F, -0.6100887287095862F, -2.894476743104641F));
        g.addOrReplaceChild("nariz_137", CubeListBuilder.create().texOffs(208, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -27.76968433918326F, -6.373875961463039F, -2.105303480275049F, -0.8653848537697308F, -2.718151226267572F));
        g.addOrReplaceChild("nariz_138", CubeListBuilder.create().texOffs(348, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -28.339566229384022F, -4.74524708859148F, -2.4046593661216282F, -1.1085030245808123F, -2.363101208944768F));
        g.addOrReplaceChild("nariz_139", CubeListBuilder.create().texOffs(380, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -29.33390803085877F, -1.9035814816805543F, -2.98330029863478F, -1.229763602384363F, -1.7385863728201434F));
        g.addOrReplaceChild("nariz_140", CubeListBuilder.create().texOffs(100, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -28.895806388954288F, -9.799989349923926F, -1.6833087154257351F, -0.07440973517020037F, -3.1331930833885284F));
        g.addOrReplaceChild("nariz_141", CubeListBuilder.create().texOffs(1000, 244).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -28.929548013376937F, -9.500524150448653F, -1.68609911065437F, -0.23202630658064577F, -3.114966945530166F));
        g.addOrReplaceChild("nariz_142", CubeListBuilder.create().texOffs(0, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -28.99750832008042F, -8.897359745901015F, -1.69355813513729F, -0.41691792787328824F, -3.0916712284364434F));
        g.addOrReplaceChild("nariz_143", CubeListBuilder.create().texOffs(224, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -29.101074363478176F, -7.978185687874596F, -1.7116381885538636F, -0.6474901773387081F, -3.0562801064038143F));
        g.addOrReplaceChild("nariz_144", CubeListBuilder.create().texOffs(240, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -29.243923841159976F, -6.710361507477408F, -1.7591570263754277F, -0.9298617191200199F, -2.9899758237469163F));
        g.addOrReplaceChild("nariz_145", CubeListBuilder.create().texOffs(364, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -29.437113584704033F, -4.99575511027744F, -1.9117666000632592F, -1.2293817773348628F, -2.8189283535270224F));
        g.addOrReplaceChild("nariz_146", CubeListBuilder.create().texOffs(400, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -29.774195076369562F, -2.004074126676912F, -2.681360927588823F, -1.4455013710822069F, -2.0341673171163013F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("nariz_147", CubeListBuilder.create().texOffs(120, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -31.104193611045705F, -9.79998934992393F, -1.4582839381640595F, -0.07440973517020037F, 3.1331930833885284F));
        g.addOrReplaceChild("nariz_148", CubeListBuilder.create().texOffs(18, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -31.070451986623056F, -9.500524150448653F, -1.455493542935424F, -0.23202630658064619F, 3.1149669455301665F));
        g.addOrReplaceChild("nariz_149", CubeListBuilder.create().texOffs(36, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -31.002491679919572F, -8.897359745901015F, -1.4480345184525039F, -0.41691792787328824F, 3.0916712284364443F));
        g.addOrReplaceChild("nariz_150", CubeListBuilder.create().texOffs(256, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -30.89892563652182F, -7.978185687874598F, -1.4299544650359304F, -0.6474901773387081F, 3.0562801064038148F));
        g.addOrReplaceChild("nariz_151", CubeListBuilder.create().texOffs(272, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -30.75607615884002F, -6.710361507477409F, -1.3824356272143656F, -0.9298617191200201F, 2.9899758237469163F));
        g.addOrReplaceChild("nariz_152", CubeListBuilder.create().texOffs(380, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -30.56288641529596F, -4.99575511027744F, -1.2298260535265344F, -1.2293817773348625F, 2.8189283535270224F));
        g.addOrReplaceChild("nariz_153", CubeListBuilder.create().texOffs(420, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -30.225804923630434F, -2.0040741266769126F, -0.46023172600097373F, -1.4455013710822069F, 2.0341673171163044F));
        g.addOrReplaceChild("nariz_154", CubeListBuilder.create().texOffs(140, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -33.25721195476831F, -9.308576962726958F, -1.2333213230726923F, -0.07067213071320624F, 3.1168196187936994F));
        g.addOrReplaceChild("nariz_155", CubeListBuilder.create().texOffs(54, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -33.15767902744165F, -9.024128198811145F, -1.2255261102603099F, -0.22019441448298785F, 3.063193111301795F));
        g.addOrReplaceChild("nariz_156", CubeListBuilder.create().texOffs(72, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -32.95720592088685F, -8.45120897610274F, -1.2048789522706254F, -0.3948163955048133F, 2.99526264542584F));
        g.addOrReplaceChild("nariz_157", CubeListBuilder.create().texOffs(288, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -32.65170102456369F, -7.578126143482377F, -1.1560286665349544F, -0.6100887287095866F, 2.894476743104641F));
        g.addOrReplaceChild("nariz_158", CubeListBuilder.create().texOffs(304, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -32.23031566081673F, -6.373875961463042F, -1.0362891733147455F, -0.8653848537697317F, 2.7181512262675733F));
        g.addOrReplaceChild("nariz_159", CubeListBuilder.create().texOffs(396, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -31.66043377061597F, -4.745247088591482F, -0.7369332874681676F, -1.1085030245808134F, 2.3631012089447703F));
        g.addOrReplaceChild("nariz_160", CubeListBuilder.create().texOffs(440, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -30.666091969141227F, -1.9035814816805552F, -0.1582923549550141F, -1.2297636023843648F, 1.738586372820144F));
        g.addOrReplaceChild("nariz_161", CubeListBuilder.create().texOffs(160, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -35.24690009014618F, -8.350393657386498F, -1.0085327028125688F, -0.06338713598943685F, 3.101699867045698F));
        g.addOrReplaceChild("nariz_162", CubeListBuilder.create().texOffs(90, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -35.08656685650499F, -8.095224777807488F, -0.9973283509042388F, -0.19721210157602287F, 3.0157120195000866F));
        g.addOrReplaceChild("nariz_163", CubeListBuilder.create().texOffs(108, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -34.763633508764315F, -7.581279299067249F, -0.968126060054743F, -0.3522875024471053F, 2.9084946766227295F));
        g.addOrReplaceChild("nariz_164", CubeListBuilder.create().texOffs(320, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -34.271509050694746F, -6.798067710756941F, -0.9017729355486238F, -0.5397998168305249F, 2.7556035669852554F));
        g.addOrReplaceChild("nariz_165", CubeListBuilder.create().texOffs(336, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -33.592717822572936F, -5.717777659752744F, -0.7548553285311147F, -0.7518283511925239F, 2.51361383936377F));
        g.addOrReplaceChild("nariz_166", CubeListBuilder.create().texOffs(412, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -32.67472004330968F, -4.2567925634573F, -0.46793001272069085F, -0.9321466577724367F, 2.1325698095884142F));
        g.addOrReplaceChild("nariz_167", CubeListBuilder.create().texOffs(460, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.072978381961438F, -1.7076353125286992F, -0.08866156741572777F, -1.0073179322215617F, 1.6755620086360334F));
        g.addOrReplaceChild("nariz_168", CubeListBuilder.create().texOffs(180, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -36.97348674585736F, -6.973486745857363F, -0.783995045431792F, -0.052924413625498296F, 3.088593963381855F));
        g.addOrReplaceChild("nariz_169", CubeListBuilder.create().texOffs(126, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -36.76039298372969F, -6.760392983729696F, -0.7716410681048116F, -0.16436717080219573F, 2.9749590212959087F));
        g.addOrReplaceChild("nariz_170", CubeListBuilder.create().texOffs(144, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -36.33119262131108F, -6.331192621311082F, -0.7400614639048853F, -0.292295065120865F, 2.8359417803073024F));
        g.addOrReplaceChild("nariz_171", CubeListBuilder.create().texOffs(352, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -35.67712577675549F, -5.67712577675549F, -0.6715005023413655F, -0.44362464736731216F, 2.6463830229836383F));
        g.addOrReplaceChild("nariz_172", CubeListBuilder.create().texOffs(368, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -34.774966110822184F, -4.774966110822191F, -0.5338387894847214F, -0.6069425223523474F, 2.3740381162101523F));
        g.addOrReplaceChild("nariz_173", CubeListBuilder.create().texOffs(428, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -33.55488468437359F, -3.554884684373595F, -0.3074712908341536F, -0.7348960113908664F, 2.01308719464068F));
        g.addOrReplaceChild("nariz_174", CubeListBuilder.create().texOffs(480, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.426061178342565F, -1.4260611783425663F, -0.055798211052347835F, -0.7838382038081364F, 1.6497479695611925F));
        g.addOrReplaceChild("nariz_175", CubeListBuilder.create().texOffs(200, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -38.35039365738649F, -5.246900090146182F, -0.5597352915228062F, -0.03981262778358538F, 3.07815518114502F));
        g.addOrReplaceChild("nariz_176", CubeListBuilder.create().texOffs(162, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -38.09522477780748F, -5.086566856504999F, -0.5486773692045144F, -0.12342805219079374F, 2.9428486004373826F));
        g.addOrReplaceChild("nariz_177", CubeListBuilder.create().texOffs(180, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -37.58127929906725F, -4.763633508764316F, -0.520934239521869F, -0.21854206754759836F, 2.7803331175673347F));
        g.addOrReplaceChild("nariz_178", CubeListBuilder.create().texOffs(384, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -36.79806771075694F, -4.271509050694749F, -0.4631216541579314F, -0.3288397479190959F, 2.567512240122906F));
        g.addOrReplaceChild("nariz_179", CubeListBuilder.create().texOffs(400, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -35.71777765975274F, -3.5927178225729395F, -0.3556138629710029F, -0.4435425229154263F, 2.2841953595489626F));
        g.addOrReplaceChild("nariz_180", CubeListBuilder.create().texOffs(444, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -34.256792563457296F, -2.674720043309682F, -0.19693839948279196F, -0.5287986119714394F, 1.947410984303624F));
        g.addOrReplaceChild("nariz_181", CubeListBuilder.create().texOffs(500, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.7076353125287F, -1.0729783819614402F, -0.03508237130652795F, -0.5600180384098523F, 1.6367709829212793F));
        g.addOrReplaceChild("nariz_182", CubeListBuilder.create().texOffs(220, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -39.30857696272695F, -3.2572119547683176F, -0.33572534142999994F, -0.024711182853536892F, 3.0708989036585095F));
        g.addOrReplaceChild("nariz_183", CubeListBuilder.create().texOffs(198, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -39.02412819881114F, -3.1576790274416653F, -0.32811275287409813F, -0.07650283791306182F, 2.9207416054121667F));
        g.addOrReplaceChild("nariz_184", CubeListBuilder.create().texOffs(216, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -38.451208976102734F, -2.9572059208868575F, -0.30928859982727447F, -0.13500060230488758F, 2.7429469640295983F));
        g.addOrReplaceChild("nariz_185", CubeListBuilder.create().texOffs(416, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -37.57812614348238F, -2.6517010245637F, -0.2712249392993524F, -0.20184829368317714F, 2.516942856860222F));
        g.addOrReplaceChild("nariz_186", CubeListBuilder.create().texOffs(432, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -36.37387596146304F, -2.230315660816736F, -0.20395386470240368F, -0.2696624299084778F, 2.2309617523128242F));
        g.addOrReplaceChild("nariz_187", CubeListBuilder.create().texOffs(460, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -34.74524708859148F, -1.6604337706159755F, -0.11065869514109919F, -0.3185451724819647F, 1.911725230176577F));
        g.addOrReplaceChild("nariz_188", CubeListBuilder.create().texOffs(520, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -31.903581481680554F, -0.6660919691412303F, -0.019542438516184025F, -0.33605298605660394F, 1.6299966086565936F));
        g.addOrReplaceChild("nariz_189", CubeListBuilder.create().texOffs(240, 244).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.00134420280341F, -39.799989349923926F, -1.104193611045714F, -0.11188794083249648F, -0.008376326977429677F, 3.0671803031147453F));
        g.addOrReplaceChild("nariz_190", CubeListBuilder.create().texOffs(234, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.95382102883244F, -39.500524150448655F, -1.0704519866230613F, -0.10917883159239712F, -0.025912042224662007F, 2.9094870002666395F));
        g.addOrReplaceChild("nariz_191", CubeListBuilder.create().texOffs(252, 250).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.75818093439331F, -38.897359745901014F, -1.0024916799195784F, -0.10253236097553955F, -0.045642111758843355F, 2.7242129724683664F));
        g.addOrReplaceChild("nariz_192", CubeListBuilder.create().texOffs(448, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.32394577947044F, -37.9781856878746F, -0.898925636521826F, -0.08930296050650506F, -0.06801522157858363F, 2.4923486975869866F));
        g.addOrReplaceChild("nariz_193", CubeListBuilder.create().texOffs(464, 261).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.57260157666701F, -36.71036150747741F, -0.7560761588400252F, -0.0665011137045479F, -0.09043477897533869F, 2.206210184145637F));
        g.addOrReplaceChild("nariz_194", CubeListBuilder.create().texOffs(476, 294).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.44153551037908F, -34.995755110277436F, -0.5628864152959661F, -0.03576308818226126F, -0.10637015789392999F, 1.8958361397745642F));
        g.addOrReplaceChild("nariz_195", CubeListBuilder.create().texOffs(540, 313).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-88.8871756048182F, -32.00407412667691F, -0.22580492363043664F, -0.006293398207508903F, -0.11202383711533762F, 1.6270344790373377F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(728, 290).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(192, 207).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-89.4F, -30.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(752, 290).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(216, 207).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-89.4F, -30.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(776, 290).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(240, 207).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-89.4F, -30.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(800, 290).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(264, 207).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-89.4F, -30.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(896, 138).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(-90.42F, -30.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_0", CubeListBuilder.create().texOffs(824, 290).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(288, 207).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.5F, -41.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_1", CubeListBuilder.create().texOffs(848, 290).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(312, 207).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.5F, -41.5F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_2", CubeListBuilder.create().texOffs(872, 290).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(336, 207).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.5F, -41.5F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_3", CubeListBuilder.create().texOffs(896, 290).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(360, 207).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.5F, -41.5F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_vidrio", CubeListBuilder.create().texOffs(542, 193).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-77.32F, -41.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("campana_0", CubeListBuilder.create().texOffs(0, 229).addBox(-13.0F, -42.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(122, 138).addBox(-3.5F, -42.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(-50.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("campana_1", CubeListBuilder.create().texOffs(66, 229).addBox(-13.0F, -42.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(188, 138).addBox(-3.5F, -42.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-50.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("campana_2", CubeListBuilder.create().texOffs(132, 229).addBox(-13.0F, -42.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(254, 138).addBox(-3.5F, -42.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-50.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("faldon", CubeListBuilder.create().texOffs(320, 138).addBox(-84.0F, -24.0F, -13.0F, 116.0F, 1.0F, 26.0F).texOffs(524, 219).addBox(-84.0F, -24.0F, 12.0F, 116.0F, 8.0F, 1.0F).texOffs(758, 219).addBox(-84.0F, -24.0F, -13.0F, 116.0F, 8.0F, 1.0F).texOffs(260, 244).addBox(-102.0F, -8.0F, -1.5F, 7.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldon_frente_0", CubeListBuilder.create().texOffs(284, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.93092720214682F, -13.5F, -12.911057465750233F, -1.6660490777722037F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_1", CubeListBuilder.create().texOffs(320, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.93092720214682F, -20.5F, -12.911057465750233F, -1.6660490777722037F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_2", CubeListBuilder.create().texOffs(356, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.6443282570732F, -13.5F, -12.557171182990185F, -1.89727719228154F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_3", CubeListBuilder.create().texOffs(392, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.6443282570732F, -20.5F, -12.557171182990185F, -1.89727719228154F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_4", CubeListBuilder.create().texOffs(428, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.12489134563305F, -13.5F, -11.856834482526137F, -2.128454793972795F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_5", CubeListBuilder.create().texOffs(464, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.12489134563305F, -20.5F, -11.856834482526137F, -2.128454793972795F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_6", CubeListBuilder.create().texOffs(500, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.43473471686077F, -13.5F, -10.824499425745387F, -2.3439405518305545F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_7", CubeListBuilder.create().texOffs(536, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.43473471686077F, -20.5F, -10.824499425745387F, -2.3439405518305545F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_8", CubeListBuilder.create().texOffs(572, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.56355272954895F, -13.5F, -9.480687276015143F, -2.536047989984824F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_9", CubeListBuilder.create().texOffs(608, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.56355272954895F, -20.5F, -9.480687276015143F, -2.536047989984824F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_10", CubeListBuilder.create().texOffs(644, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.49388421782373F, -13.5F, -7.850172368798894F, -2.7041294456239546F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_11", CubeListBuilder.create().texOffs(680, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.49388421782373F, -20.5F, -7.850172368798894F, -2.7041294456239546F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_12", CubeListBuilder.create().texOffs(0, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.20857771867195F, -13.5F, -5.958176388136612F, -2.8511182636319106F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_13", CubeListBuilder.create().texOffs(38, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.20857771867195F, -20.5F, -5.958176388136612F, -2.8511182636319106F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_14", CubeListBuilder.create().texOffs(76, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.6934262036086F, -13.5F, -3.819585260216832F, -2.980708849758128F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_15", CubeListBuilder.create().texOffs(114, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.6934262036086F, -20.5F, -3.819585260216832F, -2.980708849758128F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_16", CubeListBuilder.create().texOffs(850, 229).addBox(-7.0F, -1.0F, -3.0F, 14.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-92.93842439936554F, -13.5F, -1.3446726253231727F, -3.0958323595133255F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_17", CubeListBuilder.create().texOffs(890, 229).addBox(-7.0F, -1.0F, -3.0F, 14.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-92.93842439936554F, -20.5F, -1.3446726253231727F, -3.0958323595133255F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_18", CubeListBuilder.create().texOffs(930, 229).addBox(-7.0F, -1.0F, -3.0F, 14.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-92.93842439936554F, -13.5F, 1.3446726253231727F, 3.0958323595133255F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_19", CubeListBuilder.create().texOffs(970, 229).addBox(-7.0F, -1.0F, -3.0F, 14.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-92.93842439936554F, -20.5F, 1.3446726253231727F, 3.0958323595133255F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_20", CubeListBuilder.create().texOffs(152, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.6934262036086F, -13.5F, 3.8195852602168303F, 2.9807088497581278F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_21", CubeListBuilder.create().texOffs(190, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.6934262036086F, -20.5F, 3.8195852602168303F, 2.9807088497581278F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_22", CubeListBuilder.create().texOffs(228, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.20857771867193F, -13.5F, 5.958176388136609F, 2.851118263631911F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_23", CubeListBuilder.create().texOffs(266, 238).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.20857771867193F, -20.5F, 5.958176388136609F, 2.851118263631911F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_24", CubeListBuilder.create().texOffs(716, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.49388421782372F, -13.5F, 7.850172368798894F, 2.7041294456239546F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_25", CubeListBuilder.create().texOffs(752, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.49388421782372F, -20.5F, 7.850172368798894F, 2.7041294456239546F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_26", CubeListBuilder.create().texOffs(788, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.56355272954895F, -13.5F, 9.480687276015143F, 2.5360479899848234F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("faldon_frente_27", CubeListBuilder.create().texOffs(824, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.56355272954895F, -20.5F, 9.480687276015143F, 2.5360479899848234F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_28", CubeListBuilder.create().texOffs(860, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.43473471686077F, -13.5F, 10.824499425745385F, 2.3439405518305536F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_29", CubeListBuilder.create().texOffs(896, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.43473471686077F, -20.5F, 10.824499425745385F, 2.3439405518305536F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_30", CubeListBuilder.create().texOffs(932, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.12489134563305F, -13.5F, 11.856834482526136F, 2.1284547939727974F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_31", CubeListBuilder.create().texOffs(968, 250).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.12489134563305F, -20.5F, 11.856834482526136F, 2.1284547939727974F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_32", CubeListBuilder.create().texOffs(0, 256).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.6443282570732F, -13.5F, 12.557171182990185F, 1.89727719228154F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_33", CubeListBuilder.create().texOffs(36, 256).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.6443282570732F, -20.5F, 12.557171182990185F, 1.89727719228154F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_34", CubeListBuilder.create().texOffs(72, 256).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.93092720214682F, -13.5F, 12.911057465750234F, 1.6660490777722037F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_35", CubeListBuilder.create().texOffs(108, 256).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.93092720214682F, -20.5F, 12.911057465750234F, 1.6660490777722037F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_tapa", CubeListBuilder.create().texOffs(604, 138).addBox(0.0F, -1.0F, 0.0F, 9.0F, 1.0F, 26.0F), PartPose.offset(-93.0F, -23.0F, -13.0F));
        g.addOrReplaceChild("piloto_0", CubeListBuilder.create().texOffs(598, 238).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-89.7115762979021F, -4.0F, -11.14805689442376F, -1.7795167451853933F, -0.0286786851067917F, -1.4243232333979758F));
        g.addOrReplaceChild("piloto_1", CubeListBuilder.create().texOffs(428, 256).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.55686367188811F, -8.0F, -11.14805689442376F, -1.871759114447591F, 0.0F, -1.2897586358401607F));
        g.addOrReplaceChild("piloto_2", CubeListBuilder.create().texOffs(626, 238).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-91.83160441213326F, -4.0F, -10.488160338223159F, -2.0203483907017006F, 0.0F, -1.1449781922423197F));
        g.addOrReplaceChild("piloto_3", CubeListBuilder.create().texOffs(454, 256).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.01732748391403F, -8.0F, -10.488160338223159F, -2.1817955166198897F, 0.0F, -1.1449781922423228F));
        g.addOrReplaceChild("piloto_4", CubeListBuilder.create().texOffs(204, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.58065310984816F, -4.0F, -9.468259498355339F, -2.2921020674873684F, 0.0F, -1.0380542682679679F));
        g.addOrReplaceChild("piloto_5", CubeListBuilder.create().texOffs(232, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.22222769789539F, -8.0F, -9.468259498355339F, -2.477068607018498F, 0.0F, -1.0380542682679679F));
        g.addOrReplaceChild("piloto_6", CubeListBuilder.create().texOffs(260, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.99401954126277F, -4.0F, -8.099685819291068F, -2.5559987926073493F, 0.0F, -0.9603826096836272F));
        g.addOrReplaceChild("piloto_7", CubeListBuilder.create().texOffs(288, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.19588012842547F, -8.0F, -8.099685819291068F, -2.713043444082693F, 0.0F, -0.9603826096836272F));
        g.addOrReplaceChild("piloto_8", CubeListBuilder.create().texOffs(406, 238).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-96.06848712062265F, -4.0F, -6.3888066825133025F, -2.7805410947031586F, 0.0F, -0.9064427245156866F));
        g.addOrReplaceChild("piloto_9", CubeListBuilder.create().texOffs(144, 256).addBox(-5.5F, -1.0F, -2.0F, 11.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.93606890531782F, -8.0F, -6.3888066825133025F, -2.8871055366859353F, 0.0F, -0.9064427245156876F));
        g.addOrReplaceChild("piloto_10", CubeListBuilder.create().texOffs(438, 238).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-96.79321457010482F, -4.0F, -4.3144095100901145F, -2.958866160657571F, 0.0F, -0.872446007731317F));
        g.addOrReplaceChild("piloto_11", CubeListBuilder.create().texOffs(470, 238).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-93.43532559273888F, -8.0F, -4.3144095100901145F, -3.014975459972574F, 0.0F, -0.8724460077313159F));
        g.addOrReplaceChild("piloto_12", CubeListBuilder.create().texOffs(198, 229).addBox(-5.5F, -1.0F, -3.5F, 11.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.15835187428678F, -4.0F, -1.5904288879314532F, -3.098091919516441F, -0.018840445402565287F, -0.8568378626314546F));
        g.addOrReplaceChild("piloto_13", CubeListBuilder.create().texOffs(234, 229).addBox(-5.5F, -1.0F, -3.5F, 11.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-93.68686462450867F, -8.0F, -1.5904288879314532F, -3.111618342570505F, -0.012995114034390073F, -0.8564074460726053F));
        g.addOrReplaceChild("piloto_14", CubeListBuilder.create().texOffs(270, 229).addBox(-5.5F, -1.0F, -3.5F, 11.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.15835187428678F, -4.0F, 1.5904288879314523F, 3.098091919516441F, 0.018840445402565287F, -0.8568378626314546F));
        g.addOrReplaceChild("piloto_15", CubeListBuilder.create().texOffs(306, 229).addBox(-5.5F, -1.0F, -3.5F, 11.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-93.68686462450867F, -8.0F, 1.5904288879314523F, 3.111618342570505F, 0.01299511403439015F, -0.8564074460726052F));
        g.addOrReplaceChild("piloto_16", CubeListBuilder.create().texOffs(502, 238).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-96.79321457010482F, -4.0F, 4.314409510090112F, 2.958866160657571F, 0.0F, -0.872446007731317F));
        g.addOrReplaceChild("piloto_17", CubeListBuilder.create().texOffs(534, 238).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-93.43532559273888F, -8.0F, 4.314409510090112F, 3.0149754599725735F, 0.0F, -0.8724460077313159F));
        g.addOrReplaceChild("piloto_18", CubeListBuilder.create().texOffs(566, 238).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-96.06848712062265F, -4.0F, 6.3888066825133F, 2.7805410947031612F, 0.0F, -0.9064427245156876F));
        g.addOrReplaceChild("piloto_19", CubeListBuilder.create().texOffs(174, 256).addBox(-5.5F, -1.0F, -2.0F, 11.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.93606890531782F, -8.0F, 6.3888066825133F, 2.8871055366859384F, 0.0F, -0.9064427245156866F));
        g.addOrReplaceChild("piloto_20", CubeListBuilder.create().texOffs(316, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.99401954126279F, -4.0F, 8.099685819291068F, 2.5559987926073466F, 0.0F, -0.9603826096836283F));
        g.addOrReplaceChild("piloto_21", CubeListBuilder.create().texOffs(344, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.19588012842547F, -8.0F, 8.099685819291068F, 2.7130434440826905F, 0.0F, -0.960382609683626F));
        g.addOrReplaceChild("piloto_22", CubeListBuilder.create().texOffs(372, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.58065310984816F, -4.0F, 9.468259498355337F, 2.292102067487368F, 0.0F, -1.0380542682679679F));
        g.addOrReplaceChild("piloto_23", CubeListBuilder.create().texOffs(400, 256).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.22222769789539F, -8.0F, 9.468259498355337F, 2.4770686070184973F, 0.0F, -1.0380542682679679F));
        g.addOrReplaceChild("piloto_24", CubeListBuilder.create().texOffs(654, 238).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-91.83160441213326F, -4.0F, 10.488160338223157F, 2.020348390701702F, 0.0F, -1.1449781922423212F));
        g.addOrReplaceChild("piloto_25", CubeListBuilder.create().texOffs(480, 256).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.01732748391403F, -8.0F, 10.488160338223157F, 2.1817955166198924F, 0.0F, -1.1449781922423212F));
        g.addOrReplaceChild("piloto_26", CubeListBuilder.create().texOffs(682, 238).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-89.7115762979021F, -4.0F, 11.14805689442376F, 1.7795167451853933F, 0.02867868510679156F, -1.4243232333979767F));
        g.addOrReplaceChild("piloto_27", CubeListBuilder.create().texOffs(506, 256).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.55686367188811F, -8.0F, 11.14805689442376F, 1.8717591144475907F, 0.0F, -1.289758635840159F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(324, 172).addBox(33.0F, -42.0F, 12.0F, 23.0F, 19.0F, 1.0F).texOffs(372, 172).addBox(33.0F, -42.0F, -13.0F, 23.0F, 19.0F, 1.0F).texOffs(802, 138).addBox(33.0F, -24.0F, -12.0F, 23.0F, 1.0F, 24.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(68, 138).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 26.0F), PartPose.offset(32.0F, -38.0F, -13.0F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(300, 172).addBox(33.0F, -35.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(1010, 229).addBox(35.0F, -29.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(780, 261).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -41.28156684839221F, -11.982230097189813F, -2.6990003544068575F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(840, 261).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -42.16293955104396F, -9.911208526720891F, -2.7794716815310276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(900, 261).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -42.87498202631751F, -7.77604021959999F, -2.859943008655197F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(960, 261).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -43.41308583508825F, -5.590544285649612F, -2.9404143357793693F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(0, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -43.77376829376423F, -3.368865562177053F, -3.0208856629035403F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(60, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -43.954695014704484F, -1.1253830665963498F, -3.101356990027708F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(120, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -43.954695014704484F, 1.1253830665963482F, 3.101356990027708F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(180, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -43.773768293764235F, 3.3688655621770502F, 3.0208856629035403F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(240, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -43.41308583508825F, 5.590544285649611F, 2.9404143357793697F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(300, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -42.87498202631751F, 7.776040219599987F, 2.8599430086551965F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(360, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -42.16293955104396F, 9.911208526720891F, 2.779471681531028F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(420, 266).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(44.5F, -41.28156684839221F, 11.982230097189813F, 2.6990003544068575F, 0.0F, 0.0F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(74.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(670, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(86.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(680, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(98.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(690, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(156.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(156.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(156.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri4_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(700, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(168.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri4_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(168.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri4_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(168.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri5_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(710, 261).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(180.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri5_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(180.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri5_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(180.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(74.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(86.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(740, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(98.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(750, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(156.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(156.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(156.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd4_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(760, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(168.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd4_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(168.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd4_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(168.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd5_0", CubeListBuilder.create().texOffs(884, 207).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(986, 290).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(770, 261).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(180.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd5_1", CubeListBuilder.create().texOffs(0, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(180.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd5_2", CubeListBuilder.create().texOffs(22, 294).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 207).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(180.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(0, 219).addBox(62.0F, -13.0F, 2.0F, 130.0F, 9.0F, 1.0F).texOffs(262, 219).addBox(62.0F, -13.0F, -3.0F, 130.0F, 9.0F, 1.0F).texOffs(570, 229).addBox(69.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(640, 229).addBox(69.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F).texOffs(710, 229).addBox(151.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(780, 229).addBox(151.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(690, 69).addBox(60.0F, -35.0F, -13.0F, 134.0F, 22.0F, 26.0F).texOffs(0, 172).addBox(60.0F, -40.0F, -8.0F, 134.0F, 5.0F, 16.0F).texOffs(492, 172).addBox(62.0F, -41.0F, -7.0F, 42.0F, 1.0F, 14.0F).texOffs(674, 138).addBox(194.0F, -13.0F, -10.0F, 2.0F, 7.0F, 20.0F).texOffs(270, 250).addBox(196.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(572, 294).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -35.772542485937365F, -12.877641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(0, 298).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -37.24200561666855F, -12.400183776675252F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(272, 298).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -38.49200561666855F, -11.49200561666855F, -2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(544, 298).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -39.40018377667525F, -10.24200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(0, 301).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -39.877641290737884F, -8.772542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(272, 301).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -35.772542485937365F, 12.877641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(544, 301).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -37.24200561666855F, 12.400183776675252F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(0, 304).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -38.49200561666855F, 11.49200561666855F, 2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(272, 304).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -39.40018377667525F, 10.24200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(544, 304).addBox(-67.0F, -1.0F, -1.0F, 134.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(127.0F, -39.877641290737884F, 8.772542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(478, 69).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 52.0F), PartPose.offset(60.0F, -35.0F, -13.0F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(584, 69).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 52.0F), PartPose.offset(193.0F, -35.0F, -13.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "caja_humo_0", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_1", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_2", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_3", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_4", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_5", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_6", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caldera_0", 0.960018749816898F, 1.0F, 0.7277690946715011F);
        escalar(g0, "caldera_1", 0.960018749816898F, 1.0F, 0.7389655422818316F);
        escalar(g0, "caldera_2", 0.960018749816898F, 1.0F, 0.7501619898921624F);
        escalar(g0, "caldera_3", 0.960018749816898F, 1.0F, 0.7613584375024934F);
        escalar(g0, "caldera_4", 0.960018749816898F, 1.0F, 0.7277690946715013F);
        escalar(g0, "caldera_5", 0.960018749816898F, 1.0F, 0.7389655422818322F);
        escalar(g0, "caldera_6", 0.960018749816898F, 1.0F, 0.7501619898921628F);
        escalar(g0, "caldera_7", 0.960018749816898F, 1.0F, 0.761358437502493F);
        escalar(g0, "caldera_8", 0.960018749816898F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_9", 0.960018749816898F, 1.0F, 0.7389655422818314F);
        escalar(g0, "caldera_10", 0.960018749816898F, 1.0F, 0.7501619898921627F);
        escalar(g0, "caldera_11", 0.960018749816898F, 1.0F, 0.7613584375024943F);
        escalar(g0, "caldera_12", 0.960018749816898F, 1.0F, 0.7277690946715002F);
        escalar(g0, "caldera_13", 0.960018749816898F, 1.0F, 0.7389655422818309F);
        escalar(g0, "caldera_14", 0.960018749816898F, 1.0F, 0.7501619898921615F);
        escalar(g0, "caldera_15", 0.960018749816898F, 1.0F, 0.761358437502492F);
        escalar(g0, "caldera_16", 0.960018749816898F, 1.0F, 0.7277690946714995F);
        escalar(g0, "caldera_17", 0.960018749816898F, 1.0F, 0.7389655422818314F);
        escalar(g0, "caldera_18", 0.960018749816898F, 1.0F, 0.7501619898921635F);
        escalar(g0, "caldera_19", 0.960018749816898F, 1.0F, 0.7613584375024937F);
        escalar(g0, "caldera_20", 0.960018749816898F, 1.0F, 0.7277690946715024F);
        escalar(g0, "caldera_21", 0.960018749816898F, 1.0F, 0.7389655422818321F);
        escalar(g0, "caldera_22", 0.960018749816898F, 1.0F, 0.7501619898921619F);
        escalar(g0, "caldera_23", 0.960018749816898F, 1.0F, 0.7613584375024937F);
        escalar(g0, "caldera_24", 0.960018749816898F, 1.0F, 0.7277690946715017F);
        escalar(g0, "caldera_25", 0.960018749816898F, 1.0F, 0.7389655422818325F);
        escalar(g0, "caldera_26", 0.960018749816898F, 1.0F, 0.7501619898921632F);
        escalar(g0, "caldera_27", 0.960018749816898F, 1.0F, 0.7613584375024939F);
        escalar(g0, "caldera_28", 0.960018749816898F, 1.0F, 0.7277690946715004F);
        escalar(g0, "caldera_29", 0.960018749816898F, 1.0F, 0.7389655422818313F);
        escalar(g0, "caldera_30", 0.960018749816898F, 1.0F, 0.750161989892162F);
        escalar(g0, "caldera_31", 0.960018749816898F, 1.0F, 0.7613584375024928F);
        escalar(g0, "caldera_32", 0.960018749816898F, 1.0F, 0.7277690946715011F);
        escalar(g0, "caldera_33", 0.960018749816898F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_34", 0.960018749816898F, 1.0F, 0.7501619898921628F);
        escalar(g0, "caldera_35", 0.960018749816898F, 1.0F, 0.7613584375024934F);
        escalar(g0, "caldera_36", 0.960018749816898F, 1.0F, 0.7277690946715002F);
        escalar(g0, "caldera_37", 0.960018749816898F, 1.0F, 0.7389655422818301F);
        escalar(g0, "caldera_38", 0.960018749816898F, 1.0F, 0.7501619898921611F);
        escalar(g0, "caldera_39", 0.960018749816898F, 1.0F, 0.7613584375024923F);
        escalar(g0, "caldera_40", 0.960018749816898F, 1.0F, 0.7277690946715025F);
        escalar(g0, "caldera_41", 0.960018749816898F, 1.0F, 0.7389655422818331F);
        escalar(g0, "caldera_42", 0.960018749816898F, 1.0F, 0.7501619898921638F);
        escalar(g0, "caldera_43", 0.960018749816898F, 1.0F, 0.7613584375024943F);
        escalar(g0, "caldera_44", 0.960018749816898F, 1.0F, 0.7277690946715006F);
        escalar(g0, "caldera_45", 0.960018749816898F, 1.0F, 0.7389655422818314F);
        escalar(g0, "caldera_46", 0.960018749816898F, 1.0F, 0.7501619898921627F);
        escalar(g0, "caldera_47", 0.960018749816898F, 1.0F, 0.761358437502493F);
        escalar(g0, "caldera_48", 0.960018749816898F, 1.0F, 0.7277690946715F);
        escalar(g0, "caldera_49", 0.960018749816898F, 1.0F, 0.7389655422818309F);
        escalar(g0, "caldera_50", 0.960018749816898F, 1.0F, 0.7501619898921613F);
        escalar(g0, "caldera_51", 0.960018749816898F, 1.0F, 0.7613584375024923F);
        escalar(g0, "caldera_52", 0.960018749816898F, 1.0F, 0.7277690946715024F);
        escalar(g0, "caldera_53", 0.960018749816898F, 1.0F, 0.738965542281833F);
        escalar(g0, "caldera_54", 0.960018749816898F, 1.0F, 0.7501619898921638F);
        escalar(g0, "caldera_55", 0.960018749816898F, 1.0F, 0.7613584375024948F);
        escalar(g0, "caldera_56", 0.960018749816898F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_57", 0.960018749816898F, 1.0F, 0.7389655422818316F);
        escalar(g0, "caldera_58", 0.960018749816898F, 1.0F, 0.7501619898921624F);
        escalar(g0, "caldera_59", 0.960018749816898F, 1.0F, 0.7613584375024934F);
        escalar(g0, "caldera_60", 0.960018749816898F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_61", 0.960018749816898F, 1.0F, 0.7389655422818321F);
        escalar(g0, "caldera_62", 0.960018749816898F, 1.0F, 0.7501619898921627F);
        escalar(g0, "caldera_63", 0.960018749816898F, 1.0F, 0.7613584375024934F);
        escalar(g0, "caldera_64", 0.960018749816898F, 1.0F, 0.7277690946714993F);
        escalar(g0, "caldera_65", 0.960018749816898F, 1.0F, 0.7389655422818299F);
        escalar(g0, "caldera_66", 0.960018749816898F, 1.0F, 0.7501619898921607F);
        escalar(g0, "caldera_67", 0.960018749816898F, 1.0F, 0.7613584375024912F);
        escalar(g0, "caldera_68", 0.960018749816898F, 1.0F, 0.7277690946715026F);
        escalar(g0, "caldera_69", 0.960018749816898F, 1.0F, 0.7389655422818334F);
        escalar(g0, "caldera_70", 0.960018749816898F, 1.0F, 0.7501619898921641F);
        escalar(g0, "caldera_71", 0.960018749816898F, 1.0F, 0.7613584375024948F);
        escalar(g0, "caldera_72", 0.960018749816898F, 1.0F, 0.7277690946714981F);
        escalar(g0, "caldera_73", 0.960018749816898F, 1.0F, 0.7389655422818292F);
        escalar(g0, "caldera_74", 0.960018749816898F, 1.0F, 0.7501619898921604F);
        escalar(g0, "caldera_75", 0.960018749816898F, 1.0F, 0.7613584375024914F);
        escalar(g0, "caldera_76", 0.960018749816898F, 1.0F, 0.7277690946715015F);
        escalar(g0, "caldera_77", 0.960018749816898F, 1.0F, 0.7389655422818321F);
        escalar(g0, "caldera_78", 0.960018749816898F, 1.0F, 0.7501619898921629F);
        escalar(g0, "caldera_79", 0.960018749816898F, 1.0F, 0.7613584375024937F);
        escalar(g0, "caldera_80", 0.960018749816898F, 1.0F, 0.727769094671503F);
        escalar(g0, "caldera_81", 0.960018749816898F, 1.0F, 0.7389655422818336F);
        escalar(g0, "caldera_82", 0.960018749816898F, 1.0F, 0.7501619898921644F);
        escalar(g0, "caldera_83", 0.960018749816898F, 1.0F, 0.7613584375024951F);
        escalar(g0, "caldera_84", 0.960018749816898F, 1.0F, 0.7277690946715029F);
        escalar(g0, "caldera_85", 0.960018749816898F, 1.0F, 0.7389655422818313F);
        escalar(g0, "caldera_86", 0.960018749816898F, 1.0F, 0.7501619898921644F);
        escalar(g0, "caldera_87", 0.960018749816898F, 1.0F, 0.7613584375024951F);
        escalar(g0, "caldera_88", 0.960018749816898F, 1.0F, 0.7277690946715F);
        escalar(g0, "caldera_89", 0.960018749816898F, 1.0F, 0.7389655422818316F);
        escalar(g0, "caldera_90", 0.960018749816898F, 1.0F, 0.7501619898921614F);
        escalar(g0, "caldera_91", 0.960018749816898F, 1.0F, 0.7613584375024933F);
        escalar(g0, "caldera_92", 0.960018749816898F, 1.0F, 0.7277690946715015F);
        escalar(g0, "caldera_93", 0.960018749816898F, 1.0F, 0.7389655422818319F);
        escalar(g0, "caldera_94", 0.960018749816898F, 1.0F, 0.7501619898921619F);
        escalar(g0, "caldera_95", 0.960018749816898F, 1.0F, 0.761358437502492F);
        escalar(g0, "caldera_96", 0.960018749816898F, 1.0F, 0.7277690946715002F);
        escalar(g0, "caldera_97", 0.960018749816898F, 1.0F, 0.7389655422818323F);
        escalar(g0, "caldera_98", 0.960018749816898F, 1.0F, 0.7501619898921628F);
        escalar(g0, "caldera_99", 0.960018749816898F, 1.0F, 0.7613584375024934F);
        escalar(g0, "caldera_100", 0.960018749816898F, 1.0F, 0.7277690946714978F);
        escalar(g0, "caldera_101", 0.960018749816898F, 1.0F, 0.7389655422818292F);
        escalar(g0, "caldera_102", 0.960018749816898F, 1.0F, 0.7501619898921593F);
        escalar(g0, "caldera_103", 0.960018749816898F, 1.0F, 0.7613584375024908F);
        escalar(g0, "caldera_104", 0.960018749816898F, 1.0F, 0.7277690946715017F);
        escalar(g0, "caldera_105", 0.960018749816898F, 1.0F, 0.738965542281831F);
        escalar(g0, "caldera_106", 0.960018749816898F, 1.0F, 0.7501619898921631F);
        escalar(g0, "caldera_107", 0.960018749816898F, 1.0F, 0.7613584375024933F);
        escalar(g0, "caldera_108", 0.960018749816898F, 1.0F, 0.727769094671504F);
        escalar(g0, "caldera_109", 0.960018749816898F, 1.0F, 0.7389655422818349F);
        escalar(g0, "caldera_110", 0.960018749816898F, 1.0F, 0.7501619898921653F);
        escalar(g0, "caldera_111", 0.960018749816898F, 1.0F, 0.7613584375024964F);
        escalar(g0, "skyline_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "skyline_cantoi_1", 1.0F, 1.0F, 0.9386067902413818F);
        escalar(g0, "skyline_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "skyline_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "skyline_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "skyline_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "skyline_cantod_1", 1.0F, 1.0F, 0.9386067902413818F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "skyline_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "skyline_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "skyline_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "skyline_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "skyline_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "nariz_0", 0.40567753363893555F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_1", 0.4940006305827802F, 1.0F, 0.43489014141752624F);
        escalar(g0, "nariz_2", 0.47265444948599333F, 1.0F, 0.407534009118102F);
        escalar(g0, "nariz_3", 0.454353612920132F, 1.0F, 0.45730682866339883F);
        escalar(g0, "nariz_4", 0.46037232254446037F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_5", 0.42562651611687674F, 1.0F, 0.3842987481297931F);
        escalar(g0, "nariz_6", 0.4539221919948464F, 1.0F, 0.47446744315377615F);
        escalar(g0, "nariz_7", 0.40567753363893555F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_8", 0.49400063058278054F, 1.0F, 0.4348901414175265F);
        escalar(g0, "nariz_9", 0.47265444948599317F, 1.0F, 0.40753400911810217F);
        escalar(g0, "nariz_10", 0.4543536129201319F, 1.0F, 0.457306828663399F);
        escalar(g0, "nariz_11", 0.4603723225444599F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_12", 0.4256265161168769F, 1.0F, 0.3842987481297931F);
        escalar(g0, "nariz_13", 0.45392219199484646F, 1.0F, 0.4744674431537765F);
        escalar(g0, "nariz_14", 0.40567753363893566F, 1.0F, 0.4484721922715772F);
        escalar(g0, "nariz_15", 0.4940006305827804F, 1.0F, 0.43489014141752635F);
        escalar(g0, "nariz_16", 0.4726544494859931F, 1.0F, 0.4075340091181018F);
        escalar(g0, "nariz_17", 0.454353612920132F, 1.0F, 0.457306828663399F);
        escalar(g0, "nariz_18", 0.46037232254445937F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_19", 0.4256265161168771F, 1.0F, 0.3842987481297928F);
        escalar(g0, "nariz_20", 0.45392219199484646F, 1.0F, 0.4744674431537753F);
        escalar(g0, "nariz_21", 0.40567753363893566F, 1.0F, 0.4484721922715765F);
        escalar(g0, "nariz_22", 0.4940006305827803F, 1.0F, 0.4348901414175259F);
        escalar(g0, "nariz_23", 0.47265444948599317F, 1.0F, 0.4075340091181018F);
        escalar(g0, "nariz_24", 0.454353612920132F, 1.0F, 0.4573068286633982F);
        escalar(g0, "nariz_25", 0.4603723225444597F, 1.0F, 0.3854301443177637F);
        escalar(g0, "nariz_26", 0.42562651611687696F, 1.0F, 0.38429874812979387F);
        escalar(g0, "nariz_27", 0.45392219199484646F, 1.0F, 0.4744674431537777F);
        escalar(g0, "nariz_28", 0.40567753363893566F, 1.0F, 0.4484721922715772F);
        escalar(g0, "nariz_29", 0.49400063058278043F, 1.0F, 0.4348901414175265F);
        escalar(g0, "nariz_30", 0.472654449485993F, 1.0F, 0.407534009118102F);
        escalar(g0, "nariz_31", 0.454353612920132F, 1.0F, 0.45730682866339856F);
        escalar(g0, "nariz_32", 0.46037232254446026F, 1.0F, 0.38543014431776373F);
        escalar(g0, "nariz_33", 0.4256265161168768F, 1.0F, 0.384298748129793F);
        escalar(g0, "nariz_34", 0.4539221919948463F, 1.0F, 0.4744674431537745F);
        escalar(g0, "nariz_35", 0.40567753363893566F, 1.0F, 0.4484721922715772F);
        escalar(g0, "nariz_36", 0.4940006305827803F, 1.0F, 0.4348901414175262F);
        escalar(g0, "nariz_37", 0.4726544494859931F, 1.0F, 0.4075340091181018F);
        escalar(g0, "nariz_38", 0.4543536129201321F, 1.0F, 0.4573068286633997F);
        escalar(g0, "nariz_39", 0.46037232254446026F, 1.0F, 0.38543014431776473F);
        escalar(g0, "nariz_40", 0.42562651611687635F, 1.0F, 0.38429874812979326F);
        escalar(g0, "nariz_41", 0.4539221919948464F, 1.0F, 0.47446744315377654F);
        escalar(g0, "nariz_42", 0.40567753363893566F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_43", 0.4940006305827803F, 1.0F, 0.4348901414175267F);
        escalar(g0, "nariz_44", 0.4726544494859931F, 1.0F, 0.40753400911810217F);
        escalar(g0, "nariz_45", 0.4543536129201322F, 1.0F, 0.45730682866339867F);
        escalar(g0, "nariz_46", 0.4603723225444601F, 1.0F, 0.3854301443177638F);
        escalar(g0, "nariz_47", 0.42562651611687646F, 1.0F, 0.3842987481297932F);
        escalar(g0, "nariz_48", 0.45392219199484646F, 1.0F, 0.47446744315377637F);
        escalar(g0, "nariz_49", 0.40567753363893566F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_50", 0.4940006305827804F, 1.0F, 0.43489014141752635F);
        escalar(g0, "nariz_51", 0.47265444948599306F, 1.0F, 0.4075340091181018F);
        escalar(g0, "nariz_52", 0.4543536129201322F, 1.0F, 0.45730682866339867F);
        escalar(g0, "nariz_53", 0.4603723225444601F, 1.0F, 0.3854301443177638F);
        escalar(g0, "nariz_54", 0.42562651611687646F, 1.0F, 0.3842987481297932F);
        escalar(g0, "nariz_55", 0.45392219199484646F, 1.0F, 0.47446744315377637F);
        escalar(g0, "nariz_56", 0.40567753363893566F, 1.0F, 0.4484721922715771F);
        escalar(g0, "nariz_57", 0.49400063058278043F, 1.0F, 0.43489014141752647F);
        escalar(g0, "nariz_58", 0.472654449485993F, 1.0F, 0.40753400911810206F);
        escalar(g0, "nariz_59", 0.4543536129201323F, 1.0F, 0.45730682866339883F);
        escalar(g0, "nariz_60", 0.4603723225444599F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_61", 0.42562651611687646F, 1.0F, 0.3842987481297932F);
        escalar(g0, "nariz_62", 0.45392219199484646F, 1.0F, 0.4744674431537765F);
        escalar(g0, "nariz_63", 0.40567753363893566F, 1.0F, 0.4484721922715759F);
        escalar(g0, "nariz_64", 0.49400063058278043F, 1.0F, 0.43489014141752547F);
        escalar(g0, "nariz_65", 0.472654449485993F, 1.0F, 0.4075340091181011F);
        escalar(g0, "nariz_66", 0.45435361292013243F, 1.0F, 0.457306828663398F);
        escalar(g0, "nariz_67", 0.4603723225444597F, 1.0F, 0.3854301443177633F);
        escalar(g0, "nariz_68", 0.42562651611687674F, 1.0F, 0.3842987481297923F);
        escalar(g0, "nariz_69", 0.4539221919948464F, 1.0F, 0.47446744315377426F);
        escalar(g0, "nariz_70", 0.40567753363893566F, 1.0F, 0.4484721922715781F);
        escalar(g0, "nariz_71", 0.4940006305827803F, 1.0F, 0.43489014141752724F);
        escalar(g0, "nariz_72", 0.47265444948599306F, 1.0F, 0.4075340091181029F);
        escalar(g0, "nariz_73", 0.4543536129201324F, 1.0F, 0.4573068286633997F);
        escalar(g0, "nariz_74", 0.4603723225444598F, 1.0F, 0.38543014431776457F);
        escalar(g0, "nariz_75", 0.4256265161168765F, 1.0F, 0.38429874812979414F);
        escalar(g0, "nariz_76", 0.45392219199484646F, 1.0F, 0.47446744315377803F);
        escalar(g0, "nariz_77", 0.40567753363893566F, 1.0F, 0.4484721922715765F);
        escalar(g0, "nariz_78", 0.4940006305827804F, 1.0F, 0.434890141417526F);
        escalar(g0, "nariz_79", 0.472654449485993F, 1.0F, 0.4075340091181016F);
        escalar(g0, "nariz_80", 0.4543536129201322F, 1.0F, 0.4573068286633988F);
        escalar(g0, "nariz_81", 0.46037232254446003F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_82", 0.4256265161168765F, 1.0F, 0.3842987481297928F);
        escalar(g0, "nariz_83", 0.45392219199484646F, 1.0F, 0.4744674431537753F);
        escalar(g0, "nariz_84", 0.40567753363893566F, 1.0F, 0.44847219227157603F);
        escalar(g0, "nariz_85", 0.4940006305827803F, 1.0F, 0.43489014141752574F);
        escalar(g0, "nariz_86", 0.47265444948599317F, 1.0F, 0.40753400911810134F);
        escalar(g0, "nariz_87", 0.45435361292013215F, 1.0F, 0.45730682866339795F);
        escalar(g0, "nariz_88", 0.46037232254446F, 1.0F, 0.3854301443177631F);
        escalar(g0, "nariz_89", 0.42562651611687663F, 1.0F, 0.38429874812979253F);
        escalar(g0, "nariz_90", 0.45392219199484646F, 1.0F, 0.4744674431537756F);
        escalar(g0, "nariz_91", 0.40567753363893566F, 1.0F, 0.4484721922715777F);
        escalar(g0, "nariz_92", 0.49400063058278026F, 1.0F, 0.4348901414175271F);
        escalar(g0, "nariz_93", 0.4726544494859931F, 1.0F, 0.40753400911810267F);
        escalar(g0, "nariz_94", 0.45435361292013227F, 1.0F, 0.4573068286633998F);
        escalar(g0, "nariz_95", 0.46037232254446003F, 1.0F, 0.3854301443177647F);
        escalar(g0, "nariz_96", 0.42562651611687674F, 1.0F, 0.38429874812979387F);
        escalar(g0, "nariz_97", 0.45392219199484646F, 1.0F, 0.4744674431537771F);
        escalar(g0, "nariz_98", 0.40567753363893566F, 1.0F, 0.4484721922715769F);
        escalar(g0, "nariz_99", 0.4940006305827804F, 1.0F, 0.43489014141752635F);
        escalar(g0, "nariz_100", 0.4726544494859931F, 1.0F, 0.407534009118102F);
        escalar(g0, "nariz_101", 0.454353612920132F, 1.0F, 0.4573068286633989F);
        escalar(g0, "nariz_102", 0.46037232254446037F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_103", 0.42562651611687674F, 1.0F, 0.3842987481297931F);
        escalar(g0, "nariz_104", 0.4539221919948464F, 1.0F, 0.47446744315377615F);
        escalar(g0, "nariz_105", 0.40567753363893566F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_106", 0.49400063058278054F, 1.0F, 0.4348901414175265F);
        escalar(g0, "nariz_107", 0.47265444948599317F, 1.0F, 0.40753400911810217F);
        escalar(g0, "nariz_108", 0.4543536129201319F, 1.0F, 0.4573068286633989F);
        escalar(g0, "nariz_109", 0.46037232254446026F, 1.0F, 0.3854301443177639F);
        escalar(g0, "nariz_110", 0.4256265161168765F, 1.0F, 0.38429874812979326F);
        escalar(g0, "nariz_111", 0.45392219199484646F, 1.0F, 0.4744674431537765F);
        escalar(g0, "nariz_112", 0.40567753363893566F, 1.0F, 0.4484721922715763F);
        escalar(g0, "nariz_113", 0.49400063058278043F, 1.0F, 0.4348901414175253F);
        escalar(g0, "nariz_114", 0.472654449485993F, 1.0F, 0.40753400911810067F);
        escalar(g0, "nariz_115", 0.4543536129201322F, 1.0F, 0.4573068286633976F);
        escalar(g0, "nariz_116", 0.4603723225444599F, 1.0F, 0.38543014431776296F);
        escalar(g0, "nariz_117", 0.42562651611687674F, 1.0F, 0.3842987481297921F);
        escalar(g0, "nariz_118", 0.45392219199484646F, 1.0F, 0.4744674431537747F);
        escalar(g0, "nariz_119", 0.40567753363893555F, 1.0F, 0.44847219227157764F);
        escalar(g0, "nariz_120", 0.4940006305827804F, 1.0F, 0.4348901414175274F);
        escalar(g0, "nariz_121", 0.472654449485993F, 1.0F, 0.40753400911810306F);
        escalar(g0, "nariz_122", 0.4543536129201321F, 1.0F, 0.4573068286633997F);
        escalar(g0, "nariz_123", 0.4603723225444599F, 1.0F, 0.3854301443177644F);
        escalar(g0, "nariz_124", 0.42562651611687674F, 1.0F, 0.38429874812979375F);
        escalar(g0, "nariz_125", 0.45392219199484646F, 1.0F, 0.4744674431537769F);
        escalar(g0, "nariz_126", 0.40567753363893566F, 1.0F, 0.4484721922715752F);
        escalar(g0, "nariz_127", 0.4940006305827803F, 1.0F, 0.43489014141752447F);
        escalar(g0, "nariz_128", 0.4726544494859931F, 1.0F, 0.4075340091181002F);
        escalar(g0, "nariz_129", 0.454353612920132F, 1.0F, 0.4573068286633972F);
        escalar(g0, "nariz_130", 0.46037232254446003F, 1.0F, 0.3854301443177625F);
        escalar(g0, "nariz_131", 0.42562651611687674F, 1.0F, 0.38429874812979187F);
        escalar(g0, "nariz_132", 0.45392219199484646F, 1.0F, 0.47446744315377426F);
        escalar(g0, "nariz_133", 0.40567753363893566F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_134", 0.4940006305827803F, 1.0F, 0.4348901414175262F);
        escalar(g0, "nariz_135", 0.4726544494859931F, 1.0F, 0.4075340091181019F);
        escalar(g0, "nariz_136", 0.4543536129201322F, 1.0F, 0.45730682866339895F);
        escalar(g0, "nariz_137", 0.46037232254446F, 1.0F, 0.38543014431776434F);
        escalar(g0, "nariz_138", 0.42562651611687663F, 1.0F, 0.3842987481297933F);
        escalar(g0, "nariz_139", 0.4539221919948464F, 1.0F, 0.4744674431537766F);
        escalar(g0, "nariz_140", 0.40567753363893566F, 1.0F, 0.44847219227157825F);
        escalar(g0, "nariz_141", 0.4940006305827803F, 1.0F, 0.43489014141752813F);
        escalar(g0, "nariz_142", 0.47265444948599306F, 1.0F, 0.407534009118104F);
        escalar(g0, "nariz_143", 0.4543536129201323F, 1.0F, 0.457306828663401F);
        escalar(g0, "nariz_144", 0.46037232254446F, 1.0F, 0.38543014431776557F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_145", 0.4256265161168765F, 1.0F, 0.38429874812979503F);
        escalar(g0, "nariz_146", 0.4539221919948464F, 1.0F, 0.4744674431537782F);
        escalar(g0, "nariz_147", 0.40567753363893566F, 1.0F, 0.4484721922715774F);
        escalar(g0, "nariz_148", 0.4940006305827804F, 1.0F, 0.43489014141752624F);
        escalar(g0, "nariz_149", 0.472654449485993F, 1.0F, 0.40753400911810145F);
        escalar(g0, "nariz_150", 0.4543536129201322F, 1.0F, 0.45730682866339867F);
        escalar(g0, "nariz_151", 0.4603723225444601F, 1.0F, 0.3854301443177638F);
        escalar(g0, "nariz_152", 0.4256265161168765F, 1.0F, 0.38429874812979264F);
        escalar(g0, "nariz_153", 0.4539221919948464F, 1.0F, 0.47446744315377465F);
        escalar(g0, "nariz_154", 0.40567753363893566F, 1.0F, 0.4484721922715771F);
        escalar(g0, "nariz_155", 0.49400063058278043F, 1.0F, 0.4348901414175267F);
        escalar(g0, "nariz_156", 0.472654449485993F, 1.0F, 0.40753400911810234F);
        escalar(g0, "nariz_157", 0.4543536129201323F, 1.0F, 0.4573068286633988F);
        escalar(g0, "nariz_158", 0.4603723225444599F, 1.0F, 0.3854301443177638F);
        escalar(g0, "nariz_159", 0.4256265161168765F, 1.0F, 0.38429874812979364F);
        escalar(g0, "nariz_160", 0.4539221919948464F, 1.0F, 0.4744674431537781F);
        escalar(g0, "nariz_161", 0.40567753363893566F, 1.0F, 0.4484721922715761F);
        escalar(g0, "nariz_162", 0.4940006305827803F, 1.0F, 0.434890141417526F);
        escalar(g0, "nariz_163", 0.47265444948599306F, 1.0F, 0.407534009118102F);
        escalar(g0, "nariz_164", 0.45435361292013254F, 1.0F, 0.45730682866339867F);
        escalar(g0, "nariz_165", 0.4603723225444599F, 1.0F, 0.3854301443177631F);
        escalar(g0, "nariz_166", 0.4256265161168765F, 1.0F, 0.3842987481297921F);
        escalar(g0, "nariz_167", 0.4539221919948463F, 1.0F, 0.4744674431537746F);
        escalar(g0, "nariz_168", 0.40567753363893566F, 1.0F, 0.44847219227157736F);
        escalar(g0, "nariz_169", 0.4940006305827802F, 1.0F, 0.43489014141752635F);
        escalar(g0, "nariz_170", 0.4726544494859932F, 1.0F, 0.4075340091181017F);
        escalar(g0, "nariz_171", 0.4543536129201323F, 1.0F, 0.45730682866339867F);
        escalar(g0, "nariz_172", 0.4603723225444603F, 1.0F, 0.38543014431776423F);
        escalar(g0, "nariz_173", 0.4256265161168761F, 1.0F, 0.38429874812979375F);
        escalar(g0, "nariz_174", 0.45392219199484646F, 1.0F, 0.4744674431537776F);
        escalar(g0, "nariz_175", 0.40567753363893566F, 1.0F, 0.44847219227157503F);
        escalar(g0, "nariz_176", 0.49400063058278043F, 1.0F, 0.4348901414175244F);
        escalar(g0, "nariz_177", 0.47265444948599283F, 1.0F, 0.4075340091181003F);
        escalar(g0, "nariz_178", 0.45435361292013254F, 1.0F, 0.4573068286633972F);
        escalar(g0, "nariz_179", 0.46037232254446003F, 1.0F, 0.38543014431776235F);
        escalar(g0, "nariz_180", 0.4256265161168761F, 1.0F, 0.3842987481297917F);
        escalar(g0, "nariz_181", 0.4539221919948467F, 1.0F, 0.474467443153774F);
        escalar(g0, "nariz_182", 0.40567753363893566F, 1.0F, 0.4484721922715768F);
        escalar(g0, "nariz_183", 0.49400063058278054F, 1.0F, 0.43489014141752624F);
        escalar(g0, "nariz_184", 0.4726544494859925F, 1.0F, 0.4075340091181019F);
        escalar(g0, "nariz_185", 0.45435361292013243F, 1.0F, 0.457306828663399F);
        escalar(g0, "nariz_186", 0.46037232254446003F, 1.0F, 0.38543014431776423F);
        escalar(g0, "nariz_187", 0.42562651611687646F, 1.0F, 0.38429874812979326F);
        escalar(g0, "nariz_188", 0.4539221919948467F, 1.0F, 0.47446744315377626F);
        escalar(g0, "nariz_189", 0.40567753363893566F, 1.0F, 0.4484721922715786F);
        escalar(g0, "nariz_190", 0.4940006305827802F, 1.0F, 0.43489014141752813F);
        escalar(g0, "nariz_191", 0.472654449485993F, 1.0F, 0.40753400911810356F);
        escalar(g0, "nariz_192", 0.454353612920132F, 1.0F, 0.45730682866340056F);
        escalar(g0, "nariz_193", 0.4603723225444604F, 1.0F, 0.38543014431776534F);
        escalar(g0, "nariz_194", 0.42562651611687674F, 1.0F, 0.38429874812979453F);
        escalar(g0, "nariz_195", 0.45392219199484646F, 1.0F, 0.4744674431537779F);
        escalar(g0, "faro_0", 0.5100083458096798F, 0.8F, 0.5100083458096798F);
        escalar(g0, "faro_1", 0.5100083458096798F, 0.8F, 0.5100083458096798F);
        escalar(g0, "faro_2", 0.5100083458096798F, 0.8F, 0.5100083458096798F);
        escalar(g0, "faro_3", 0.5100083458096798F, 0.8F, 0.5100083458096798F);
        escalar(g0, "faro_vidrio", 0.24761904761904763F, 0.15F, 0.24761904761904763F);
        escalar(g0, "faro_alto_0", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_alto_1", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_alto_2", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_alto_3", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_alto_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "campana_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "campana_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "campana_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "faldon_frente_0", 0.5014285714285714F, 1.0F, 0.4725832091980088F);
        escalar(g0, "faldon_frente_1", 0.5014285714285714F, 1.0F, 0.4725832091980088F);
        escalar(g0, "faldon_frente_2", 0.5014285714285714F, 1.0F, 0.4180558437301127F);
        escalar(g0, "faldon_frente_3", 0.5014285714285714F, 1.0F, 0.4180558437301127F);
        escalar(g0, "faldon_frente_4", 0.5014285714285714F, 1.0F, 0.41636832757375314F);
        escalar(g0, "faldon_frente_5", 0.5014285714285714F, 1.0F, 0.41636832757375314F);
        escalar(g0, "faldon_frente_6", 0.5014285714285714F, 1.0F, 0.4323707403275105F);
        escalar(g0, "faldon_frente_7", 0.5014285714285714F, 1.0F, 0.4323707403275105F);
        escalar(g0, "faldon_frente_8", 0.5014285714285714F, 1.0F, 0.4591943188551008F);
        escalar(g0, "faldon_frente_9", 0.5014285714285714F, 1.0F, 0.4591943188551008F);
        escalar(g0, "faldon_frente_10", 0.5014285714285714F, 1.0F, 0.49275464144945536F);
        escalar(g0, "faldon_frente_11", 0.5014285714285714F, 1.0F, 0.49275464144945536F);
        escalar(g0, "faldon_frente_12", 0.5014285714285714F, 1.0F, 0.4249759223378974F);
        escalar(g0, "faldon_frente_13", 0.5014285714285714F, 1.0F, 0.4249759223378974F);
        escalar(g0, "faldon_frente_14", 0.5014285714285714F, 1.0F, 0.46201071212544653F);
        escalar(g0, "faldon_frente_15", 0.5014285714285714F, 1.0F, 0.46201071212544653F);
        escalar(g0, "faldon_frente_16", 0.5014285714285714F, 1.0F, 0.45202724333917926F);
        escalar(g0, "faldon_frente_17", 0.5014285714285714F, 1.0F, 0.45202724333917926F);
        escalar(g0, "faldon_frente_18", 0.5014285714285714F, 1.0F, 0.45202724333917926F);
        escalar(g0, "faldon_frente_19", 0.5014285714285714F, 1.0F, 0.45202724333917926F);
        escalar(g0, "faldon_frente_20", 0.5014285714285714F, 1.0F, 0.4620107121254458F);
        escalar(g0, "faldon_frente_21", 0.5014285714285714F, 1.0F, 0.4620107121254458F);
        escalar(g0, "faldon_frente_22", 0.5014285714285714F, 1.0F, 0.4249759223378978F);
        escalar(g0, "faldon_frente_23", 0.5014285714285714F, 1.0F, 0.4249759223378978F);
        escalar(g0, "faldon_frente_24", 0.5014285714285714F, 1.0F, 0.4927546414494555F);
        escalar(g0, "faldon_frente_25", 0.5014285714285714F, 1.0F, 0.4927546414494555F);
        escalar(g0, "faldon_frente_26", 0.5014285714285714F, 1.0F, 0.4591943188551005F);
        escalar(g0, "faldon_frente_27", 0.5014285714285714F, 1.0F, 0.4591943188551005F);
        escalar(g0, "faldon_frente_28", 0.5014285714285714F, 1.0F, 0.4323707403275102F);
        escalar(g0, "faldon_frente_29", 0.5014285714285714F, 1.0F, 0.4323707403275102F);
        escalar(g0, "faldon_frente_30", 0.5014285714285714F, 1.0F, 0.41636832757375364F);
        escalar(g0, "faldon_frente_31", 0.5014285714285714F, 1.0F, 0.41636832757375364F);
        escalar(g0, "faldon_frente_32", 0.5014285714285714F, 1.0F, 0.4180558437301127F);
        escalar(g0, "faldon_frente_33", 0.5014285714285714F, 1.0F, 0.4180558437301127F);
        escalar(g0, "faldon_frente_34", 0.5014285714285714F, 1.0F, 0.4725832091980088F);
        escalar(g0, "faldon_frente_35", 0.5014285714285714F, 1.0F, 0.4725832091980088F);
        escalar(g0, "piloto_0", 0.466420511385623F, 1.0F, 0.4783740356599739F);
        escalar(g0, "piloto_1", 0.46642051138562274F, 1.0F, 0.42317796255329815F);
        escalar(g0, "piloto_2", 0.4911802084141336F, 1.0F, 0.42366068440450444F);
        escalar(g0, "piloto_3", 0.4911802084141329F, 1.0F, 0.3988650015701684F);
        escalar(g0, "piloto_4", 0.46683376143552247F, 1.0F, 0.5020233628102365F);
        escalar(g0, "piloto_5", 0.4668337614355226F, 1.0F, 0.41208891984302654F);
        escalar(g0, "piloto_6", 0.4904141647333626F, 1.0F, 0.5017562100073909F);
        escalar(g0, "piloto_7", 0.4904141647333626F, 1.0F, 0.44785192983900735F);
        escalar(g0, "piloto_8", 0.46379617620456054F, 1.0F, 0.422151189558699F);
        escalar(g0, "piloto_9", 0.4637961762045601F, 1.0F, 0.5015541320660339F);
        escalar(g0, "piloto_10", 0.4766358121556246F, 1.0F, 0.47072412721847756F);
        escalar(g0, "piloto_11", 0.4766358121556251F, 1.0F, 0.4639472612974177F);
        escalar(g0, "piloto_12", 0.4833076703972578F, 1.0F, 0.458037394045992F);
        escalar(g0, "piloto_13", 0.4833076703972583F, 1.0F, 0.45764150958378264F);
        escalar(g0, "piloto_14", 0.4833076703972578F, 1.0F, 0.45803739404599175F);
        escalar(g0, "piloto_15", 0.4833076703972583F, 1.0F, 0.45764150958378247F);
        escalar(g0, "piloto_16", 0.4766358121556246F, 1.0F, 0.47072412721847723F);
        escalar(g0, "piloto_17", 0.4766358121556251F, 1.0F, 0.4639472612974173F);
        escalar(g0, "piloto_18", 0.4637961762045601F, 1.0F, 0.42215118955869874F);
        escalar(g0, "piloto_19", 0.46379617620456054F, 1.0F, 0.5015541320660337F);
        escalar(g0, "piloto_20", 0.49041416473336225F, 1.0F, 0.5017562100073922F);
        escalar(g0, "piloto_21", 0.490414164733363F, 1.0F, 0.4478519298390087F);
        escalar(g0, "piloto_22", 0.46683376143552247F, 1.0F, 0.5020233628102363F);
        escalar(g0, "piloto_23", 0.4668337614355226F, 1.0F, 0.41208891984302626F);
        escalar(g0, "piloto_24", 0.4911802084141333F, 1.0F, 0.4236606844045032F);
        escalar(g0, "piloto_25", 0.49118020841413323F, 1.0F, 0.3988650015701668F);
        escalar(g0, "piloto_26", 0.46642051138562274F, 1.0F, 0.4783740356599753F);
        escalar(g0, "piloto_27", 0.466420511385623F, 1.0F, 0.4231779625533F);
        escalar(g0, "cabina_techo_0", 1.0007407407407407F, 1.0F, 0.7575297517670156F);
        escalar(g0, "cabina_techo_1", 1.0007407407407407F, 1.0F, 0.7575297517670149F);
        escalar(g0, "cabina_techo_2", 1.0007407407407407F, 1.0F, 0.757529751767016F);
        escalar(g0, "cabina_techo_3", 1.0007407407407407F, 1.0F, 0.7575297517670149F);
        escalar(g0, "cabina_techo_4", 1.0007407407407407F, 1.0F, 0.7575297517670148F);
        escalar(g0, "cabina_techo_5", 1.0007407407407407F, 1.0F, 0.7575297517670156F);
        escalar(g0, "cabina_techo_6", 1.0007407407407407F, 1.0F, 0.7575297517670146F);
        escalar(g0, "cabina_techo_7", 1.0007407407407407F, 1.0F, 0.7575297517670152F);
        escalar(g0, "cabina_techo_8", 1.0007407407407407F, 1.0F, 0.7575297517670155F);
        escalar(g0, "cabina_techo_9", 1.0007407407407407F, 1.0F, 0.7575297517670149F);
        escalar(g0, "cabina_techo_10", 1.0007407407407407F, 1.0F, 0.7575297517670161F);
        escalar(g0, "cabina_techo_11", 1.0007407407407407F, 1.0F, 0.7575297517670156F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1) {
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
    }
}
