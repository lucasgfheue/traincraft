package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "GE ES44AC" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloES44 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("es44"), "main"),
            LocomotoraMod.id("textures/entity/es44.png"),
            List.of(
                new DatosModelo.Animada("bogiefi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -81.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -81.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -81.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -62.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -62.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -62.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -81.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -81.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -81.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -62.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -62.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -62.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 45.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 45.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 45.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 64.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 64.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 64.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 83.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 83.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 83.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 45.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 45.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 45.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 64.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 64.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 64.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 83.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 83.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 83.0F, -4.5F, 1.0471975511965976F, "cuerpo")),
            ModeloES44::crearCapa,
            16.0F,
            ModeloES44::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -62.0F, 64.0F)));

    private ModeloES44() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogiefi0_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(92, 182).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-81.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi0_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi0_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi1_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(102, 182).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-62.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi1_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi1_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi2_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(112, 182).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi2_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi2_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd0_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 182).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-81.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd0_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd0_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd1_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(132, 182).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-62.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd1_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd1_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd2_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 182).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd2_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd2_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogief", CubeListBuilder.create().texOffs(0, 169).addBox(-87.0F, -9.0F, 7.0F, 50.0F, 6.0F, 1.0F).texOffs(102, 169).addBox(-87.0F, -9.0F, -8.0F, 50.0F, 6.0F, 1.0F).texOffs(152, 182).addBox(-83.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(162, 182).addBox(-83.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(172, 182).addBox(-64.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(182, 182).addBox(-64.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(192, 182).addBox(-45.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(202, 182).addBox(-45.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieti0_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(212, 182).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(45.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti0_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(45.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti0_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(45.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti1_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(222, 182).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti1_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti1_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti2_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 182).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(83.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti2_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(83.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti2_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(83.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd0_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(242, 182).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(45.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd0_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(45.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd0_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(45.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd1_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 182).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd1_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd1_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd2_0", CubeListBuilder.create().texOffs(772, 147).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(672, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 182).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(83.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd2_1", CubeListBuilder.create().texOffs(694, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(83.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd2_2", CubeListBuilder.create().texOffs(716, 182).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 147).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(83.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiet", CubeListBuilder.create().texOffs(204, 169).addBox(39.0F, -9.0F, 7.0F, 50.0F, 6.0F, 1.0F).texOffs(306, 169).addBox(39.0F, -9.0F, -8.0F, 50.0F, 6.0F, 1.0F).texOffs(272, 182).addBox(43.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(282, 182).addBox(43.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(292, 182).addBox(62.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(302, 182).addBox(62.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(312, 182).addBox(81.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(322, 182).addBox(81.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque", CubeListBuilder.create().texOffs(0, 116).addBox(-38.0F, -10.0F, -12.0F, 78.0F, 7.0F, 24.0F).texOffs(698, 116).addBox(-38.0F, -12.0F, -10.0F, 78.0F, 2.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque_cantoi_0", CubeListBuilder.create().texOffs(508, 197).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.309016994374947F, -11.951056516295154F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_1", CubeListBuilder.create().texOffs(666, 197).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.89680224666742F, -11.7600735106701F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_2", CubeListBuilder.create().texOffs(824, 197).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.39680224666742F, -11.39680224666742F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_3", CubeListBuilder.create().texOffs(0, 199).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.7600735106701F, -10.89680224666742F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_4", CubeListBuilder.create().texOffs(158, 199).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.951056516295154F, -10.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_0", CubeListBuilder.create().texOffs(316, 199).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.309016994374947F, 11.951056516295154F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_1", CubeListBuilder.create().texOffs(474, 199).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.89680224666742F, 11.7600735106701F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_2", CubeListBuilder.create().texOffs(632, 199).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.39680224666742F, 11.39680224666742F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_3", CubeListBuilder.create().texOffs(790, 199).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.7600735106701F, 10.89680224666742F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_4", CubeListBuilder.create().texOffs(0, 201).addBox(-39.0F, -1.0F, -0.5F, 78.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.951056516295154F, 10.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_tapaa", CubeListBuilder.create().texOffs(686, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 48.0F), PartPose.offset(-38.0F, -10.0F, -12.0F));
        g.addOrReplaceChild("tanque_tapab", CubeListBuilder.create().texOffs(784, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 48.0F), PartPose.offset(39.0F, -10.0F, -12.0F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(514, 64).addBox(-98.0F, -15.0F, -14.5F, 196.0F, 4.0F, 29.0F).texOffs(0, 197).addBox(-56.0F, -26.0F, 13.0F, 126.0F, 1.0F, 1.0F).texOffs(254, 197).addBox(-56.0F, -26.0F, -14.0F, 126.0F, 1.0F, 1.0F).texOffs(818, 147).addBox(-56.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(822, 147).addBox(-56.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(826, 147).addBox(-24.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(830, 147).addBox(-24.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(834, 147).addBox(8.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(838, 147).addBox(8.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(842, 147).addBox(40.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(846, 147).addBox(40.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(850, 147).addBox(69.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(854, 147).addBox(69.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pilotof", CubeListBuilder.create().texOffs(402, 64).addBox(-100.0F, -15.0F, -13.0F, 2.0F, 10.0F, 26.0F).texOffs(312, 176).addBox(-104.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("pilotot", CubeListBuilder.create().texOffs(458, 64).addBox(98.0F, -15.0F, -13.0F, 2.0F, 10.0F, 26.0F).texOffs(326, 176).addBox(100.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("nariz_0", CubeListBuilder.create().texOffs(926, 147).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.96670087666183F, -16.750000596771223F, -13.989070094960457F, -1.57635375205186F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_1", CubeListBuilder.create().texOffs(160, 160).addBox(-3.5F, -1.0F, -4.0F, 7.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.96670087666183F, -20.25000048551933F, -13.989070094960457F, -1.57635375205186F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_2", CubeListBuilder.create().texOffs(958, 147).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.96670085481419F, -23.750000307233837F, -13.989070094676723F, -1.5763537522578597F, 0.0F, -1.5707963205520714F));
        g.addOrReplaceChild("nariz_3", CubeListBuilder.create().texOffs(280, 160).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.92172824379047F, -26.349999950726986F, -13.98843798781139F, -1.5768127236903537F, -0.001061941844033373F, -1.5707899376553944F));
        g.addOrReplaceChild("nariz_4", CubeListBuilder.create().texOffs(900, 160).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-85.67583942611881F, -27.749999482805244F, -13.983760939385672F, -1.580486704289007F, -0.010892794990605742F, -1.5706907702832F));
        g.addOrReplaceChild("nariz_5", CubeListBuilder.create().texOffs(280, 176).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-85.19694537531836F, -28.849999995588387F, -13.973772151368347F, -1.5971796231417992F, -0.01619667557263243F, -1.3365490064795043F));
        g.addOrReplaceChild("nariz_6", CubeListBuilder.create().texOffs(264, 187).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.53247059848901F, -29.950000395722533F, -13.977540148532274F, -1.6145985000965861F, 0.0013030610844028635F, -1.2642742124544681F));
        g.addOrReplaceChild("nariz_7", CubeListBuilder.create().texOffs(696, 187).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.07298682198225F, -30.75000035069813F, -13.643633681245808F, -2.9394742841036F, -0.5127497461669858F, -1.1503166814381296F));
        g.addOrReplaceChild("nariz_8", CubeListBuilder.create().texOffs(504, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.44124270971338F, -16.750000596771223F, -13.880335390788364F, -1.6355697170748753F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_9", CubeListBuilder.create().texOffs(744, 160).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.44124270971338F, -20.25000048551933F, -13.880335390788364F, -1.6355697170748753F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_10", CubeListBuilder.create().texOffs(534, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.44124263791963F, -23.750000307233837F, -13.880335389075725F, -1.6355697190348424F, 0.0F, -1.5707963061648544F));
        g.addOrReplaceChild("nariz_11", CubeListBuilder.create().texOffs(588, 169).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-89.29330905984743F, -26.349999950726986F, -13.876725032915173F, -1.640903766153981F, -0.01022514195032817F, -1.4840749978064753F));
        g.addOrReplaceChild("nariz_12", CubeListBuilder.create().texOffs(172, 176).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-88.4949519017464F, -27.749999482805244F, -13.857107444930964F, -1.7178865929705782F, -0.08777956700410823F, -1.1272767320604011F));
        g.addOrReplaceChild("nariz_13", CubeListBuilder.create().texOffs(180, 187).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.04146869379353F, -28.849999995588387F, -13.834503981695777F, -1.844268776667374F, -0.14502393944970193F, -1.0549938503141147F));
        g.addOrReplaceChild("nariz_14", CubeListBuilder.create().texOffs(298, 203).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-85.28962420999673F, -29.950000395722533F, -13.887215959848255F, -2.041004895640647F, 0.05402745695323531F, -0.5253511418455988F));
        g.addOrReplaceChild("nariz_15", CubeListBuilder.create().texOffs(668, 187).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.17041964116513F, -30.75000035069813F, -12.923281604016502F, -2.969789531297465F, -1.2833004812657758F, -0.9724720965157293F));
        g.addOrReplaceChild("nariz_16", CubeListBuilder.create().texOffs(796, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.02382397452737F, -16.750000596771223F, -13.55571034446033F, -1.7787906883922773F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_17", CubeListBuilder.create().texOffs(52, 176).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.02382397452737F, -20.25000048551933F, -13.55571034446033F, -1.7787906883922773F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_18", CubeListBuilder.create().texOffs(822, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.0238238495284F, -23.750000307233837F, -13.555710341460383F, -1.7787906932388704F, 0.0F, -1.5707962893848422F));
        g.addOrReplaceChild("nariz_19", CubeListBuilder.create().texOffs(190, 176).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-91.76721882999686F, -26.349999950726986F, -13.549684118280311F, -1.7969909150379448F, -0.038962507997693706F, -1.4162196122963044F));
        g.addOrReplaceChild("nariz_20", CubeListBuilder.create().texOffs(956, 176).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.42106266642986F, -27.749999482805244F, -13.525280035577413F, -2.084369200881276F, -0.2864004550381893F, -0.9088942791926331F));
        g.addOrReplaceChild("nariz_21", CubeListBuilder.create().texOffs(636, 187).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.12775037703847F, -28.849999995588387F, -13.524505589240142F, -2.3811071517325173F, 0.013300293684714602F, -0.4285782887371143F));
        g.addOrReplaceChild("nariz_22", CubeListBuilder.create().texOffs(270, 203).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-85.68288453745117F, -29.950000395722533F, -13.697451204068908F, -2.5586806281795593F, 0.1139358755088768F, -0.41714605134350125F));
        g.addOrReplaceChild("nariz_23", CubeListBuilder.create().texOffs(528, 187).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.22088985911043F, -30.75000035069813F, -12.176424147355533F, -2.931880010758694F, -1.3743582978004019F, -0.8471383230544172F));
        g.addOrReplaceChild("nariz_24", CubeListBuilder.create().texOffs(396, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.86637747647737F, -16.750000596771223F, -12.990701478465827F, -1.985685875601917F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_25", CubeListBuilder.create().texOffs(828, 176).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.86637747647737F, -20.25000048551933F, -12.990701478465827F, -1.985685875601917F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_26", CubeListBuilder.create().texOffs(420, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.86637730854316F, -23.750000307233837F, -12.990701476531747F, -1.9856858828498243F, 0.0F, -1.5707962308325258F));
        g.addOrReplaceChild("nariz_27", CubeListBuilder.create().texOffs(992, 176).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.52360766134663F, -26.349999950726986F, -12.98716046448814F, -2.024489475341134F, -0.08016898342767789F, -1.3424704877811626F));
        g.addOrReplaceChild("nariz_28", CubeListBuilder.create().texOffs(958, 182).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.77543183296092F, -27.749999482805244F, -12.982290792066676F, -2.567499803029647F, -0.0008803783313925736F, -0.3730240062508683F));
        g.addOrReplaceChild("nariz_29", CubeListBuilder.create().texOffs(546, 187).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.91595110063861F, -28.849999995588387F, -13.027589829720753F, -2.738591803520668F, 0.029984067529698302F, -0.3616148060160104F));
        g.addOrReplaceChild("nariz_30", CubeListBuilder.create().texOffs(564, 187).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.01829727701144F, -29.950000395722533F, -13.30963194869068F, -2.89838547092525F, 0.15122755239508737F, -0.3640184463261717F));
        g.addOrReplaceChild("nariz_31", CubeListBuilder.create().texOffs(288, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.2873589182916F, -30.75000035069813F, -11.322560258026263F, -2.9040264605312984F, -1.4010663670734456F, -0.7159859454209662F));
        g.addOrReplaceChild("nariz_32", CubeListBuilder.create().texOffs(738, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.20345136147938F, -16.750000596771223F, -12.212450268333956F, -2.2288822404816195F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_33", CubeListBuilder.create().texOffs(978, 182).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.20345136147938F, -20.25000048551933F, -12.212450268333956F, -2.2288822404816195F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_34", CubeListBuilder.create().texOffs(760, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.20345116453885F, -23.750000307233837F, -12.212450268527817F, -2.228882248971423F, 0.0F, -1.5707962142574812F));
        g.addOrReplaceChild("nariz_35", CubeListBuilder.create().texOffs(194, 187).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.80301243723021F, -26.349999950726986F, -12.213125738420029F, -2.288451257566694F, -0.11151848122333713F, -1.258146533291499F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("nariz_36", CubeListBuilder.create().texOffs(998, 182).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.79343755501768F, -27.749999482805244F, -12.223829463900767F, -2.8206569823907253F, 0.005897048782094663F, -0.32934977418737793F));
        g.addOrReplaceChild("nariz_37", CubeListBuilder.create().texOffs(0, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.56921929000538F, -28.849999995588387F, -12.263707275268711F, -2.9313234765766083F, 0.017493359937285F, -0.32822252689824205F));
        g.addOrReplaceChild("nariz_38", CubeListBuilder.create().texOffs(20, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.35102189902082F, -29.950000395722533F, -12.418091319549136F, -3.053918129859898F, 0.07334683676485751F, -0.33049868088246104F));
        g.addOrReplaceChild("nariz_39", CubeListBuilder.create().texOffs(332, 182).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.37395321060205F, -30.75000035069813F, -10.121359110937219F, -2.9927931045447207F, -1.387110405801002F, -0.5892928054888089F));
        g.addOrReplaceChild("nariz_40", CubeListBuilder.create().texOffs(782, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.21273913765509F, -16.750000596771223F, -11.203075748554319F, -2.483589304460811F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_41", CubeListBuilder.create().texOffs(40, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.21273913765509F, -20.25000048551933F, -11.203075748554319F, -2.483589304460811F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_42", CubeListBuilder.create().texOffs(804, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.21273892271907F, -23.750000307233837F, -11.203075748500172F, -2.4835893129501634F, 0.0F, -1.5707962039743535F));
        g.addOrReplaceChild("nariz_43", CubeListBuilder.create().texOffs(208, 187).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.77644797350199F, -26.349999950726986F, -11.20249222734349F, -2.5518732287774903F, -0.11545679367455795F, -1.173107684395147F));
        g.addOrReplaceChild("nariz_44", CubeListBuilder.create().texOffs(826, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.60071525709594F, -27.749999482805244F, -11.184357838753561F, -2.9639483458092677F, -0.009620179261182298F, -0.306246306760549F));
        g.addOrReplaceChild("nariz_45", CubeListBuilder.create().texOffs(444, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.12786143855422F, -28.849999995588387F, -11.094823902967597F, -3.0340537347138756F, -0.03956146567580336F, -0.3072458090061979F));
        g.addOrReplaceChild("nariz_46", CubeListBuilder.create().texOffs(468, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.64202307752026F, -29.950000395722533F, -10.861076104141492F, -3.1016070495118133F, -0.10762613602840353F, -0.3049092663835669F));
        g.addOrReplaceChild("nariz_47", CubeListBuilder.create().texOffs(340, 176).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.44479827645152F, -30.75000035069813F, -8.499748170173454F, -3.0872409447294307F, -1.34285436302054F, -0.5120488840651303F));
        g.addOrReplaceChild("nariz_48", CubeListBuilder.create().texOffs(492, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.99092170042553F, -16.750000596771223F, -9.86587005557055F, -2.726778025525283F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_49", CubeListBuilder.create().texOffs(850, 176).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.99092170042553F, -20.25000048551933F, -9.86587005557055F, -2.726778025525283F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_50", CubeListBuilder.create().texOffs(516, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.99092147393344F, -23.750000307233837F, -9.865870050021861F, -2.7267780327719136F, 0.0F, -1.570796197370884F));
        g.addOrReplaceChild("nariz_51", CubeListBuilder.create().texOffs(1008, 176).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.53122650634953F, -26.349999950726986F, -9.852834369811818F, -2.7850370500596475F, -0.09483489858940651F, -1.105287249666334F));
        g.addOrReplaceChild("nariz_52", CubeListBuilder.create().texOffs(540, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.23747265975545F, -27.749999482805244F, -9.739386067320728F, -3.0491558139141626F, -0.05239360358647146F, -0.29134808667985496F));
        g.addOrReplaceChild("nariz_53", CubeListBuilder.create().texOffs(564, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.56336321764783F, -28.849999995588387F, -9.412732725797058F, -3.0892222553106654F, -0.14620120909744827F, -0.2919789826786157F));
        g.addOrReplaceChild("nariz_54", CubeListBuilder.create().texOffs(848, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-86.84170496226542F, -29.950000395722533F, -8.817138742467366F, -3.1228682486972916F, -0.1252591412955713F, -0.2832196453792281F));
        g.addOrReplaceChild("nariz_55", CubeListBuilder.create().texOffs(588, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.48004852174421F, -30.75000035069813F, -6.6741051364283015F, -3.135283392143724F, -0.6423727352829846F, -0.4673575460420917F));
        g.addOrReplaceChild("nariz_56", CubeListBuilder.create().texOffs(874, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.5558569886106F, -16.750000596771223F, -8.023115214745115F, -2.9336569336539164F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_57", CubeListBuilder.create().texOffs(76, 176).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.5558569886106F, -20.25000048551933F, -8.023115214745115F, -2.9336569336539164F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_58", CubeListBuilder.create().texOffs(900, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.55585675325008F, -23.750000307233837F, -8.023115198663643F, -2.933656938498801F, 0.0F, -1.5707961942409687F));
        g.addOrReplaceChild("nariz_59", CubeListBuilder.create().texOffs(208, 176).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.07782812726106F, -26.349999950726986F, -7.987709725485634F, -2.968725284030313F, -0.06624181116326654F, -1.063725182792271F));
        g.addOrReplaceChild("nariz_60", CubeListBuilder.create().texOffs(628, 169).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-94.68505645605802F, -27.749999482805244F, -7.745869158152104F, -3.1007472061724175F, -0.12276136166768264F, -0.28051568520823483F));
        g.addOrReplaceChild("nariz_61", CubeListBuilder.create().texOffs(656, 169).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-90.83974003755681F, -28.849999995588387F, -7.2096470171070655F, -3.1203081653086446F, -0.11892095727750158F, -0.2765900008129866F));
        g.addOrReplaceChild("nariz_62", CubeListBuilder.create().texOffs(684, 169).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-86.948957976437F, -29.950000395722533F, -6.479463938187459F, -3.1343785921806018F, -0.10993868662063012F, -0.2729300601277941F));
        g.addOrReplaceChild("nariz_63", CubeListBuilder.create().texOffs(916, 176).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.49437452662191F, -30.75000035069813F, -4.790176745662674F, -3.1394618660254063F, -0.584201553389754F, -0.4652282268704882F));
        g.addOrReplaceChild("nariz_64", CubeListBuilder.create().texOffs(564, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.88040130672745F, -16.750000596771223F, -5.440255089568738F, -3.0768527089644238F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_65", CubeListBuilder.create().texOffs(772, 160).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.88040130672745F, -20.25000048551933F, -5.440255089568738F, -3.0768527089644238F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_66", CubeListBuilder.create().texOffs(594, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.88040106437336F, -23.750000307233837F, -5.440255065701882F, -3.076852710923008F, 0.0F, -1.5707961881564716F));
        g.addOrReplaceChild("nariz_67", CubeListBuilder.create().texOffs(856, 160).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.38800604168375F, -26.349999950726986F, -5.389607788305201F, -3.0889780929019883F, -0.041045675207628037F, -1.0451930600579284F));
        g.addOrReplaceChild("nariz_68", CubeListBuilder.create().texOffs(376, 160).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-94.92191630515651F, -27.749999482805244F, -5.095728957588139F, -3.129932540809565F, -0.08003232089312813F, -0.2713230520509532F));
        g.addOrReplaceChild("nariz_69", CubeListBuilder.create().texOffs(408, 169).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-90.96529600810385F, -28.849999995588387F, -4.554365926494699F, -3.136015852346166F, -0.08198838786692834F, -0.27021788032485033F));
        g.addOrReplaceChild("nariz_70", CubeListBuilder.create().texOffs(438, 169).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-86.99019981138505F, -29.950000395722533F, -3.959931295732361F, -3.1398297443508993F, -0.07438692818411771F, -0.2692497956393621F));
        g.addOrReplaceChild("nariz_71", CubeListBuilder.create().texOffs(0, 182).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.49901447776362F, -30.75000035069813F, -2.886675546219654F, -3.1411346614039366F, -0.4743326686194931F, -0.46407873428948304F));
        g.addOrReplaceChild("nariz_72", CubeListBuilder.create().texOffs(990, 147).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.98908285258935F, -16.750000596771223F, -1.9661270077035828F, -3.136040100816109F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_73", CubeListBuilder.create().texOffs(190, 160).addBox(-3.5F, -1.0F, -4.0F, 7.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.98908285258935F, -20.25000048551933F, -1.9661270077035828F, -3.136040100816109F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_74", CubeListBuilder.create().texOffs(0, 160).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.98908260689647F, -23.750000307233837F, -1.9661273705681166F, -3.1360400999611917F, 1.0328897625965039e-07F, -1.5707961869768337F));
        g.addOrReplaceChild("nariz_75", CubeListBuilder.create().texOffs(304, 160).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.48999919876626F, -26.349999950726986F, -1.939602421665458F, -3.137146178858666F, -0.014757554409841262F, -1.0398195038961187F));
        g.addOrReplaceChild("nariz_76", CubeListBuilder.create().texOffs(858, 147).addBox(-4.5F, -1.0F, -4.0F, 9.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.9935733490387F, -27.749999482805244F, -1.7983599941910196F, -3.1406436179350163F, -0.02938149326561729F, -0.2686818680435784F));
        g.addOrReplaceChild("nariz_77", CubeListBuilder.create().texOffs(408, 160).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-90.99755297820393F, -28.849999995588387F, -1.5625184478401635F, -3.1411769910324328F, -0.029936967285190772F, -0.2685235594278373F));
        g.addOrReplaceChild("nariz_78", CubeListBuilder.create().texOffs(468, 169).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-86.99937917404559F, -29.950000395722533F, -1.332765504082876F, -3.141469102290643F, -0.026391776510336407F, -0.26842757106246234F));
        g.addOrReplaceChild("nariz_79", CubeListBuilder.create().texOffs(64, 182).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.49994152671589F, -30.75000035069813F, -0.9664318420675465F, -3.1415649494361264F, -0.21602554536923638F, -0.4636872933585983F));
        g.addOrReplaceChild("nariz_80", CubeListBuilder.create().texOffs(32, 160).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.98908285258929F, -16.750000596771223F, 1.9661290329795873F, 3.136040095096619F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_81", CubeListBuilder.create().texOffs(220, 160).addBox(-3.5F, -1.0F, -4.0F, 7.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.98908285258929F, -20.25000048551933F, 1.9661290329795873F, 3.136040095096619F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_82", CubeListBuilder.create().texOffs(64, 160).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.98908260689645F, -23.750000307233837F, 1.9661286446679245F, 3.1360400963630646F, 1.1133934625761696e-07F, -1.5707961857851713F));
        g.addOrReplaceChild("nariz_83", CubeListBuilder.create().texOffs(328, 160).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.48999919876626F, -26.349999950726986F, 1.9396026831272088F, 3.1371461782536927F, 0.014757687121514039F, -1.0398195032997015F));
        g.addOrReplaceChild("nariz_84", CubeListBuilder.create().texOffs(892, 147).addBox(-4.5F, -1.0F, -4.0F, 9.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.9935733490387F, -27.749999482805244F, 1.7983604655481376F, 3.1406436176887245F, 0.02938138030302681F, -0.26868186814568235F));
        g.addOrReplaceChild("nariz_85", CubeListBuilder.create().texOffs(440, 160).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-90.99755297820394F, -28.849999995588387F, 1.562519425516188F, 3.141176990772461F, 0.02993695935353781F, -0.26852355942414186F));
        g.addOrReplaceChild("nariz_86", CubeListBuilder.create().texOffs(498, 169).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-86.99937917404557F, -29.950000395722533F, 1.3327640148750093F, 3.1414691024267984F, 0.02639237782332011F, -0.26842757099136505F));
        g.addOrReplaceChild("nariz_87", CubeListBuilder.create().texOffs(78, 182).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.49994152671589F, -30.75000035069813F, 0.9664298465408214F, 3.1415649495022744F, 0.21602407319977138F, -0.4636872934269458F));
        g.addOrReplaceChild("nariz_88", CubeListBuilder.create().texOffs(624, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.8804013067273F, -16.750000596771223F, 5.440255089571916F, 3.0768527089643207F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_89", CubeListBuilder.create().texOffs(800, 160).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.8804013067273F, -20.25000048551933F, 5.440255089571916F, 3.0768527089643207F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_90", CubeListBuilder.create().texOffs(654, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.88040106437329F, -23.750000307233837F, 5.4402550657034805F, 3.076852710922958F, 0.0F, -1.5707961881564911F));
        g.addOrReplaceChild("nariz_91", CubeListBuilder.create().texOffs(878, 160).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.3880060416837F, -26.349999950726986F, 5.389607788305589F, 3.0889780929019794F, 0.04104567520744339F, -1.0451930600578883F));
        g.addOrReplaceChild("nariz_92", CubeListBuilder.create().texOffs(472, 160).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-94.92191630515647F, -27.749999482805244F, 5.095728957588892F, 3.1299325408095573F, 0.0800323208931438F, -0.2713230520509591F));
        g.addOrReplaceChild("nariz_93", CubeListBuilder.create().texOffs(528, 169).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-90.96529600810383F, -28.849999995588387F, 4.55436592649551F, 3.1360158523461634F, 0.08198838786691835F, -0.2702178803248508F));
        g.addOrReplaceChild("nariz_94", CubeListBuilder.create().texOffs(558, 169).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-86.99019981138505F, -29.950000395722533F, 3.959931295721939F, 3.1398297443509047F, 0.07438692818678576F, -0.2692497956393589F));
        g.addOrReplaceChild("nariz_95", CubeListBuilder.create().texOffs(16, 182).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.49901447776364F, -30.75000035069813F, 2.886675546208785F, 3.1411346614039446F, 0.47433266861617485F, -0.46407873428948615F));
        g.addOrReplaceChild("nariz_96", CubeListBuilder.create().texOffs(926, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.55585698861037F, -16.750000596771223F, 8.023115214746348F, 2.9336569336538196F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_97", CubeListBuilder.create().texOffs(100, 176).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.55585698861037F, -20.25000048551933F, 8.023115214746348F, 2.9336569336538196F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_98", CubeListBuilder.create().texOffs(952, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.55585675325003F, -23.750000307233837F, 8.023115198664007F, 2.9336569384987783F, 0.0F, -1.57079619424102F));
        g.addOrReplaceChild("nariz_99", CubeListBuilder.create().texOffs(226, 176).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-97.07782812726101F, -26.349999950726986F, 7.98770972548607F, 2.9687252840302945F, 0.06624181116279054F, -1.0637251827921883F));
        g.addOrReplaceChild("nariz_100", CubeListBuilder.create().texOffs(712, 169).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-94.68505645605785F, -27.749999482805244F, 7.745869158153056F, 3.1007472061724037F, 0.1227613616678123F, -0.28051568520824266F));
        g.addOrReplaceChild("nariz_101", CubeListBuilder.create().texOffs(740, 169).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-90.83974003755678F, -28.849999995588387F, 7.209647017107079F, 3.120308165308639F, 0.11892095727763843F, -0.27659000081299295F));
        g.addOrReplaceChild("nariz_102", CubeListBuilder.create().texOffs(768, 169).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-86.94895797643706F, -29.950000395722533F, 6.479463938181128F, 3.1343785921806187F, 0.10993868662197692F, -0.2729300601277867F));
        g.addOrReplaceChild("nariz_103", CubeListBuilder.create().texOffs(936, 176).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.49437452662195F, -30.75000035069813F, 4.790176745656585F, 3.13946186602542F, 0.584201553388879F, -0.46522822687049376F));
        g.addOrReplaceChild("nariz_104", CubeListBuilder.create().texOffs(612, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.99092170042525F, -16.750000596771223F, 9.865870055571225F, 2.726778025525183F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_105", CubeListBuilder.create().texOffs(872, 176).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.99092170042525F, -20.25000048551933F, 9.865870055571225F, 2.726778025525183F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_106", CubeListBuilder.create().texOffs(636, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.99092147393345F, -23.750000307233837F, 9.865870050021869F, 2.726778032771908F, 0.0F, -1.5707961973710525F));
        g.addOrReplaceChild("nariz_107", CubeListBuilder.create().texOffs(32, 182).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.53122650634954F, -26.349999950726986F, 9.852834369811866F, 2.785037050059653F, 0.09483489858903951F, -1.1052872496662018F));
        g.addOrReplaceChild("nariz_108", CubeListBuilder.create().texOffs(660, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.2374726597552F, -27.749999482805244F, 9.73938606732155F, 3.049155813914132F, 0.052393603586438534F, -0.29134808667985973F));
        g.addOrReplaceChild("nariz_109", CubeListBuilder.create().texOffs(684, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.56336321764776F, -28.849999995588387F, 9.412732725797117F, 3.08922225531066F, 0.1462012090976719F, -0.29197898267862815F));
        g.addOrReplaceChild("nariz_110", CubeListBuilder.create().texOffs(978, 169).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-86.84170496226555F, -29.950000395722533F, 8.817138742463614F, 3.1228682486973103F, 0.12525914129627266F, -0.2832196453792164F));
        g.addOrReplaceChild("nariz_111", CubeListBuilder.create().texOffs(708, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.48004852174427F, -30.75000035069813F, 6.674105136424927F, 3.1352833921437373F, 0.6423727352826971F, -0.46735754604209445F));
        g.addOrReplaceChild("nariz_112", CubeListBuilder.create().texOffs(848, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.2127391376547F, -16.750000596771223F, 11.203075748554836F, 2.4835893044606983F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_113", CubeListBuilder.create().texOffs(60, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.2127391376547F, -20.25000048551933F, 11.203075748554836F, 2.4835893044606983F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_114", CubeListBuilder.create().texOffs(870, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.21273892271908F, -23.750000307233837F, 11.203075748500154F, 2.4835893129501705F, 0.0F, -1.5707962039745869F));
        g.addOrReplaceChild("nariz_115", CubeListBuilder.create().texOffs(222, 187).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.77644797350204F, -26.349999950726986F, 11.20249222734342F, 2.5518732287775268F, 0.11545679367430031F, -1.1731076843949828F));
        g.addOrReplaceChild("nariz_116", CubeListBuilder.create().texOffs(892, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.60071525709563F, -27.749999482805244F, 11.184357838754089F, 2.963948345809225F, 0.009620179261120368F, -0.30624630676054543F));
        g.addOrReplaceChild("nariz_117", CubeListBuilder.create().texOffs(732, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.1278614385541F, -28.849999995588387F, 11.094823902967756F, 3.0340537347138645F, 0.039561465676072674F, -0.30724580900623044F));
        g.addOrReplaceChild("nariz_118", CubeListBuilder.create().texOffs(756, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.64202307752032F, -29.950000395722533F, 10.8610761041402F, 3.1016070495118595F, 0.10762613602859374F, -0.3049092663835516F));
        g.addOrReplaceChild("nariz_119", CubeListBuilder.create().texOffs(368, 176).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.44479827645155F, -30.75000035069813F, 8.499748170172312F, 3.087240944729445F, 1.3428543630204188F, -0.5120488840651063F));
        g.addOrReplaceChild("nariz_120", CubeListBuilder.create().texOffs(914, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.20345136147895F, -16.750000596771223F, 12.212450268334297F, 2.2288822404815174F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_121", CubeListBuilder.create().texOffs(80, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.20345136147895F, -20.25000048551933F, 12.212450268334297F, 2.2288822404815174F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_122", CubeListBuilder.create().texOffs(936, 182).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.2034511645389F, -23.750000307233837F, 12.212450268527787F, 2.2288822489714275F, 0.0F, -1.570796214257747F));
        g.addOrReplaceChild("nariz_123", CubeListBuilder.create().texOffs(236, 187).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.80301243723038F, -26.349999950726986F, 12.213125738419928F, 2.288451257566741F, 0.11151848122317835F, -1.2581465332913182F));
        g.addOrReplaceChild("nariz_124", CubeListBuilder.create().texOffs(100, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.79343755501742F, -27.749999482805244F, 12.223829463901064F, 2.820656982390667F, -0.005897048782151427F, -0.32934977418736844F));
        g.addOrReplaceChild("nariz_125", CubeListBuilder.create().texOffs(120, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.56921929000524F, -28.849999995588387F, 12.263707275268887F, 2.9313234765766008F, -0.01749335993716129F, -0.3282225268982703F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("nariz_126", CubeListBuilder.create().texOffs(140, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.35102189902082F, -29.950000395722533F, 12.418091319549239F, 3.0539181298598788F, -0.0733468367649392F, -0.3304986808824603F));
        g.addOrReplaceChild("nariz_127", CubeListBuilder.create().texOffs(358, 182).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.37395321060204F, -30.75000035069813F, 10.121359110937329F, 2.9927931045447314F, 1.3871104058010129F, -0.5892928054888134F));
        g.addOrReplaceChild("nariz_128", CubeListBuilder.create().texOffs(780, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.86637747647693F, -16.750000596771223F, 12.990701478466002F, 1.9856858756018598F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_129", CubeListBuilder.create().texOffs(894, 176).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.86637747647693F, -20.25000048551933F, 12.990701478466002F, 1.9856858756018598F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_130", CubeListBuilder.create().texOffs(804, 176).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.86637730854342F, -23.750000307233837F, 12.990701476531642F, 1.9856858828498645F, 0.0F, -1.5707962308329175F));
        g.addOrReplaceChild("nariz_131", CubeListBuilder.create().texOffs(48, 182).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.52360766134701F, -26.349999950726986F, 12.987160464487983F, 2.024489475341225F, 0.08016898342757334F, -1.3424704877808653F));
        g.addOrReplaceChild("nariz_132", CubeListBuilder.create().texOffs(160, 187).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.77543183296069F, -27.749999482805244F, 12.9822907920668F, 2.5674998030295813F, 0.0008803783313590054F, -0.373024006250858F));
        g.addOrReplaceChild("nariz_133", CubeListBuilder.create().texOffs(582, 187).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.9159511006385F, -28.849999995588387F, 13.02758982972083F, 2.738591803520624F, -0.02998406752963779F, -0.36161480601604273F));
        g.addOrReplaceChild("nariz_134", CubeListBuilder.create().texOffs(600, 187).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.01829727701147F, -29.950000395722533F, 13.309631948690647F, 2.8983854709252808F, -0.15122755239507912F, -0.3640184463261701F));
        g.addOrReplaceChild("nariz_135", CubeListBuilder.create().texOffs(312, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.2873589182916F, -30.75000035069813F, 11.32256025802623F, 2.904026460531286F, 1.4010663670734416F, -0.7159859454209538F));
        g.addOrReplaceChild("nariz_136", CubeListBuilder.create().texOffs(0, 176).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.02382397452666F, -16.750000596771223F, 13.555710344460476F, 1.7787906883922175F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_137", CubeListBuilder.create().texOffs(124, 176).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.02382397452666F, -20.25000048551933F, 13.555710344460476F, 1.7787906883922175F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_138", CubeListBuilder.create().texOffs(26, 176).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-92.02382384952858F, -23.750000307233837F, 13.55571034146033F, 1.778790693238887F, 0.0F, -1.5707962893850984F));
        g.addOrReplaceChild("nariz_139", CubeListBuilder.create().texOffs(244, 176).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-91.76721882999725F, -26.349999950726986F, 13.549684118280215F, 1.7969909150379941F, 0.038962507997602966F, -1.4162196122959367F));
        g.addOrReplaceChild("nariz_140", CubeListBuilder.create().texOffs(974, 176).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.42106266642952F, -27.749999482805244F, 13.525280035577513F, 2.0843692008811896F, 0.2864004550381334F, -0.9088942791926616F));
        g.addOrReplaceChild("nariz_141", CubeListBuilder.create().texOffs(652, 187).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.12775037703832F, -28.849999995588387F, 13.52450558924018F, 2.3811071517324667F, -0.013300293684642936F, -0.4285782887371879F));
        g.addOrReplaceChild("nariz_142", CubeListBuilder.create().texOffs(284, 203).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-85.68288453745123F, -29.950000395722533F, 13.69745120406888F, 2.558680628179614F, -0.11393587550889567F, -0.41714605134348537F));
        g.addOrReplaceChild("nariz_143", CubeListBuilder.create().texOffs(618, 187).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.22088985911043F, -30.75000035069813F, 12.176424147355528F, 2.9318800107586687F, 1.374358297800404F, -0.8471383230544252F));
        g.addOrReplaceChild("nariz_144", CubeListBuilder.create().texOffs(684, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.44124270971294F, -16.750000596771223F, 13.880335390788423F, 1.6355697170748562F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_145", CubeListBuilder.create().texOffs(828, 160).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.44124270971294F, -20.25000048551933F, 13.880335390788423F, 1.6355697170748562F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_146", CubeListBuilder.create().texOffs(714, 160).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.44124263791964F, -23.750000307233837F, 13.880335389075727F, 1.6355697190348422F, 0.0F, -1.570796306164982F));
        g.addOrReplaceChild("nariz_147", CubeListBuilder.create().texOffs(608, 169).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-89.29330905984757F, -26.349999950726986F, 13.876725032915157F, 1.6409037661539854F, 0.010225141950293878F, -1.4840749978062995F));
        g.addOrReplaceChild("nariz_148", CubeListBuilder.create().texOffs(262, 176).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-88.4949519017462F, -27.749999482805244F, 13.857107444931003F, 1.7178865929705451F, 0.08777956700407662F, -1.1272767320603976F));
        g.addOrReplaceChild("nariz_149", CubeListBuilder.create().texOffs(250, 187).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.04146869379349F, -28.849999995588387F, 13.834503981695786F, 1.844268776667379F, 0.14502393944973646F, -1.0549938503141614F));
        g.addOrReplaceChild("nariz_150", CubeListBuilder.create().texOffs(310, 203).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-85.2896242099968F, -29.950000395722533F, 13.887215959848241F, 2.041004895640708F, -0.0540274569532494F, -0.5253511418455679F));
        g.addOrReplaceChild("nariz_151", CubeListBuilder.create().texOffs(682, 187).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.17041964116511F, -30.75000035069813F, 12.9232816040165F, 2.9697895312974842F, 1.283300481265779F, -0.9724720965157391F));
        g.addOrReplaceChild("nariz_152", CubeListBuilder.create().texOffs(96, 160).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.96670087666183F, -16.750000596771223F, 13.989070094960457F, 1.57635375205186F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_153", CubeListBuilder.create().texOffs(250, 160).addBox(-3.5F, -1.0F, -4.0F, 7.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.96670087666183F, -20.25000048551933F, 13.989070094960457F, 1.57635375205186F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("nariz_154", CubeListBuilder.create().texOffs(128, 160).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.96670085481419F, -23.750000307233837F, 13.989070094676723F, 1.5763537522578597F, 0.0F, -1.5707963205520714F));
        g.addOrReplaceChild("nariz_155", CubeListBuilder.create().texOffs(352, 160).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-85.92172824379047F, -26.349999950726986F, 13.98843798781139F, 1.5768127236903537F, 0.0010619418440333988F, -1.5707899376553944F));
        g.addOrReplaceChild("nariz_156", CubeListBuilder.create().texOffs(920, 160).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-85.6758394261188F, -27.749999482805244F, 13.983760939385672F, 1.580486704289007F, 0.010892794990605687F, -1.5706907702832F));
        g.addOrReplaceChild("nariz_157", CubeListBuilder.create().texOffs(296, 176).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-85.19694537531839F, -28.849999995588387F, 13.973772151368344F, 1.5971796231418043F, 0.016196675572641258F, -1.33654900647953F));
        g.addOrReplaceChild("nariz_158", CubeListBuilder.create().texOffs(276, 187).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.53247059848904F, -29.950000395722533F, 13.97754014853227F, 1.6145985000965917F, -0.0013030610844073358F, -1.2642742124544466F));
        g.addOrReplaceChild("nariz_159", CubeListBuilder.create().texOffs(704, 187).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.07298682198225F, -30.75000035069813F, 13.643633681245808F, 2.9394742841036003F, 0.5127497461669863F, -1.1503166814381294F));
        g.addOrReplaceChild("faroi_0", CubeListBuilder.create().texOffs(384, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(72, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, -6.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faroi_1", CubeListBuilder.create().texOffs(408, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(96, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, -6.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faroi_2", CubeListBuilder.create().texOffs(432, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(120, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, -6.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faroi_3", CubeListBuilder.create().texOffs(456, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(144, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, -6.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faroi_vidrio", CubeListBuilder.create().texOffs(460, 147).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-98.92F, -21.0F, -6.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farod_0", CubeListBuilder.create().texOffs(480, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(168, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, 6.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farod_1", CubeListBuilder.create().texOffs(504, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(192, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, 6.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farod_2", CubeListBuilder.create().texOffs(528, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(216, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, 6.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farod_3", CubeListBuilder.create().texOffs(552, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(240, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.3F, -21.0F, 6.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farod_vidrio", CubeListBuilder.create().texOffs(500, 147).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-98.92F, -21.0F, 6.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(578, 0).addBox(-84.0F, -40.0F, -14.0F, 26.0F, 25.0F, 28.0F).texOffs(306, 116).addBox(-84.0F, -43.0F, -11.0F, 26.0F, 3.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_cantoi_0", CubeListBuilder.create().texOffs(738, 201).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -40.46352549156242F, -13.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_1", CubeListBuilder.create().texOffs(792, 201).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -41.34520337000113F, -13.640110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_2", CubeListBuilder.create().texOffs(846, 201).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -42.09520337000113F, -13.09520337000113F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_3", CubeListBuilder.create().texOffs(900, 201).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -42.64011026600515F, -12.345203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_4", CubeListBuilder.create().texOffs(954, 201).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -42.92658477444273F, -11.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_0", CubeListBuilder.create().texOffs(0, 203).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -40.46352549156242F, 13.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_1", CubeListBuilder.create().texOffs(54, 203).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -41.34520337000113F, 13.640110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_2", CubeListBuilder.create().texOffs(108, 203).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -42.09520337000113F, 13.09520337000113F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_3", CubeListBuilder.create().texOffs(162, 203).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -42.64011026600515F, 12.345203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_4", CubeListBuilder.create().texOffs(216, 203).addBox(-13.0F, -1.0F, -0.5F, 26.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-71.0F, -42.92658477444273F, 11.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_tapaa", CubeListBuilder.create().texOffs(236, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 56.0F), PartPose.offset(-84.0F, -40.0F, -14.0F));
        g.addOrReplaceChild("cabina_tapab", CubeListBuilder.create().texOffs(350, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 56.0F), PartPose.offset(-59.0F, -40.0F, -14.0F));
        g.addOrReplaceChild("capo", CubeListBuilder.create().texOffs(98, 64).addBox(-58.0F, -38.0F, -12.0F, 128.0F, 23.0F, 24.0F).texOffs(402, 116).addBox(-58.0F, -40.0F, -10.0F, 128.0F, 2.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(712, 187).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -38.30901699437494F, -11.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(0, 191).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -38.89680224666742F, -11.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(258, 191).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -39.39680224666742F, -11.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(516, 191).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -39.7600735106701F, -10.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(0, 193).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -39.951056516295154F, -10.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(258, 193).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -38.30901699437494F, 11.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(516, 193).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -38.89680224666742F, 11.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(0, 195).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -39.39680224666742F, 11.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(258, 195).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -39.7600735106701F, 10.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(516, 195).addBox(-64.0F, -1.0F, -0.5F, 128.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.0F, -39.951056516295154F, 10.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(882, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 48.0F), PartPose.offset(-58.0F, -38.0F, -12.0F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(0, 64).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 48.0F), PartPose.offset(69.0F, -38.0F, -12.0F));
        g.addOrReplaceChild("radiador", CubeListBuilder.create().texOffs(464, 0).addBox(70.0F, -39.0F, -14.5F, 28.0F, 24.0F, 29.0F).texOffs(204, 116).addBox(70.0F, -42.0F, -11.5F, 28.0F, 3.0F, 23.0F).texOffs(360, 147).addBox(72.0F, -37.0F, 14.5F, 24.0F, 10.0F, 1.0F).texOffs(410, 147).addBox(72.0F, -37.0F, -15.5F, 24.0F, 10.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("radiador_cantoi_0", CubeListBuilder.create().texOffs(158, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -39.46352549156242F, -14.42658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_1", CubeListBuilder.create().texOffs(216, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -40.34520337000113F, -14.140110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_2", CubeListBuilder.create().texOffs(274, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -41.09520337000113F, -13.59520337000113F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_3", CubeListBuilder.create().texOffs(332, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -41.64011026600515F, -12.845203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_4", CubeListBuilder.create().texOffs(390, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -41.92658477444273F, -11.963525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_0", CubeListBuilder.create().texOffs(448, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -39.46352549156242F, 14.42658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_1", CubeListBuilder.create().texOffs(506, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -40.34520337000113F, 14.140110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_2", CubeListBuilder.create().texOffs(564, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -41.09520337000113F, 13.59520337000113F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_3", CubeListBuilder.create().texOffs(622, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -41.64011026600515F, 12.845203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_4", CubeListBuilder.create().texOffs(680, 201).addBox(-14.0F, -1.0F, -0.5F, 28.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(84.0F, -41.92658477444273F, 11.963525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 58.0F), PartPose.offset(70.0F, -39.0F, -14.5F));
        g.addOrReplaceChild("radiador_tapab", CubeListBuilder.create().texOffs(118, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 58.0F), PartPose.offset(97.0F, -39.0F, -14.5F));
        g.addOrReplaceChild("ventilador78_0", CubeListBuilder.create().texOffs(336, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(580, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(78.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador78_1", CubeListBuilder.create().texOffs(360, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(604, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(78.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador78_2", CubeListBuilder.create().texOffs(384, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(628, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(78.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador78_3", CubeListBuilder.create().texOffs(408, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(652, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(78.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador90_0", CubeListBuilder.create().texOffs(432, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(676, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(90.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador90_1", CubeListBuilder.create().texOffs(456, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(700, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(90.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador90_2", CubeListBuilder.create().texOffs(480, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(724, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(90.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("ventilador90_3", CubeListBuilder.create().texOffs(504, 187).addBox(-5.0F, -43.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(748, 147).addBox(-1.0F, -43.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(90.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("escape", CubeListBuilder.create().texOffs(148, 176).addBox(-20.0F, -42.0F, -2.0F, 8.0F, 2.0F, 4.0F).texOffs(0, 147).addBox(20.0F, -41.0F, -6.0F, 24.0F, 1.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(958, 116).addBox(-66.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(894, 116).addBox(-66.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -44.5F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(976, 116).addBox(-66.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(926, 116).addBox(-66.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -44.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(576, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(264, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(98.4F, -33.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(600, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(288, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(98.4F, -33.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(624, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(312, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(98.4F, -33.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(648, 182).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(336, 147).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(98.4F, -33.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(540, 147).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(99.02000000000001F, -33.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tanque_cantoi_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantoi_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantoi_2", 1.0F, 1.0F, 0.6257378601609229F);
        escalar(g0, "tanque_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantod_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantod_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantod_2", 1.0F, 1.0F, 0.6257378601609229F);
        escalar(g0, "tanque_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "tanque_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "nariz_0", 0.4437501491928052F, 1.0F, 0.4979327845634064F);
        escalar(g0, "nariz_1", 0.5071426548505399F, 1.0F, 0.4979327845634064F);
        escalar(g0, "nariz_2", 0.4437501324344035F, 1.0F, 0.49793277910197403F);
        escalar(g0, "nariz_3", 0.4386862055384267F, 1.0F, 0.4866907827936386F);
        escalar(g0, "nariz_4", 0.42706724094942144F, 1.0F, 0.4859796810145178F);
        escalar(g0, "nariz_5", 0.46071019037072963F, 1.0F, 0.48891861650228724F);
        escalar(g0, "nariz_6", 0.5162976367600952F, 1.0F, 0.37201990316442385F);
        escalar(g0, "nariz_7", 0.5228611600775058F, 1.0F, 0.4482569278371544F);
        escalar(g0, "nariz_8", 0.4437501491928052F, 1.0F, 0.4388599280303676F);
        escalar(g0, "nariz_9", 0.5071426548505399F, 1.0F, 0.4388599280303676F);
        escalar(g0, "nariz_10", 0.44375013243440387F, 1.0F, 0.4388599200402496F);
        escalar(g0, "nariz_11", 0.4448382302936021F, 1.0F, 0.49277381423621486F);
        escalar(g0, "nariz_12", 0.44634593040239373F, 1.0F, 0.46962130983148664F);
        escalar(g0, "nariz_13", 0.5044007546784091F, 1.0F, 0.4557297600596398F);
        escalar(g0, "nariz_14", 0.45093668844875534F, 1.0F, 0.5210479576660408F);
        escalar(g0, "nariz_15", 0.4382881491488998F, 1.0F, 0.4031618671568822F);
        escalar(g0, "nariz_16", 0.4437501491928052F, 1.0F, 0.44936571001585185F);
        escalar(g0, "nariz_17", 0.5071426548505399F, 1.0F, 0.44936571001585185F);
        escalar(g0, "nariz_18", 0.4437501324344046F, 1.0F, 0.4493657002013392F);
        escalar(g0, "nariz_19", 0.45711661499058637F, 1.0F, 0.4295795902798618F);
        escalar(g0, "nariz_20", 0.4994968183047156F, 1.0F, 0.4199738695278884F);
        escalar(g0, "nariz_21", 0.45008048932388434F, 1.0F, 0.5082737781336968F);
        escalar(g0, "nariz_22", 0.4642983750578988F, 1.0F, 0.4699941766613923F);
        escalar(g0, "nariz_23", 0.49570551603932306F, 1.0F, 0.4169254102483813F);
        escalar(g0, "nariz_24", 0.4437501491928052F, 1.0F, 0.43199636776364997F);
        escalar(g0, "nariz_25", 0.5071426548505399F, 1.0F, 0.43199636776364997F);
        escalar(g0, "nariz_26", 0.4437501324344055F, 1.0F, 0.4319963593622232F);
        escalar(g0, "nariz_27", 0.4710552902214748F, 1.0F, 0.4153384503866703F);
        escalar(g0, "nariz_28", 0.4385527931801702F, 1.0F, 0.45524391997406677F);
        escalar(g0, "nariz_29", 0.45163167343169175F, 1.0F, 0.4889783924738276F);
        escalar(g0, "nariz_30", 0.4537093178271595F, 1.0F, 0.3448717113652081F);
        escalar(g0, "nariz_31", 0.4560124835489442F, 1.0F, 0.502572797148688F);
        escalar(g0, "nariz_32", 0.4437501491928052F, 1.0F, 0.496348364102649F);
        escalar(g0, "nariz_33", 0.5071426548505399F, 1.0F, 0.496348364102649F);
        escalar(g0, "nariz_34", 0.4437501324344062F, 1.0F, 0.496348357831874F);
        escalar(g0, "nariz_35", 0.4824084001872577F, 1.0F, 0.4841149178743771F);
        escalar(g0, "nariz_36", 0.49307268679799626F, 1.0F, 0.4347314283335893F);
        escalar(g0, "nariz_37", 0.49479388667290863F, 1.0F, 0.3891660798763245F);
        escalar(g0, "nariz_38", 0.49437200057492775F, 1.0F, 0.45404390247329035F);
        escalar(g0, "nariz_39", 0.4976418959980532F, 1.0F, 0.5053329883400604F);
        escalar(g0, "nariz_40", 0.4437501491928052F, 1.0F, 0.49636101544035544F);
        escalar(g0, "nariz_41", 0.5071426548505399F, 1.0F, 0.49636101544035544F);
        escalar(g0, "nariz_42", 0.4437501324344067F, 1.0F, 0.4963610132769285F);
        escalar(g0, "nariz_43", 0.49025640761320355F, 1.0F, 0.49248004788991184F);
        escalar(g0, "nariz_44", 0.46241876251787317F, 1.0F, 0.4865251263760928F);
        escalar(g0, "nariz_45", 0.46163283168641167F, 1.0F, 0.389254256385239F);
        escalar(g0, "nariz_46", 0.46865730491768787F, 1.0F, 0.4848390076636339F);
        escalar(g0, "nariz_47", 0.4567842382030355F, 1.0F, 0.458482441407464F);
        escalar(g0, "nariz_48", 0.4437501491928052F, 1.0F, 0.4320264851214134F);
        escalar(g0, "nariz_49", 0.5071426548505399F, 1.0F, 0.4320264851214134F);
        escalar(g0, "nariz_50", 0.4437501324344071F, 1.0F, 0.43202648614639855F);
        escalar(g0, "nariz_51", 0.4957573637096863F, 1.0F, 0.43452136720044393F);
        escalar(g0, "nariz_52", 0.48579009955182373F, 1.0F, 0.456661341363427F);
        escalar(g0, "nariz_53", 0.49005094006369293F, 1.0F, 0.5104486210198501F);
        escalar(g0, "nariz_54", 0.5051036199316417F, 1.0F, 0.45660163740739107F);
        escalar(g0, "nariz_55", 0.470266726587076F, 1.0F, 0.4796681830681826F);
        escalar(g0, "nariz_56", 0.4437501491928052F, 1.0F, 0.4494096886111662F);
        escalar(g0, "nariz_57", 0.5071426548505399F, 1.0F, 0.4494096886111662F);
        escalar(g0, "nariz_58", 0.4437501324344074F, 1.0F, 0.44940969069912756F);
        escalar(g0, "nariz_59", 0.5004754103409891F, 1.0F, 0.4537683291513769F);
        escalar(g0, "nariz_60", 0.45075695449198566F, 1.0F, 0.47589091138115674F);
        escalar(g0, "nariz_61", 0.45764557949436946F, 1.0F, 0.5021307495805616F);
        escalar(g0, "nariz_62", 0.4666941401420778F, 1.0F, 0.5003243903232919F);
        escalar(g0, "nariz_63", 0.47723625053847263F, 1.0F, 0.48734959682133583F);
        escalar(g0, "nariz_64", 0.4437501491928052F, 1.0F, 0.4389042244395516F);
        escalar(g0, "nariz_65", 0.5071426548505399F, 1.0F, 0.4389042244395516F);
        escalar(g0, "nariz_66", 0.44375013243440764F, 1.0F, 0.43890422483687497F);
        escalar(g0, "nariz_67", 0.504319649966336F, 1.0F, 0.4394894446188643F);
        escalar(g0, "nariz_68", 0.4640783768526042F, 1.0F, 0.4358758194371627F);
        escalar(g0, "nariz_69", 0.46779238435040515F, 1.0F, 0.4849001585343875F);
        escalar(g0, "nariz_70", 0.46985180616809025F, 1.0F, 0.43981515143653266F);
        escalar(g0, "nariz_71", 0.4972233346360867F, 1.0F, 0.4894072391729873F);
        escalar(g0, "nariz_72", 0.4437501491928052F, 1.0F, 0.49778983551841777F);
        escalar(g0, "nariz_73", 0.5071426548505399F, 1.0F, 0.49778983551841777F);
        escalar(g0, "nariz_74", 0.4437501324344279F, 1.0F, 0.4977897384416079F);
        escalar(g0, "nariz_75", 0.5057013969745249F, 1.0F, 0.4911571555972337F);
        escalar(g0, "nariz_76", 0.4673390534935911F, 1.0F, 0.4558433400886234F);
        escalar(g0, "nariz_77", 0.46778435608952623F, 1.0F, 0.4535776442522871F);
        escalar(g0, "nariz_78", 0.46765272008313324F, 1.0F, 0.4525880789819003F);
        escalar(g0, "nariz_79", 0.4564329217986482F, 1.0F, 0.49571492467039885F);
        escalar(g0, "nariz_80", 0.4437501491928052F, 1.0F, 0.49778932920839947F);
        escalar(g0, "nariz_81", 0.5071426548505399F, 1.0F, 0.49778932920839947F);
        escalar(g0, "nariz_82", 0.4437501324344279F, 1.0F, 0.4977894199222058F);
        escalar(g0, "nariz_83", 0.5057013969745281F, 1.0F, 0.4911570902328272F);
        escalar(g0, "nariz_84", 0.4673390534935813F, 1.0F, 0.45584322224980334F);
        escalar(g0, "nariz_85", 0.46778435608952396F, 1.0F, 0.4535773649171316F);
        escalar(g0, "nariz_86", 0.4676527200833026F, 1.0F, 0.4525885753802834F);
        escalar(g0, "nariz_87", 0.45643292179554557F, 1.0F, 0.4957159224268798F);
        escalar(g0, "nariz_88", 0.4437501491928052F, 1.0F, 0.438904224439116F);
        escalar(g0, "nariz_89", 0.5071426548505399F, 1.0F, 0.438904224439116F);
        escalar(g0, "nariz_90", 0.44375013243440764F, 1.0F, 0.43890422483660135F);
        escalar(g0, "nariz_91", 0.5043196499663414F, 1.0F, 0.43948944461894834F);
        escalar(g0, "nariz_92", 0.4640783768525961F, 1.0F, 0.43587581943719106F);
        escalar(g0, "nariz_93", 0.46779238435040277F, 1.0F, 0.4849001585341098F);
        escalar(g0, "nariz_94", 0.46985180616841593F, 1.0F, 0.43981515143734623F);
        escalar(g0, "nariz_95", 0.4972233346320073F, 1.0F, 0.48940723917442996F);
        escalar(g0, "nariz_96", 0.4437501491928052F, 1.0F, 0.449409688611006F);
        escalar(g0, "nariz_97", 0.5071426548505399F, 1.0F, 0.449409688611006F);
        escalar(g0, "nariz_98", 0.4437501324344074F, 1.0F, 0.44940969069901804F);
        escalar(g0, "nariz_99", 0.5004754103410173F, 1.0F, 0.4537683291512792F);
        escalar(g0, "nariz_100", 0.450756954491981F, 1.0F, 0.4758909113812019F);
        escalar(g0, "nariz_101", 0.4576455794943729F, 1.0F, 0.5021307495805762F);
        escalar(g0, "nariz_102", 0.4666941401423182F, 1.0F, 0.5003243903239513F);
        escalar(g0, "nariz_103", 0.4772362505366521F, 1.0F, 0.4873495968222834F);
        escalar(g0, "nariz_104", 0.4437501491928052F, 1.0F, 0.4320264851213533F);
        escalar(g0, "nariz_105", 0.5071426548505399F, 1.0F, 0.4320264851213533F);
        escalar(g0, "nariz_106", 0.4437501324344071F, 1.0F, 0.4320264861463535F);
        escalar(g0, "nariz_107", 0.49575736370975093F, 1.0F, 0.43452136720036777F);
        escalar(g0, "nariz_108", 0.48579009955181546F, 1.0F, 0.4566613413633189F);
        escalar(g0, "nariz_109", 0.4900509400636818F, 1.0F, 0.5104486210198587F);
        escalar(g0, "nariz_110", 0.5051036199317795F, 1.0F, 0.4566016374077626F);
        escalar(g0, "nariz_111", 0.4702667265862823F, 1.0F, 0.47966818306859166F);
        escalar(g0, "nariz_112", 0.4437501491928052F, 1.0F, 0.49636101544038597F);
        escalar(g0, "nariz_113", 0.5071426548505399F, 1.0F, 0.49636101544038597F);
        escalar(g0, "nariz_114", 0.4437501324344067F, 1.0F, 0.49636101327697557F);
        escalar(g0, "nariz_115", 0.4902564076132826F, 1.0F, 0.49248004788992356F);
        escalar(g0, "nariz_116", 0.462418762517878F, 1.0F, 0.48652512637607015F);
        escalar(g0, "nariz_117", 0.46163283168637115F, 1.0F, 0.3892542563852932F);
        escalar(g0, "nariz_118", 0.46865730491773533F, 1.0F, 0.48483900766439875F);
        escalar(g0, "nariz_119", 0.4567842382028209F, 1.0F, 0.4584824414081717F);
        escalar(g0, "nariz_120", 0.4437501491928052F, 1.0F, 0.49634836410253325F);
        escalar(g0, "nariz_121", 0.5071426548505399F, 1.0F, 0.49634836410253325F);
        escalar(g0, "nariz_122", 0.4437501324344062F, 1.0F, 0.4963483578317948F);
        escalar(g0, "nariz_123", 0.48240840018733505F, 1.0F, 0.4841149178743019F);
        escalar(g0, "nariz_124", 0.4930726867980098F, 1.0F, 0.4347314283334614F);
        escalar(g0, "nariz_125", 0.4947938866728678F, 1.0F, 0.3891660798762748F);
        escalar(g0, "nariz_126", 0.49437200057492714F, 1.0F, 0.4540439024732035F);
        escalar(g0, "nariz_127", 0.4976418959980792F, 1.0F, 0.5053329883399499F);
        escalar(g0, "nariz_128", 0.4437501491928052F, 1.0F, 0.4319963677637054F);
        escalar(g0, "nariz_129", 0.5071426548505399F, 1.0F, 0.4319963677637054F);
        escalar(g0, "nariz_130", 0.4437501324344055F, 1.0F, 0.43199635936217823F);
        escalar(g0, "nariz_131", 0.4710552902215746F, 1.0F, 0.4153384503866146F);
        escalar(g0, "nariz_132", 0.4385527931801816F, 1.0F, 0.4552439199741029F);
        escalar(g0, "nariz_133", 0.45163167343165317F, 1.0F, 0.4889783924738095F);
        escalar(g0, "nariz_134", 0.4537093178271607F, 1.0F, 0.3448717113651921F);
        escalar(g0, "nariz_135", 0.4560124835489415F, 1.0F, 0.5025727971487132F);
        escalar(g0, "nariz_136", 0.4437501491928052F, 1.0F, 0.4493657100159161F);
        escalar(g0, "nariz_137", 0.5071426548505399F, 1.0F, 0.4493657100159161F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "nariz_138", 0.4437501324344046F, 1.0F, 0.4493657002014119F);
        escalar(g0, "nariz_139", 0.4571166149906852F, 1.0F, 0.42957959027990994F);
        escalar(g0, "nariz_140", 0.49949681830473036F, 1.0F, 0.41997386952790866F);
        escalar(g0, "nariz_141", 0.4500804893238133F, 1.0F, 0.508273778133716F);
        escalar(g0, "nariz_142", 0.464298375057916F, 1.0F, 0.4699941766613959F);
        escalar(g0, "nariz_143", 0.4957055160393248F, 1.0F, 0.41692541024838603F);
        escalar(g0, "nariz_144", 0.4437501491928052F, 1.0F, 0.4388599280302389F);
        escalar(g0, "nariz_145", 0.5071426548505399F, 1.0F, 0.4388599280302389F);
        escalar(g0, "nariz_146", 0.44375013243440387F, 1.0F, 0.43885992004024954F);
        escalar(g0, "nariz_147", 0.44483823029363806F, 1.0F, 0.49277381423626365F);
        escalar(g0, "nariz_148", 0.44634593040240317F, 1.0F, 0.46962130983141154F);
        escalar(g0, "nariz_149", 0.5044007546783367F, 1.0F, 0.4557297600595637F);
        escalar(g0, "nariz_150", 0.45093668844877877F, 1.0F, 0.5210479576660229F);
        escalar(g0, "nariz_151", 0.4382881491489016F, 1.0F, 0.40316186715688F);
        escalar(g0, "nariz_152", 0.4437501491928052F, 1.0F, 0.4979327845634064F);
        escalar(g0, "nariz_153", 0.5071426548505399F, 1.0F, 0.4979327845634064F);
        escalar(g0, "nariz_154", 0.4437501324344035F, 1.0F, 0.49793277910197403F);
        escalar(g0, "nariz_155", 0.4386862055384268F, 1.0F, 0.4866907827936377F);
        escalar(g0, "nariz_156", 0.42706724094942F, 1.0F, 0.4859796810145168F);
        escalar(g0, "nariz_157", 0.4607101903707129F, 1.0F, 0.48891861650230145F);
        escalar(g0, "nariz_158", 0.5162976367601145F, 1.0F, 0.3720199031644476F);
        escalar(g0, "nariz_159", 0.5228611600775066F, 1.0F, 0.44825692783715526F);
        escalar(g0, "faroi_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroi_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroi_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroi_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroi_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "farod_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farod_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farod_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farod_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farod_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "cabina_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "cabina_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "cabina_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "cabina_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "cabina_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "cabina_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "cabina_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "cabina_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "cabina_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "cabina_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "cabina_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "radiador_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "radiador_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "radiador_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "radiador_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "radiador_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "radiador_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "radiador_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "radiador_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "ventilador78_0", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador78_1", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador78_2", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador78_3", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador90_0", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador90_1", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador90_2", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "ventilador90_3", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "bocina_0", 1.0F, 0.1077859454596501F, 0.1077859454596501F);
        escalar(g0, "bocina_1", 1.0F, 0.1077859454596501F, 0.1077859454596501F);
        escalar(g0, "faro_t_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_vidrio", 0.24F, 0.15F, 0.24F);
    }
}
