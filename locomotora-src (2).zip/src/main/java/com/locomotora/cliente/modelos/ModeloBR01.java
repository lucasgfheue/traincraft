package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "DR BR 01" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloBR01 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("br01"), "main"),
            LocomotoraMod.id("textures/entity/br01.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -8.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -8.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -8.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 12.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 12.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 12.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 32.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 32.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 32.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 9.0F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 9.0F, 3.0F, 0.0F, -30.0F, 12.0F, -12.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 9.0F, 3.0F, 0.0F, -30.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 12.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 12.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 12.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 9.0F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 9.0F, 3.0F, 1.5707963267948966F, -30.0F, 12.0F, -12.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 9.0F, 3.0F, 1.5707963267948966F, -30.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -50.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -50.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -50.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -32.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -32.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -32.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -50.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -50.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -50.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -32.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -32.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -32.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 52.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 52.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 52.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 52.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 52.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 52.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 88.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 88.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 88.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 120.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 120.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 120.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 134.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 134.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 134.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 88.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 88.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 88.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 120.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 120.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 120.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 134.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 134.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 134.0F, -5.0F, 1.0471975511965976F, "tender")),
            ModeloBR01::crearCapa,
            16.0F,
            ModeloBR01::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -41.0F, 52.0F),
                new DatosModelo.Segmento("tender", 81.0F, 127.0F)));

    private ModeloBR01() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g1);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
        escalas3(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(128, 169).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(512, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(552, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(936, 255).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(550, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(588, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(128, 169).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(512, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(562, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(942, 255).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(12.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(550, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(588, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(128, 169).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(512, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(572, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(948, 255).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(32.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(550, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(588, 214).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 169).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(0, 262).addBox(-8.0F, -12.5F, -7.5F, 40.0F, 1.0F, 1.0F).texOffs(898, 242).addBox(-9.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(906, 242).addBox(10.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(914, 242).addBox(30.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(164, 262).addBox(-30.0F, -0.5F, -0.5F, 30.0F, 1.0F, 1.0F).texOffs(922, 242).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(12.0F, -12.0F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(582, 225).addBox(-19.3496231131986F, -10.5F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(408, 262).addBox(-27.8496231131986F, -9.5F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(288, 262).addBox(-24.8496231131986F, -7.5F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(318, 262).addBox(-24.8496231131986F, -11.5F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(484, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(0, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(512, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(44, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(540, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(88, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(568, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(132, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(734, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(740, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(746, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(752, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(758, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(764, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(770, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(776, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(128, 169).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(512, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(592, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(954, 255).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(550, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(588, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(128, 169).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(512, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(602, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(960, 255).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(12.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(550, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(588, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(128, 169).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(512, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(612, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(966, 255).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(32.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(550, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(262, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(588, 214).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 169).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(82, 262).addBox(-8.0F, -12.5F, 6.5F, 40.0F, 1.0F, 1.0F).texOffs(930, 242).addBox(-9.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(938, 242).addBox(10.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(946, 242).addBox(30.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(226, 262).addBox(-30.0F, -0.5F, -0.5F, 30.0F, 1.0F, 1.0F).texOffs(954, 242).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(12.0F, -12.0F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(622, 225).addBox(-19.3496231131986F, -10.5F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(430, 262).addBox(-27.8496231131986F, -9.5F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(348, 262).addBox(-24.8496231131986F, -7.5F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(378, 262).addBox(-24.8496231131986F, -11.5F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(596, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(176, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(624, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(220, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(652, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(264, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(680, 190).addBox(-36.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(308, 190).addBox(-36.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(782, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(788, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(794, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(800, 202).addBox(-37.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 202).addBox(-37.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(806, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(812, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(818, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(824, 202).addBox(-25.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 202).addBox(-25.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(0, 214).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(240, 242).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(22, 214).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(632, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-50.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(262, 242).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 214).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(284, 242).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 214).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(0, 214).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(240, 242).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(22, 214).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(642, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-32.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(262, 242).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 214).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(284, 242).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 214).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(0, 214).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(240, 242).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(22, 214).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-50.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(262, 242).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 214).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(284, 242).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 214).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(0, 214).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(240, 242).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(22, 214).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(662, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-32.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(262, 242).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 214).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(284, 242).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 214).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(938, 169).addBox(-5.5F, -5.5F, -6.0F, 11.0F, 11.0F, 2.0F).texOffs(162, 225).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 169).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(52.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(188, 225).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(974, 169).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(214, 225).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 169).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(938, 169).addBox(-5.5F, -5.5F, 4.0F, 11.0F, 11.0F, 2.0F).texOffs(162, 225).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 169).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(52.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(188, 225).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(974, 169).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(214, 225).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 169).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(290, 169).addBox(-58.0F, -19.0F, 2.0F, 120.0F, 15.0F, 1.0F).texOffs(532, 169).addBox(-58.0F, -19.0F, -3.0F, 120.0F, 15.0F, 1.0F).texOffs(60, 136).addBox(-62.0F, -14.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(962, 242).addBox(-64.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(436, 136).addBox(-59.0F, -20.0F, -12.5F, 121.0F, 1.0F, 25.0F).texOffs(972, 255).addBox(-56.0F, -30.0F, -0.5F, 1.0F, 2.0F, 1.0F).texOffs(166, 136).addBox(22.0F, -30.0F, -9.0F, 18.0F, 10.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(838, 99).addBox(-65.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(142, 99).addBox(-65.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(858, 99).addBox(-65.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(200, 99).addBox(-65.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(878, 99).addBox(-65.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(258, 99).addBox(-65.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(830, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(836, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(842, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(848, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(418, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(898, 99).addBox(-65.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(316, 99).addBox(-65.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(918, 99).addBox(-65.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(374, 99).addBox(-65.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(938, 99).addBox(-65.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(432, 99).addBox(-65.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(854, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(440, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(860, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(462, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(866, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(484, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(872, 202).addBox(-66.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(506, 202).addBox(-66.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(312, 56).addBox(-54.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(204, 0).addBox(-54.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -29.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(354, 56).addBox(-54.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(312, 0).addBox(-54.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(396, 56).addBox(-54.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(420, 0).addBox(-54.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(438, 56).addBox(-54.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(528, 0).addBox(-54.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(480, 56).addBox(-54.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(636, 0).addBox(-54.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(522, 56).addBox(-54.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(744, 0).addBox(-54.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_0", CubeListBuilder.create().texOffs(564, 56).addBox(-55.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(852, 0).addBox(-55.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -29.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("puerta_1", CubeListBuilder.create().texOffs(576, 56).addBox(-55.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(930, 0).addBox(-55.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_2", CubeListBuilder.create().texOffs(588, 56).addBox(-55.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(0, 56).addBox(-55.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_3", CubeListBuilder.create().texOffs(600, 56).addBox(-55.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(78, 56).addBox(-55.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_4", CubeListBuilder.create().texOffs(612, 56).addBox(-55.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(156, 56).addBox(-55.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_5", CubeListBuilder.create().texOffs(624, 56).addBox(-55.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(234, 56).addBox(-55.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(968, 242).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -37.56624981908866F, 0.9651845510355137F, 3.029396166284862F, -0.0008558248479810756F, -0.007595730503077666F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(0, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -37.71436941250229F, 0.9818736210822372F, 3.0293961662848625F, -0.00085582484798107F, -0.007595730503077666F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(416, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.86248900591593F, 0.9985626911289607F, 3.0293961662848634F, -0.00085582484798107F, -0.007595730503077666F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(462, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -38.01060859932957F, 1.0152517611756844F, 3.029396166284864F, -0.0008558248479810813F, -0.00759573050307803F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(44, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -37.1367022836154F, 2.847155269457922F, 2.805002547934306F, -0.00252456228595185F, -0.007214862425042403F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(88, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -37.27739454212172F, 2.896385619938462F, 2.805002547934306F, -0.0025245622859518214F, -0.007214862425042221F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(508, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.41808680062803F, 2.9456159704190026F, 2.8050025479343046F, -0.0025245622859518444F, -0.007214862425042221F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(554, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -37.55877905913436F, 2.9948463208995433F, 2.8050025479343033F, -0.0025245622859518557F, -0.007214862425042585F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(132, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -36.29914651973182F, 4.586357733984665F, 2.5806071258430383F, -0.00406671371415333F, -0.006472218665457293F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(176, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -36.42535654600961F, 4.665660749557887F, 2.5806071258430383F, -0.004066713714153261F, -0.00647221866545711F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(600, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -36.551566572287385F, 4.744963765131108F, 2.5806071258430396F, -0.004066713714153307F, -0.00647221866545711F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(646, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -36.677776598565174F, 4.82426678070433F, 2.5806071258430396F, -0.004066713714153307F, -0.006472218665457293F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(220, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -35.09558107076734F, 6.095581070767336F, 2.3562090972205776F, -0.0054049502769377995F, -0.0054050292273912885F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(264, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -35.20098016709184F, 6.200980167091843F, 2.3562090972205776F, -0.005404950276937731F, -0.0054050292273912885F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(692, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -35.306379263416346F, 6.30637926341635F, 2.3562090972205767F, -0.005404950276937776F, -0.005405029227391106F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(738, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -35.41177835974085F, 6.411778359740857F, 2.356209097220576F, -0.005404950276937776F, -0.0054050292273912885F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(308, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -33.58635773398467F, 7.299146519731821F, 2.131808175497027F, -0.006472165145488333F, -0.004066798891235745F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(352, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -33.66566074955789F, 7.4253565460096045F, 2.131808175497027F, -0.006472165145488265F, -0.004066798891235563F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(784, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -33.74496376513111F, 7.5515665722873875F, 2.1318081754970275F, -0.006472165145488333F, -0.004066798891235563F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(830, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -33.82426678070433F, 7.677776598565171F, 2.131808175497028F, -0.006472165145488333F, -0.004066798891235563F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(396, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -31.84715526945792F, 8.136702283615401F, 1.9074046471166644F, -0.007214839433000332F, -0.0025246279941832177F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(440, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -31.896385619938464F, 8.27739454212172F, 1.9074046471166644F, -0.0072148394330002865F, -0.0025246279941830356F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(876, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -31.945615970419002F, 8.418086800628037F, 1.907404647116665F, -0.007214839433000332F, -0.002524627994183309F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(922, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -31.994846320899544F, 8.558779059134356F, 1.9074046471166652F, -0.0072148394330003775F, -0.0025246279941830356F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(484, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -29.965184551035513F, 8.56624981908866F, 1.6829993148389568F, -0.007595727721330502F, -0.0008558495370219836F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(528, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -29.981873621082237F, 8.714369412502295F, 1.6829993148389566F, -0.007595727721330457F, -0.0008558495370219836F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(968, 230).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -29.99856269112896F, 8.862489005915931F, 1.6829993148389564F, -0.007595727721330502F, -0.0008558495370220747F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(0, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -30.015251761175683F, 9.010608599329569F, 1.6829993148389564F, -0.007595727721330548F, -0.0008558495370219836F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(572, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -28.034815448964487F, 8.56624981908866F, 1.4585933387508365F, -0.007595727721330502F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(616, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -28.018126378917763F, 8.714369412502295F, 1.4585933387508365F, -0.007595727721330457F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(46, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -28.00143730887104F, 8.862489005915931F, 1.4585933387508367F, -0.007595727721330502F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(92, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -27.984748238824317F, 9.010608599329569F, 1.4585933387508367F, -0.007595727721330548F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(660, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -26.15284473054208F, 8.136702283615403F, 1.2341880064731294F, -0.007214839433000332F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(704, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -26.103614380061536F, 8.277394542121721F, 1.2341880064731294F, -0.0072148394330002865F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(138, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -26.054384029581F, 8.418086800628037F, 1.2341880064731292F, -0.007214839433000332F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(184, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -26.00515367910046F, 8.558779059134357F, 1.234188006473129F, -0.0072148394330003775F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(748, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -24.413642266015337F, 7.299146519731823F, 1.009784478092765F, -0.006472165145488333F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(792, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -24.33433925044212F, 7.425356546009607F, 1.0097844780927654F, -0.006472165145488265F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(230, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -24.255036234868896F, 7.55156657228739F, 1.0097844780927656F, -0.006472165145488333F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(276, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -24.175733219295672F, 7.677776598565174F, 1.009784478092766F, -0.006472165145488333F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(836, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -22.90441892923267F, 6.095581070767338F, 0.7853835563692178F, -0.0054049502769377995F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(880, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -22.799019832908158F, 6.200980167091845F, 0.7853835563692176F, -0.005404950276937731F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(322, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -22.69362073658365F, 6.306379263416352F, 0.7853835563692173F, -0.005404950276937776F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(368, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -22.588221640259142F, 6.411778359740859F, 0.7853835563692171F, -0.0054049502769377995F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(924, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -21.70085348026818F, 4.5863577339846655F, 0.5609855277467534F, -0.00406671371415333F, 0.00647221866545711F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(968, 246).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -21.574643453990397F, 4.665660749557887F, 0.5609855277467526F, -0.004066713714153261F, 0.0064722186654572016F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(414, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -21.44843342771261F, 4.744963765131109F, 0.5609855277467528F, -0.004066713714153307F, 0.0064722186654572016F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(460, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -21.32222340143483F, 4.824266780704331F, 0.5609855277467528F, -0.00406671371415333F, 0.0064722186654572016F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(0, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -20.8632977163846F, 2.8471552694579243F, 0.33659010565548986F, -0.0025245622859518557F, 0.007214862425042221F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(44, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -20.72260545787828F, 2.8963856199384654F, 0.33659010565549047F, -0.0025245622859518214F, 0.007214862425042312F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(506, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.58191319937196F, 2.9456159704190057F, 0.33659010565549013F, -0.0025245622859518557F, 0.007214862425042312F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(552, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -20.441220940865648F, 2.994846320899546F, 0.33659010565548986F, -0.0025245622859518444F, 0.007214862425042312F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(88, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -20.43375018091134F, 0.9651845510355166F, 0.11219648730493095F, -0.0008558248479810819F, 0.007595730503077666F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(132, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -20.285630587497707F, 0.9818736210822401F, 0.11219648730493037F, -0.0008558248479810704F, 0.007595730503077666F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(598, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.137510994084067F, 0.9985626911289638F, 0.11219648730492982F, -0.0008558248479810819F, 0.007595730503077666F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(644, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -19.98939140067043F, 1.0152517611756873F, 0.11219648730493015F, -0.0008558248479810704F, 0.007595730503077757F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(176, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -20.43375018091134F, -0.9651845510355126F, -0.11219648730493116F, 0.000855824847981075F, 0.007595730503077666F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(220, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -20.285630587497707F, -0.9818736210822361F, -0.11219648730493058F, 0.0008558248479810637F, 0.007595730503077666F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(690, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.137510994084067F, -0.9985626911289596F, -0.11219648730493004F, 0.000855824847981075F, 0.007595730503077666F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(736, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -19.98939140067043F, -1.0152517611756833F, -0.11219648730492948F, 0.0008558248479810808F, 0.007595730503077848F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(264, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -20.863297716384597F, -2.8471552694579207F, -0.3365901056554883F, 0.00252456228595185F, 0.007214862425042312F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(308, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -20.72260545787828F, -2.896385619938461F, -0.33659010565548797F, 0.0025245622859518158F, 0.007214862425042312F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(782, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.58191319937196F, -2.9456159704190013F, -0.33659010565548864F, 0.00252456228595185F, 0.007214862425042221F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(828, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -20.441220940865644F, -2.994846320899542F, -0.33659010565548925F, 0.0025245622859518444F, 0.007214862425042494F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(352, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -21.700853480268176F, -4.586357733984662F, -0.5609855277467534F, 0.004066713714153307F, 0.0064722186654572016F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(396, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -21.57464345399039F, -4.665660749557883F, -0.5609855277467536F, 0.004066713714153261F, 0.0064722186654572016F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(874, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -21.44843342771261F, -4.744963765131105F, -0.5609855277467528F, 0.00406671371415333F, 0.00647221866545711F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(920, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -21.322223401434826F, -4.824266780704328F, -0.5609855277467528F, 0.004066713714153296F, 0.006472218665457293F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(440, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -22.904418929232662F, -6.095581070767333F, -0.785383556369216F, 0.005404950276937776F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(484, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -22.799019832908154F, -6.20098016709184F, -0.7853835563692164F, 0.005404950276937708F, 0.0054050292273911974F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(966, 234).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -22.693620736583647F, -6.306379263416346F, -0.785383556369217F, 0.005404950276937822F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(0, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -22.58822164025914F, -6.411778359740855F, -0.7853835563692166F, 0.005404950276937776F, 0.0054050292273912885F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(528, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -24.41364226601533F, -7.29914651973182F, -1.0097844780927643F, 0.006472165145488333F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(572, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -24.33433925044211F, -7.425356546009603F, -1.0097844780927638F, 0.006472165145488265F, 0.004066798891235563F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(46, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -24.255036234868886F, -7.551566572287387F, -1.0097844780927636F, 0.006472165145488356F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(92, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -24.17573321929566F, -7.6777765985651705F, -1.009784478092764F, 0.006472165145488333F, 0.004066798891235654F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(616, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -26.152844730542068F, -8.1367022836154F, -1.234188006473128F, 0.007214839433000332F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(660, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -26.10361438006153F, -8.277394542121717F, -1.2341880064731283F, 0.007214839433000309F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(138, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -26.054384029580987F, -8.418086800628036F, -1.2341880064731283F, 0.007214839433000332F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(184, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -26.005153679100445F, -8.558779059134354F, -1.2341880064731285F, 0.007214839433000332F, 0.0025246279941831267F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(704, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -28.03481544896448F, -8.56624981908866F, -1.4585933387508363F, 0.007595727721330502F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(748, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -28.018126378917756F, -8.714369412502295F, -1.4585933387508363F, 0.007595727721330457F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(230, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -28.001437308871033F, -8.862489005915931F, -1.4585933387508363F, 0.007595727721330502F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(276, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -27.98474823882431F, -9.010608599329569F, -1.458593338750836F, 0.007595727721330502F, 0.0008558495370219836F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(792, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -29.965184551035513F, -8.56624981908866F, -1.6829993148389568F, 0.007595727721330502F, -0.0008558495370219836F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(836, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -29.981873621082237F, -8.714369412502295F, -1.6829993148389566F, 0.007595727721330457F, -0.0008558495370219836F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(322, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -29.99856269112896F, -8.862489005915931F, -1.6829993148389566F, 0.007595727721330502F, -0.0008558495370219836F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(368, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -30.015251761175683F, -9.010608599329569F, -1.6829993148389564F, 0.007595727721330548F, -0.0008558495370219836F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(880, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -31.84715526945792F, -8.136702283615405F, -1.907404647116663F, 0.007214839433000332F, -0.0025246279941832177F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(924, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -31.896385619938464F, -8.277394542121721F, -1.9074046471166635F, 0.007214839433000264F, -0.0025246279941830356F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(414, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -31.945615970419F, -8.41808680062804F, -1.907404647116664F, 0.0072148394330003775F, -0.0025246279941830356F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(460, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -31.99484632089954F, -8.558779059134359F, -1.9074046471166637F, 0.0072148394330003775F, -0.0025246279941832177F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(968, 249).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -33.58635773398467F, -7.299146519731823F, -2.131808175497028F, 0.006472165145488333F, -0.004066798891235745F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(0, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -33.66566074955789F, -7.425356546009606F, -2.1318081754970284F, 0.0064721651454882415F, -0.004066798891235381F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(506, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -33.744963765131104F, -7.55156657228739F, -2.131808175497028F, 0.0064721651454883785F, -0.004066798891235563F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(552, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -33.82426678070433F, -7.677776598565174F, -2.1318081754970284F, 0.006472165145488333F, -0.004066798891235745F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(44, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -35.09558107076734F, -6.095581070767337F, -2.356209097220577F, 0.0054049502769377995F, -0.0054050292273912885F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(88, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -35.20098016709184F, -6.200980167091844F, -2.356209097220576F, 0.005404950276937731F, -0.005405029227391106F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(598, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -35.306379263416346F, -6.306379263416351F, -2.356209097220575F, 0.005404950276937776F, -0.0054050292273912885F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(644, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -35.41177835974085F, -6.411778359740858F, -2.3562090972205754F, 0.0054049502769377995F, -0.0054050292273912885F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(132, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -36.29914651973182F, -4.58635773398467F, -2.5806071258430396F, 0.00406671371415333F, -0.006472218665457293F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(176, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -36.42535654600961F, -4.665660749557892F, -2.5806071258430396F, 0.004066713714153261F, -0.00647221866545711F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(690, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -36.551566572287385F, -4.744963765131113F, -2.580607125843039F, 0.004066713714153307F, -0.006472218665457293F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(736, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -36.67777659856517F, -4.824266780704336F, -2.580607125843039F, 0.00406671371415333F, -0.00647221866545711F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(220, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -37.1367022836154F, -2.847155269457931F, -2.8050025479343024F, 0.0025245622859518557F, -0.007214862425042403F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(264, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -37.27739454212172F, -2.8963856199384717F, -2.8050025479343024F, 0.0025245622859518214F, -0.007214862425042221F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(782, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.41808680062804F, -2.945615970419012F, -2.805002547934303F, 0.0025245622859518557F, -0.007214862425042403F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(828, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -37.55877905913435F, -2.9948463208995526F, -2.805002547934303F, 0.0025245622859518557F, -0.007214862425042221F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(308, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.25F, -37.56624981908866F, -0.9651845510355196F, -3.0293961662848625F, 0.0008558248479810822F, -0.007595730503077666F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(352, 252).addBox(-10.0F, -1.0F, -1.0F, 20.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.75F, -37.71436941250229F, -0.9818736210822432F, -3.029396166284863F, 0.0008558248479810708F, -0.007595730503077666F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(874, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.86248900591593F, -0.9985626911289668F, -3.0293961662848634F, 0.0008558248479810822F, -0.007595730503077666F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(920, 238).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.25F, -38.01060859932957F, -1.0152517611756906F, -3.0293961662848625F, 0.0008558248479810822F, -0.007595730503077848F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(626, 214).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(842, 169).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offset(-46.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(650, 214).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(866, 169).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-46.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(674, 214).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(890, 169).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-46.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(698, 214).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(914, 169).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-46.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_0", CubeListBuilder.create().texOffs(396, 252).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(926, 202).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-46.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_1", CubeListBuilder.create().texOffs(420, 252).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(950, 202).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-46.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_2", CubeListBuilder.create().texOffs(444, 252).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(974, 202).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-46.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_3", CubeListBuilder.create().texOffs(468, 252).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(998, 202).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-46.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_arena_0", CubeListBuilder.create().texOffs(306, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.614752861305579F, -35.84788507991347F, 0.6701232371976483F, 0.07902898016435374F, 0.008321558400374733F, -1.6425972004303144F));
        g.addOrReplaceChild("domo_arena_1", CubeListBuilder.create().texOffs(530, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.85639320475216F, -37.28375802365976F, 0.6331974257059422F, 0.07571115317538997F, 0.0341747703350517F, -1.8699743436397533F));
        g.addOrReplaceChild("domo_arena_2", CubeListBuilder.create().texOffs(542, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.333873260875087F, -38.33051865188429F, 0.5602322151290824F, 0.0664710848077229F, 0.0630236451838935F, -2.1461051160072433F));
        g.addOrReplaceChild("domo_arena_3", CubeListBuilder.create().texOffs(780, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.03846634744119F, -39.122898780595506F, 0.45256115688689325F, 0.05005984577528628F, 0.08963787247714672F, -2.4575255568024077F));
        g.addOrReplaceChild("domo_arena_4", CubeListBuilder.create().texOffs(790, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.969257359497727F, -39.659869289590446F, 0.3103240910098027F, 0.02864015577007096F, 0.10769407060651152F, -2.7716212871871164F));
        g.addOrReplaceChild("domo_arena_5", CubeListBuilder.create().texOffs(452, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.24605130307666F, -39.93161621713294F, 0.11521324237466748F, 0.007168354163566261F, 0.15102949095761783F, -3.051139310595273F));
        g.addOrReplaceChild("domo_arena_6", CubeListBuilder.create().texOffs(492, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.827322772778532F, -35.84788507991347F, 1.7326412942324207F, 0.3848357153307929F, 0.028262528127461262F, -1.6389311087264218F));
        g.addOrReplaceChild("domo_arena_7", CubeListBuilder.create().texOffs(800, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.057249872982446F, -37.28375802365976F, 1.6371675331953863F, 0.369435784327734F, 0.11500019477868736F, -1.8559124261168565F));
        g.addOrReplaceChild("domo_arena_8", CubeListBuilder.create().texOffs(810, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.511584621657462F, -38.33051865188429F, 1.4485118802195083F, 0.3260881250266903F, 0.21220723066073333F, -2.123074101393851F));
        g.addOrReplaceChild("domo_arena_9", CubeListBuilder.create().texOffs(820, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.182023352653903F, -39.122898780595506F, 1.170122307453361F, 0.24755446824989707F, 0.30212301330492963F, -2.4324311672624406F));
        g.addOrReplaceChild("domo_arena_10", CubeListBuilder.create().texOffs(532, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.067695319699993F, -39.659869289590446F, 0.8023603791553625F, 0.14286526600919244F, 0.3669537011196855F, -2.7535493915627582F));
        g.addOrReplaceChild("domo_arena_11", CubeListBuilder.create().texOffs(504, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.252172166361621F, -35.84788507991347F, 2.416761738347055F, 0.7367056331592498F, 0.03942950335410051F, -1.6320121262710334F));
        g.addOrReplaceChild("domo_arena_12", CubeListBuilder.create().texOffs(830, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.458688783614043F, -37.28375802365976F, 2.283590877500977F, 0.7126683660987677F, 0.18112410466663167F, -1.811517299659404F));
        g.addOrReplaceChild("domo_arena_13", CubeListBuilder.create().texOffs(840, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.86676454029249F, -38.33051865188429F, 2.0204459522630236F, 0.6419129509665605F, 0.33878069709380043F, -2.047215962371215F));
        g.addOrReplaceChild("domo_arena_14", CubeListBuilder.create().texOffs(850, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.46894122445716F, -39.122898780595506F, 1.6321363407723966F, 0.48839614972904727F, 0.43600762841649515F, -2.3782373143319235F));
        g.addOrReplaceChild("domo_arena_15", CubeListBuilder.create().texOffs(540, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.264436746591976F, -39.659869289590446F, 1.1191663682282056F, 0.28605058482379914F, 0.5307459740023602F, -2.7144998589246767F));
        g.addOrReplaceChild("domo_arena_16", CubeListBuilder.create().texOffs(516, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.8927349078395F, -35.84788507991347F, 2.914977203940961F, 1.0661004519633692F, 0.05276877989512513F, -1.6121598200856757F));
        g.addOrReplaceChild("domo_arena_17", CubeListBuilder.create().texOffs(860, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.063954586070173F, -37.28375802365976F, 2.754353168300189F, 1.0419669529604778F, 0.21964725339056074F, -1.7463761653403045F));
        g.addOrReplaceChild("domo_arena_18", CubeListBuilder.create().texOffs(870, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.402283775661825F, -38.33051865188429F, 2.4369609131058416F, 0.967903984635694F, 0.4202931728016917F, -1.9274444593777809F));
        g.addOrReplaceChild("domo_arena_19", CubeListBuilder.create().texOffs(880, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.90153899043549F, -39.122898780595506F, 1.9686012698666526F, 0.806182044928532F, 0.6359560037692845F, -2.183796124228206F));
        g.addOrReplaceChild("domo_arena_20", CubeListBuilder.create().texOffs(548, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.561071812278023F, -39.659869289590446F, 1.3498825304284636F, 0.45562473627816535F, 0.6882301280315835F, -2.639573364025266F));
        g.addOrReplaceChild("domo_arena_21", CubeListBuilder.create().texOffs(320, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-13.772318335986888F, -35.84788507991347F, 3.2454156211722527F, 1.3288368301968063F, 0.05571045385840239F, -1.596191002777402F));
        g.addOrReplaceChild("domo_arena_22", CubeListBuilder.create().texOffs(890, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.895070314463073F, -37.28375802365976F, 3.0665834321247636F, 1.3111833484559865F, 0.23351026546197032F, -1.6791951492450148F));
        g.addOrReplaceChild("domo_arena_23", CubeListBuilder.create().texOffs(900, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.137627582574916F, -38.33051865188429F, 2.713211960933084F, 1.2549725236545786F, 0.4560626672048612F, -1.795184887480872F));
        g.addOrReplaceChild("domo_arena_24", CubeListBuilder.create().texOffs(840, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.495557033274249F, -39.122898780595506F, 2.1917596146025184F, 1.1198294135332925F, 0.7186278488386306F, -1.9767297330949545F));
        g.addOrReplaceChild("domo_arena_25", CubeListBuilder.create().texOffs(556, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.968393798228819F, -39.659869289590446F, 1.502903640233337F, 0.673835712823013F, 0.8579407216860447F, -2.488139724284684F));
        g.addOrReplaceChild("domo_arena_26", CubeListBuilder.create().texOffs(312, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-15.138412980735948F, -35.84788507991347F, 3.4107477745401047F, 1.5224059452924517F, 0.055992601816951315F, -1.5791939221749578F));
        g.addOrReplaceChild("domo_arena_27", CubeListBuilder.create().texOffs(440, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-15.185889024082975F, -37.28375802365976F, 3.222805285192764F, 1.5157101047310086F, 0.23575227982142744F, -1.6067802885492237F));
        g.addOrReplaceChild("domo_arena_28", CubeListBuilder.create().texOffs(554, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.279701437682876F, -38.33051865188429F, 2.8514319082082658F, 1.4939056108435491F, 0.4668035934114942F, -1.6462630563783172F));
        g.addOrReplaceChild("domo_arena_29", CubeListBuilder.create().texOffs(818, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.418135655424429F, -39.122898780595506F, 2.3034150631012964F, 1.4382441411293216F, 0.7577554054596681F, -1.7125599296788276F));
        g.addOrReplaceChild("domo_arena_30", CubeListBuilder.create().texOffs(848, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.601011882982796F, -39.659869289590446F, 1.5794664981684354F, 1.2896308772120757F, 1.0917079272343122F, -1.861714938840593F));
        g.addOrReplaceChild("domo_arena_31", CubeListBuilder.create().texOffs(564, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.85186868837372F, -39.93161621713294F, 0.5864045420514867F, 0.44118361339061407F, 1.2994318138252945F, -2.7090987022170174F));
        g.addOrReplaceChild("domo_arena_32", CubeListBuilder.create().texOffs(328, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.861587019244183F, -35.84788507991347F, 3.4107477745401047F, 1.619186708296227F, 0.05599260181693902F, -1.5623987314150294F));
        g.addOrReplaceChild("domo_arena_33", CubeListBuilder.create().texOffs(454, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.814110975898252F, -37.28375802365976F, 3.2228052851927647F, 1.6258825488575137F, 0.235752279821383F, -1.5348123650414012F));
        g.addOrReplaceChild("domo_arena_34", CubeListBuilder.create().texOffs(566, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.720298562300517F, -38.33051865188429F, 2.8514319082082658F, 1.6476870427444699F, 0.4668035934114565F, -1.495329597213211F));
        g.addOrReplaceChild("domo_arena_35", CubeListBuilder.create().texOffs(828, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.581864344562156F, -39.122898780595506F, 2.303415063101297F, 1.7033485124574501F, 0.757755405459784F, -1.4290327239141805F));
        g.addOrReplaceChild("domo_arena_36", CubeListBuilder.create().texOffs(856, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.398988117008003F, -39.659869289590446F, 1.5794664981684357F, 1.8519617763716327F, 1.0917079272349892F, -1.2798777147554867F));
        g.addOrReplaceChild("domo_arena_37", CubeListBuilder.create().texOffs(572, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.148131311622866F, -39.93161621713294F, 0.5864045420514868F, 2.7004090401905874F, 1.2994318138302046F, -0.4324939513815535F));
        g.addOrReplaceChild("domo_arena_38", CubeListBuilder.create().texOffs(334, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.22768166401311F, -35.84788507991347F, 3.245415621172253F, 1.8127558233929866F, 0.05571045385840257F, -1.545401650812391F));
        g.addOrReplaceChild("domo_arena_39", CubeListBuilder.create().texOffs(910, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.104929685536924F, -37.28375802365976F, 3.0665834321247645F, 1.8304093051338064F, 0.2335102654619702F, -1.4623975043447783F));
        g.addOrReplaceChild("domo_arena_40", CubeListBuilder.create().texOffs(920, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.86237241742508F, -38.33051865188429F, 2.7132119609330845F, 1.8866201299352146F, 0.4560626672048614F, -1.346407766108922F));
        g.addOrReplaceChild("domo_arena_41", CubeListBuilder.create().texOffs(864, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.50444296672575F, -39.122898780595506F, 2.191759614602519F, 2.0217632400565013F, 0.7186278488386307F, -1.1648629204948382F));
        g.addOrReplaceChild("domo_arena_42", CubeListBuilder.create().texOffs(580, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.03160620177118F, -39.659869289590446F, 1.5029036402333371F, 2.467756940766781F, 0.8579407216860443F, -0.6534529293051083F));
        g.addOrReplaceChild("domo_arena_43", CubeListBuilder.create().texOffs(528, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.1072650921605F, -35.84788507991347F, 2.9149772039409614F, 2.0754922016264246F, 0.05276877989512497F, -1.5294328335041179F));
        g.addOrReplaceChild("domo_arena_44", CubeListBuilder.create().texOffs(930, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.93604541392983F, -37.28375802365976F, 2.7543531683001894F, 2.099625700629315F, 0.21964725339056085F, -1.3952164882494884F));
        g.addOrReplaceChild("domo_arena_45", CubeListBuilder.create().texOffs(940, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.597716224338175F, -38.33051865188429F, 2.4369609131058416F, 2.1736886689540977F, 0.42029317280169176F, -1.214148194212013F));
        g.addOrReplaceChild("domo_arena_46", CubeListBuilder.create().texOffs(950, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.09846100956451F, -39.122898780595506F, 1.968601269866653F, 2.33541060866126F, 0.6359560037692848F, -0.9577965293615878F));
        g.addOrReplaceChild("domo_arena_47", CubeListBuilder.create().texOffs(588, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.438928187721977F, -39.659869289590446F, 1.3498825304284638F, 2.685967917311627F, 0.6882301280315835F, -0.5020192895645273F));
        g.addOrReplaceChild("domo_arena_48", CubeListBuilder.create().texOffs(540, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.74782783363838F, -35.84788507991347F, 2.4167617383470557F, 2.404887020430542F, 0.039429503354100386F, -1.5095805273187604F));
        g.addOrReplaceChild("domo_arena_49", CubeListBuilder.create().texOffs(960, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.54131121638596F, -37.28375802365976F, 2.2835908775009774F, 2.428924287491025F, 0.18112410466663187F, -1.3300753539303893F));
        g.addOrReplaceChild("domo_arena_50", CubeListBuilder.create().texOffs(970, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.13323545970751F, -38.33051865188429F, 2.0204459522630236F, 2.499679702623231F, 0.3387806970938006F, -1.094376691218579F));
        g.addOrReplaceChild("domo_arena_51", CubeListBuilder.create().texOffs(980, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.531058775542842F, -39.122898780595506F, 1.632136340772397F, 2.653196503860745F, 0.4360076284164951F, -0.7633553392578692F));
        g.addOrReplaceChild("domo_arena_52", CubeListBuilder.create().texOffs(596, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.735563253408028F, -39.659869289590446F, 1.119166368228206F, 2.8555420687659936F, 0.5307459740023603F, -0.42709279466511635F));
        g.addOrReplaceChild("domo_arena_53", CubeListBuilder.create().texOffs(552, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.17267722722147F, -35.84788507991347F, 1.7326412942324216F, 2.7567569382589996F, 0.028262528127461196F, -1.5026615448633711F));
        g.addOrReplaceChild("domo_arena_54", CubeListBuilder.create().texOffs(990, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.942750127017554F, -37.28375802365976F, 1.6371675331953874F, 2.7721568692620604F, 0.11500019477868736F, -1.285680227472936F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("domo_arena_55", CubeListBuilder.create().texOffs(1000, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.488415378342538F, -38.33051865188429F, 1.4485118802195092F, 2.8155045285631046F, 0.21220723066073277F, -1.0185185521959432F));
        g.addOrReplaceChild("domo_arena_56", CubeListBuilder.create().texOffs(1010, 252).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.817976647346097F, -39.122898780595506F, 1.1701223074533618F, 2.8940381853398973F, 0.30212301330492897F, -0.7091614863273521F));
        g.addOrReplaceChild("domo_arena_57", CubeListBuilder.create().texOffs(604, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.932304680300007F, -39.659869289590446F, 0.8023603791553631F, 2.9987273875806006F, 0.3669537011196857F, -0.3880432620270351F));
        g.addOrReplaceChild("domo_arena_58", CubeListBuilder.create().texOffs(348, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.38524713869442F, -35.84788507991347F, 0.6701232372101994F, 3.0625636734239663F, 0.008321558400531118F, -1.4989954531594707F));
        g.addOrReplaceChild("domo_arena_59", CubeListBuilder.create().texOffs(578, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.14360679524784F, -37.28375802365976F, 0.6331974257178017F, 3.065881500412992F, 0.034174770335693536F, -1.2716183099500082F));
        g.addOrReplaceChild("domo_arena_60", CubeListBuilder.create().texOffs(590, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.666126739124913F, -38.33051865188429F, 0.5602322151395751F, 3.075121568780833F, 0.06302364518507295F, -0.9954875375825024F));
        g.addOrReplaceChild("domo_arena_61", CubeListBuilder.create().texOffs(0, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.96153365255881F, -39.122898780595506F, 0.45256115689536947F, 3.0915328078135778F, 0.08963787247881615F, -0.684067096787332F));
        g.addOrReplaceChild("domo_arena_62", CubeListBuilder.create().texOffs(10, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.030742640502275F, -39.659869289590446F, 0.3103240910156149F, 3.112952497819191F, 0.1076940706085095F, -0.3699713664026409F));
        g.addOrReplaceChild("domo_arena_63", CubeListBuilder.create().texOffs(462, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.75394869692334F, -39.93161621713294F, 0.11521324237682537F, 3.134424299426092F, 0.1510294909604036F, -0.09045334299452006F));
        g.addOrReplaceChild("domo_arena_64", CubeListBuilder.create().texOffs(362, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.38524713869442F, -35.84788507991347F, -0.6701232371850969F, -3.062563673426914F, -0.008321558400218188F, -1.498995453159486F));
        g.addOrReplaceChild("domo_arena_65", CubeListBuilder.create().texOffs(602, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.14360679524784F, -37.28375802365976F, -0.6331974256940824F, -3.0658815004158146F, -0.0341747703344101F, -1.2716183099500689F));
        g.addOrReplaceChild("domo_arena_66", CubeListBuilder.create().texOffs(614, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.666126739124913F, -38.33051865188429F, -0.5602322151185892F, -3.0751215687833073F, -0.06302364518271392F, -0.9954875375826008F));
        g.addOrReplaceChild("domo_arena_67", CubeListBuilder.create().texOffs(20, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.96153365255881F, -39.122898780595506F, -0.4525611568784167F, -3.0915328078154376F, -0.0896378724754765F, -0.6840670967874374F));
        g.addOrReplaceChild("domo_arena_68", CubeListBuilder.create().texOffs(30, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.030742640502275F, -39.659869289590446F, -0.31032409100399033F, -3.1129524978202534F, -0.1076940706045137F, -0.3699713664027135F));
        g.addOrReplaceChild("domo_arena_69", CubeListBuilder.create().texOffs(472, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.75394869692334F, -39.93161621713294F, -0.11521324237250954F, -3.1344242994263602F, -0.15102949095483176F, -0.09045334299452006F));
        g.addOrReplaceChild("domo_arena_70", CubeListBuilder.create().texOffs(564, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.17267722722147F, -35.84788507991347F, -1.732641294232419F, -2.756756938258999F, -0.028262528127461262F, -1.5026615448633711F));
        g.addOrReplaceChild("domo_arena_71", CubeListBuilder.create().texOffs(40, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.942750127017554F, -37.28375802365976F, -1.6371675331953846F, -2.77215686926206F, -0.11500019477868727F, -1.285680227472936F));
        g.addOrReplaceChild("domo_arena_72", CubeListBuilder.create().texOffs(50, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.488415378342538F, -38.33051865188429F, -1.448511880219507F, -2.8155045285631046F, -0.21220723066073266F, -1.0185185521959434F));
        g.addOrReplaceChild("domo_arena_73", CubeListBuilder.create().texOffs(60, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.817976647346097F, -39.122898780595506F, -1.1701223074533598F, -2.8940381853398973F, -0.3021230133049288F, -0.7091614863273522F));
        g.addOrReplaceChild("domo_arena_74", CubeListBuilder.create().texOffs(612, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.932304680300003F, -39.659869289590446F, -0.8023603791553616F, -2.9987273875806006F, -0.3669537011196852F, -0.38804326202703504F));
        g.addOrReplaceChild("domo_arena_75", CubeListBuilder.create().texOffs(576, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.74782783363838F, -35.84788507991347F, -2.4167617383470543F, -2.4048870204305457F, -0.03942950335410051F, -1.5095805273187592F));
        g.addOrReplaceChild("domo_arena_76", CubeListBuilder.create().texOffs(70, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.54131121638596F, -37.28375802365976F, -2.283590877500976F, -2.4289242874910273F, -0.18112410466663154F, -1.3300753539303891F));
        g.addOrReplaceChild("domo_arena_77", CubeListBuilder.create().texOffs(80, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.13323545970751F, -38.33051865188429F, -2.0204459522630227F, -2.499679702623233F, -0.33878069709380015F, -1.0943766912185786F));
        g.addOrReplaceChild("domo_arena_78", CubeListBuilder.create().texOffs(90, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.53105877554284F, -39.122898780595506F, -1.6321363407723957F, -2.653196503860747F, -0.43600762841649476F, -0.7633553392578692F));
        g.addOrReplaceChild("domo_arena_79", CubeListBuilder.create().texOffs(620, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.735563253408028F, -39.659869289590446F, -1.1191663682282051F, -2.8555420687659945F, -0.5307459740023602F, -0.4270927946651163F));
        g.addOrReplaceChild("domo_arena_80", CubeListBuilder.create().texOffs(588, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.1072650921605F, -35.84788507991347F, -2.914977203940961F, -2.0754922016264232F, -0.052768779895125247F, -1.5294328335041174F));
        g.addOrReplaceChild("domo_arena_81", CubeListBuilder.create().texOffs(100, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.93604541392983F, -37.28375802365976F, -2.754353168300189F, -2.0996257006293155F, -0.21964725339056046F, -1.3952164882494893F));
        g.addOrReplaceChild("domo_arena_82", CubeListBuilder.create().texOffs(110, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.597716224338175F, -38.33051865188429F, -2.4369609131058416F, -2.1736886689541004F, -0.42029317280169165F, -1.2141481942120123F));
        g.addOrReplaceChild("domo_arena_83", CubeListBuilder.create().texOffs(120, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.098461009564513F, -39.122898780595506F, -1.9686012698666524F, -2.3354106086612627F, -0.6359560037692843F, -0.9577965293615868F));
        g.addOrReplaceChild("domo_arena_84", CubeListBuilder.create().texOffs(628, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.43892818772198F, -39.659869289590446F, -1.3498825304284636F, -2.6859679173116286F, -0.6882301280315835F, -0.5020192895645273F));
        g.addOrReplaceChild("domo_arena_85", CubeListBuilder.create().texOffs(376, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.22768166401311F, -35.84788507991347F, -3.2454156211722522F, -1.812755823392988F, -0.05571045385840231F, -1.5454016508123916F));
        g.addOrReplaceChild("domo_arena_86", CubeListBuilder.create().texOffs(130, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.104929685536927F, -37.28375802365976F, -3.0665834321247636F, -1.8304093051338073F, -0.23351026546197026F, -1.462397504344778F));
        g.addOrReplaceChild("domo_arena_87", CubeListBuilder.create().texOffs(140, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.862372417425085F, -38.33051865188429F, -2.713211960933084F, -1.8866201299352143F, -0.4560626672048612F, -1.346407766108922F));
        g.addOrReplaceChild("domo_arena_88", CubeListBuilder.create().texOffs(872, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.50444296672575F, -39.122898780595506F, -2.1917596146025184F, -2.0217632400565013F, -0.7186278488386307F, -1.1648629204948382F));
        g.addOrReplaceChild("domo_arena_89", CubeListBuilder.create().texOffs(636, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.031606201771183F, -39.659869289590446F, -1.5029036402333367F, -2.467756940766781F, -0.8579407216860441F, -0.6534529293051083F));
        g.addOrReplaceChild("domo_arena_90", CubeListBuilder.create().texOffs(344, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.861587019275554F, -35.84788507991347F, -3.4107477745401047F, -1.6191867082979865F, -0.05599260181695853F, -1.5623987314147232F));
        g.addOrReplaceChild("domo_arena_91", CubeListBuilder.create().texOffs(468, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.814110975927893F, -37.28375802365976F, -3.222805285192764F, -1.62588254885952F, -0.235752279821453F, -1.5348123650400882F));
        g.addOrReplaceChild("domo_arena_92", CubeListBuilder.create().texOffs(626, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.72029856232674F, -38.33051865188429F, -2.8514319082082658F, -1.64768704274727F, -0.46680359341151595F, -1.4953295972104736F));
        g.addOrReplaceChild("domo_arena_93", CubeListBuilder.create().texOffs(838, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.581864344583337F, -39.122898780595506F, -2.3034150631012964F, -1.7033485124622205F, -0.7577554054596009F, -1.4290327239091047F));
        g.addOrReplaceChild("domo_arena_94", CubeListBuilder.create().texOffs(880, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.39898811702253F, -39.659869289590446F, -1.5794664981684354F, -1.8519617763812417F, -1.09170792723392F, -1.2798777147455587F));
        g.addOrReplaceChild("domo_arena_95", CubeListBuilder.create().texOffs(644, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.14813131162826F, -39.93161621713294F, -0.5864045420514867F, -2.7004090402041507F, -1.299431813822453F, -0.43249395136769675F));
        g.addOrReplaceChild("domo_arena_96", CubeListBuilder.create().texOffs(360, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-15.138412980767315F, -35.84788507991347F, -3.4107477745401047F, -1.5224059452942111F, -0.05599260181693178F, -1.5791939221746507F));
        g.addOrReplaceChild("domo_arena_97", CubeListBuilder.create().texOffs(482, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-15.185889024112612F, -37.28375802365976F, -3.2228052851927647F, -1.5157101047330148F, -0.23575227982135744F, -1.6067802885479119F));
        g.addOrReplaceChild("domo_arena_98", CubeListBuilder.create().texOffs(638, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.279701437709098F, -38.33051865188429F, -2.8514319082082658F, -1.4939056108463495F, -0.46680359341143446F, -1.6462630563755791F));
        g.addOrReplaceChild("domo_arena_99", CubeListBuilder.create().texOffs(848, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.418135655445614F, -39.122898780595506F, -2.303415063101297F, -1.438244141134092F, -0.757755405459851F, -1.7125599296737521F));
        g.addOrReplaceChild("domo_arena_100", CubeListBuilder.create().texOffs(888, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.601011882997323F, -39.659869289590446F, -1.5794664981684357F, -1.2896308772216851F, -1.091707927235381F, -1.8617149388306649F));
        g.addOrReplaceChild("domo_arena_101", CubeListBuilder.create().texOffs(652, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.851868688379113F, -39.93161621713294F, -0.5864045420514868F, -0.44118361340417633F, -1.2994318138330452F, -2.709098702203162F));
        g.addOrReplaceChild("domo_arena_102", CubeListBuilder.create().texOffs(390, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-13.772318335986892F, -35.84788507991347F, -3.2454156211722536F, -1.3288368301968065F, -0.055710453858402335F, -1.5961910027774018F));
        g.addOrReplaceChild("domo_arena_103", CubeListBuilder.create().texOffs(150, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.895070314463076F, -37.28375802365976F, -3.066583432124765F, -1.3111833484559872F, -0.2335102654619701F, -1.6791951492450146F));
        g.addOrReplaceChild("domo_arena_104", CubeListBuilder.create().texOffs(160, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.137627582574918F, -38.33051865188429F, -2.7132119609330845F, -1.2549725236545795F, -0.4560626672048616F, -1.7951848874808713F));
        g.addOrReplaceChild("domo_arena_105", CubeListBuilder.create().texOffs(896, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.495557033274252F, -39.122898780595506F, -2.1917596146025193F, -1.1198294135332931F, -0.718627848838631F, -1.9767297330949543F));
        g.addOrReplaceChild("domo_arena_106", CubeListBuilder.create().texOffs(660, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.96839379822882F, -39.659869289590446F, -1.5029036402333371F, -0.673835712823014F, -0.8579407216860454F, -2.488139724284683F));
        g.addOrReplaceChild("domo_arena_107", CubeListBuilder.create().texOffs(600, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.8927349078395F, -35.84788507991347F, -2.9149772039409623F, -1.0661004519633706F, -0.05276877989512489F, -1.612159820085675F));
        g.addOrReplaceChild("domo_arena_108", CubeListBuilder.create().texOffs(170, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.063954586070174F, -37.28375802365976F, -2.75435316830019F, -1.041966952960479F, -0.21964725339056057F, -1.7463761653403038F));
        g.addOrReplaceChild("domo_arena_109", CubeListBuilder.create().texOffs(180, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.402283775661829F, -38.33051865188429F, -2.436960913105842F, -0.9679039846356946F, -0.42029317280169215F, -1.9274444593777806F));
        g.addOrReplaceChild("domo_arena_110", CubeListBuilder.create().texOffs(190, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.90153899043549F, -39.122898780595506F, -1.968601269866653F, -0.8061820449285316F, -0.6359560037692846F, -2.1837961242282065F));
        g.addOrReplaceChild("domo_arena_111", CubeListBuilder.create().texOffs(668, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.561071812278023F, -39.659869289590446F, -1.3498825304284638F, -0.4556247362781659F, -0.6882301280315847F, -2.639573364025265F));
        g.addOrReplaceChild("domo_arena_112", CubeListBuilder.create().texOffs(612, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.252172166361621F, -35.84788507991347F, -2.416761738347056F, -0.73670563315925F, -0.039429503354100386F, -1.6320121262710325F));
        g.addOrReplaceChild("domo_arena_113", CubeListBuilder.create().texOffs(200, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.458688783614043F, -37.28375802365976F, -2.283590877500978F, -0.7126683660987679F, -0.18112410466663179F, -1.811517299659404F));
        g.addOrReplaceChild("domo_arena_114", CubeListBuilder.create().texOffs(210, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.86676454029249F, -38.33051865188429F, -2.0204459522630245F, -0.6419129509665606F, -0.3387806970938007F, -2.047215962371215F));
        g.addOrReplaceChild("domo_arena_115", CubeListBuilder.create().texOffs(220, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.468941224457161F, -39.122898780595506F, -1.632136340772397F, -0.48839614972904805F, -0.4360076284164951F, -2.378237314331924F));
        g.addOrReplaceChild("domo_arena_116", CubeListBuilder.create().texOffs(676, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.264436746591976F, -39.659869289590446F, -1.119166368228206F, -0.28605058482380014F, -0.5307459740023607F, -2.7144998589246767F));
        g.addOrReplaceChild("domo_arena_117", CubeListBuilder.create().texOffs(624, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.827322772778532F, -35.84788507991347F, -1.7326412942324225F, -0.3848357153307945F, -0.0282625281274612F, -1.6389311087264211F));
        g.addOrReplaceChild("domo_arena_118", CubeListBuilder.create().texOffs(230, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.057249872982448F, -37.28375802365976F, -1.6371675331953883F, -0.36943578432773366F, -0.11500019477868743F, -1.8559124261168571F));
        g.addOrReplaceChild("domo_arena_119", CubeListBuilder.create().texOffs(240, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.511584621657462F, -38.33051865188429F, -1.44851188021951F, -0.32608812502669016F, -0.21220723066073333F, -2.12307410139385F));
        g.addOrReplaceChild("domo_arena_120", CubeListBuilder.create().texOffs(250, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.182023352653903F, -39.122898780595506F, -1.1701223074533624F, -0.24755446824989755F, -0.30212301330492997F, -2.43243116726244F));
        g.addOrReplaceChild("domo_arena_121", CubeListBuilder.create().texOffs(684, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.067695319699995F, -39.659869289590446F, -0.8023603791553634F, -0.14286526600919267F, -0.36695370111968584F, -2.7535493915627582F));
        g.addOrReplaceChild("domo_arena_122", CubeListBuilder.create().texOffs(404, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.614752861305579F, -35.84788507991347F, -0.6701232372180382F, -0.07902898016674793F, -0.008321558400628782F, -1.6425972004303269F));
        g.addOrReplaceChild("domo_arena_123", CubeListBuilder.create().texOffs(650, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.85639320475216F, -37.28375802365976F, -0.6331974257252087F, -0.07571115317768304F, -0.0341747703360943F, -1.869974343639803F));
        g.addOrReplaceChild("domo_arena_124", CubeListBuilder.create().texOffs(662, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.333873260875087F, -38.33051865188429F, -0.5602322151461286F, -0.06647108480973352F, -0.06302364518581001F, -2.1461051160073223F));
        g.addOrReplaceChild("domo_arena_125", CubeListBuilder.create().texOffs(260, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.03846634744119F, -39.122898780595506F, -0.4525611569006634F, -0.05005984577679687F, -0.08963787247985934F, -2.4575255568024934F));
        g.addOrReplaceChild("domo_arena_126", CubeListBuilder.create().texOffs(270, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.969257359497727F, -39.659869289590446F, -0.31032409101924496F, -0.02864015577093368F, -0.10769407060975711F, -2.7716212871871755F));
        g.addOrReplaceChild("domo_arena_127", CubeListBuilder.create().texOffs(482, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.24605130307666F, -39.93161621713294F, -0.1152132423781731F, -0.007168354163784087F, -0.15102949096214366F, -3.051139310595273F));
        g.addOrReplaceChild("domo_vapor_0", CubeListBuilder.create().texOffs(418, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.38524713869442F, -35.932673587904816F, 0.6701232371976483F, 0.07906432488892606F, 0.0075684668950291795F, -1.6360893058830563F));
        g.addOrReplaceChild("domo_vapor_1", CubeListBuilder.create().texOffs(674, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.143606795247839F, -37.51213382602573F, 0.6331974257059422F, 0.07628882261566108F, 0.03130699397992647F, -1.8441723915771253F));
        g.addOrReplaceChild("domo_vapor_2", CubeListBuilder.create().texOffs(686, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.6661267391249135F, -38.66357051707272F, 0.5602322151290824F, 0.06824843795211688F, 0.058836282891328286F, -2.1034823722769413F));
        g.addOrReplaceChild("domo_vapor_3", CubeListBuilder.create().texOffs(280, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.96153365255881F, -39.53518865865505F, 0.45256115688689325F, 0.052893510509811746F, 0.08611958801437228F, -2.410464358737384F));
        g.addOrReplaceChild("domo_vapor_4", CubeListBuilder.create().texOffs(290, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.030742640502274F, -40.125856218549494F, 0.3103240910098027F, 0.031080666876358316F, 0.10625732941537448F, -2.738356337358019F));
        g.addOrReplaceChild("domo_vapor_5", CubeListBuilder.create().texOffs(492, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(2.75394869692334F, -40.42477783884624F, 0.11521324237466748F, 0.007878422275711287F, 0.15090221630529108F, -3.042150810202705F));
        g.addOrReplaceChild("domo_vapor_6", CubeListBuilder.create().texOffs(636, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.172677227221468F, -35.932673587904816F, 1.7326412942324207F, 0.3849987212032422F, 0.025704731201978057F, -1.6327536653770998F));
        g.addOrReplaceChild("domo_vapor_7", CubeListBuilder.create().texOffs(300, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.942750127017553F, -37.51213382602573F, 1.6371675331953863F, 0.3721231000145434F, 0.10534592457201518F, -1.8312020886659386F));
        g.addOrReplaceChild("domo_vapor_8", CubeListBuilder.create().texOffs(310, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.488415378342538F, -38.66357051707272F, 1.4485118802195083F, 0.3344779933948486F, 0.1980850433155329F, -2.081453209398476F));
        g.addOrReplaceChild("domo_vapor_9", CubeListBuilder.create().texOffs(320, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.8179766473460965F, -39.53518865865505F, 1.170122307453361F, 0.26124336448161756F, 0.290217604504333F, -2.385057155808591F));
        g.addOrReplaceChild("domo_vapor_10", CubeListBuilder.create().texOffs(692, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.932304680300005F, -40.125856218549494F, 0.8023603791553625F, 0.15493413985673182F, 0.3620208380226428F, -2.719032879383512F));
        g.addOrReplaceChild("domo_vapor_11", CubeListBuilder.create().texOffs(648, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.747827833638379F, -35.932673587904816F, 2.416761738347055F, 0.7369891375027342F, 0.03585986494326288F, -1.6264591137884659F));
        g.addOrReplaceChild("domo_vapor_12", CubeListBuilder.create().texOffs(330, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.5413112163859575F, -37.51213382602573F, 2.283590877500977F, 0.7169276210712324F, 0.16577293916062463F, -1.790364524128496F));
        g.addOrReplaceChild("domo_vapor_13", CubeListBuilder.create().texOffs(340, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.13323545970751F, -38.66357051707272F, 2.0204459522630236F, 0.6559114583650015F, 0.3154378157261394F, -2.009470583851837F));
        g.addOrReplaceChild("domo_vapor_14", CubeListBuilder.create().texOffs(350, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.5310587755428395F, -39.53518865865505F, 1.6321363407723966F, 0.5140573623340794F, 0.4179824993528926F, -2.3306005522960342F));
        g.addOrReplaceChild("domo_vapor_15", CubeListBuilder.create().texOffs(700, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.735563253408025F, -40.125856218549494F, 1.1191663682282056F, 0.3097706985845887F, 0.5230530415575524F, -2.6774509965147693F));
        g.addOrReplaceChild("domo_vapor_16", CubeListBuilder.create().texOffs(660, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.1072650921605F, -35.932673587904816F, 2.914977203940961F, 1.0659608392216327F, 0.04326486040386537F, -1.6169603672288249F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("domo_vapor_17", CubeListBuilder.create().texOffs(360, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.936045413929827F, -37.51213382602573F, 2.754353168300189F, 1.0462562337888588F, 0.20074569166431075F, -1.730709592520402F));
        g.addOrReplaceChild("domo_vapor_18", CubeListBuilder.create().texOffs(370, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.597716224338173F, -38.66357051707272F, 2.4369609131058416F, 0.9829915857911079F, 0.3896249557472402F, -1.8974408099438487F));
        g.addOrReplaceChild("domo_vapor_19", CubeListBuilder.create().texOffs(380, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0984610095645095F, -39.53518865865505F, 1.9686012698666526F, 0.8372786379406248F, 0.60477965969847F, -2.139840808719505F));
        g.addOrReplaceChild("domo_vapor_20", CubeListBuilder.create().texOffs(708, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.438928187721979F, -40.125856218549494F, 1.3498825304284636F, 0.49164220890968025F, 0.67661119719186F, -2.598369018095948F));
        g.addOrReplaceChild("domo_vapor_21", CubeListBuilder.create().texOffs(432, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.2276816640131125F, -35.932673587904816F, 3.2454156211722527F, 1.3290185616517356F, 0.05065773255015074F, -1.5938834799140906F));
        g.addOrReplaceChild("domo_vapor_22", CubeListBuilder.create().texOffs(390, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.104929685536925F, -37.51213382602573F, 3.0665834321247636F, 1.314343864676408F, 0.21315431425808992F, -1.6694230745382705F));
        g.addOrReplaceChild("domo_vapor_23", CubeListBuilder.create().texOffs(400, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.8623724174250826F, -38.66357051707272F, 2.713211960933084F, 1.266682866048155F, 0.42106817772254934F, -1.7754722987918523F));
        g.addOrReplaceChild("domo_vapor_24", CubeListBuilder.create().texOffs(410, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.50444296672575F, -39.53518865865505F, 2.1917596146025184F, 1.1473155552218999F, 0.6783745743961305F, -1.943521991536424F));
        g.addOrReplaceChild("domo_vapor_25", CubeListBuilder.create().texOffs(716, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.031606201771181F, -40.125856218549494F, 1.502903640233337F, 0.7207746969731584F, 0.8394043840085421F, -2.441624529360653F));
        g.addOrReplaceChild("domo_vapor_26", CubeListBuilder.create().texOffs(376, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.861587019264053F, -35.932673587904816F, 3.4107477745401047F, 1.5224744951957712F, 0.05091190446358385F, -1.5784305645549999F));
        g.addOrReplaceChild("domo_vapor_27", CubeListBuilder.create().texOffs(496, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.8141109759170257F, -37.51213382602573F, 3.222805285192764F, 1.516914215820205F, 0.21502895975392924F, -1.6035135361293675F));
        g.addOrReplaceChild("domo_vapor_28", CubeListBuilder.create().texOffs(698, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.7202985623171245F, -38.66357051707272F, 2.8514319082082658F, 1.4985091452981307F, 0.4297864111823685F, -1.639438860930499F));
        g.addOrReplaceChild("domo_vapor_29", CubeListBuilder.create().texOffs(858, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.581864344575571F, -39.53518865865505F, 2.3034150631012964F, 1.4499746798962252F, 0.7112236232711313F, -1.699862995635859F));
        g.addOrReplaceChild("domo_vapor_30", CubeListBuilder.create().texOffs(904, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.398988117017204F, -40.125856218549494F, 1.5794664981684354F, 1.3151515812572032F, 1.0547580874895286F, -1.8366064552609822F));
        g.addOrReplaceChild("domo_vapor_31", CubeListBuilder.create().texOffs(724, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(2.14813131162628F, -40.42477783884624F, 0.5864045420514867F, 0.4794089178775339F, 1.2947177566761585F, -2.6717187309178265F));
        g.addOrReplaceChild("domo_vapor_32", CubeListBuilder.create().texOffs(392, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.1384129807558145F, -35.932673587904816F, 3.4107477745401047F, 1.6191181583929093F, 0.050911904463572646F, -1.5631620890349698F));
        g.addOrReplaceChild("domo_vapor_33", CubeListBuilder.create().texOffs(510, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.1858890241017468F, -37.51213382602573F, 3.2228052851927647F, 1.6246784377683456F, 0.21502895975388733F, -1.5380791174611819F));
        g.addOrReplaceChild("domo_vapor_34", CubeListBuilder.create().texOffs(710, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.2797014376994846F, -38.66357051707272F, 2.8514319082082658F, 1.643083508289994F, 0.4297864111823245F, -1.502153792660873F));
        g.addOrReplaceChild("domo_vapor_35", CubeListBuilder.create().texOffs(868, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.4181356554378461F, -39.53518865865505F, 2.303415063101297F, 1.6916179736908052F, 0.7112236232712077F, -1.4417296579568692F));
        g.addOrReplaceChild("domo_vapor_36", CubeListBuilder.create().texOffs(912, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.6010118829919968F, -40.125856218549494F, 1.5794664981684357F, 1.826441072326997F, 1.0547580874901086F, -1.3049861983346152F));
        g.addOrReplaceChild("domo_vapor_37", CubeListBuilder.create().texOffs(732, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.8518686883771354F, -40.42477783884624F, 0.5864045420514868F, 2.662183735703154F, 1.2947177566809662F, -0.46987392268127604F));
        g.addOrReplaceChild("domo_vapor_38", CubeListBuilder.create().texOffs(446, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.22768166401311096F, -35.932673587904816F, 3.245415621172253F, 1.8125740919380575F, 0.05065773255015086F, -1.547709173675703F));
        g.addOrReplaceChild("domo_vapor_39", CubeListBuilder.create().texOffs(420, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.104929685536924F, -37.51213382602573F, 3.0665834321247645F, 1.8272487889133848F, 0.21315431425808973F, -1.472169579051523F));
        g.addOrReplaceChild("domo_vapor_40", CubeListBuilder.create().texOffs(430, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.13762758257491897F, -38.66357051707272F, 2.7132119609330845F, 1.8749097875416383F, 0.4210681777225495F, -1.3661203547979408F));
        g.addOrReplaceChild("domo_vapor_41", CubeListBuilder.create().texOffs(440, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.4955570332742508F, -39.53518865865505F, 2.191759614602519F, 1.994277098367893F, 0.6783745743961306F, -1.1980706620533697F));
        g.addOrReplaceChild("domo_vapor_42", CubeListBuilder.create().texOffs(740, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.9683937982288201F, -40.125856218549494F, 1.5029036402333371F, 2.4208179566166343F, 0.8394043840085423F, -0.6999681242291407F));
        g.addOrReplaceChild("domo_vapor_43", CubeListBuilder.create().texOffs(672, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.1072650921604992F, -35.932673587904816F, 2.9149772039409614F, 2.07563181436816F, 0.04326486040386537F, -1.5246322863609687F));
        g.addOrReplaceChild("domo_vapor_44", CubeListBuilder.create().texOffs(450, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.9360454139298271F, -37.51213382602573F, 2.7543531683001894F, 2.095336419800934F, 0.20074569166431075F, -1.4108830610693914F));
        g.addOrReplaceChild("domo_vapor_45", CubeListBuilder.create().texOffs(460, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.5977162243381724F, -38.66357051707272F, 2.4369609131058416F, 2.158601067798685F, 0.3896249557472402F, -1.2441518436459447F));
        g.addOrReplaceChild("domo_vapor_46", CubeListBuilder.create().texOffs(470, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.0984610095645096F, -39.53518865865505F, 1.968601269866653F, 2.304314015649168F, 0.6047796596984703F, -1.0017518448702882F));
        g.addOrReplaceChild("domo_vapor_47", CubeListBuilder.create().texOffs(748, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.5610718122780214F, -40.125856218549494F, 1.3498825304284638F, 2.6499504446801128F, 0.6766111971918604F, -0.5432236354938453F));
        g.addOrReplaceChild("domo_vapor_48", CubeListBuilder.create().texOffs(684, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.7478278336383783F, -35.932673587904816F, 2.4167617383470557F, 2.4046035160870582F, 0.03585986494326277F, -1.5151335398013277F));
        g.addOrReplaceChild("domo_vapor_49", CubeListBuilder.create().texOffs(480, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.5413112163859575F, -37.51213382602573F, 2.2835908775009774F, 2.4246650325185604F, 0.1657729391606248F, -1.3512281294612971F));
        g.addOrReplaceChild("domo_vapor_50", CubeListBuilder.create().texOffs(490, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.1332354597075105F, -38.66357051707272F, 2.0204459522630236F, 2.485681195224791F, 0.3154378157261395F, -1.1321220697379566F));
        g.addOrReplaceChild("domo_vapor_51", CubeListBuilder.create().texOffs(500, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.5310587755428395F, -39.53518865865505F, 1.632136340772397F, 2.6275352912557137F, 0.41798249935289267F, -0.8109921012937586F));
        g.addOrReplaceChild("domo_vapor_52", CubeListBuilder.create().texOffs(756, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.2644367465919753F, -40.125856218549494F, 1.119166368228206F, 2.8318219550052044F, 0.5230530415575525F, -0.4641416570750238F));
        g.addOrReplaceChild("domo_vapor_53", CubeListBuilder.create().texOffs(696, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.1726772272214676F, -35.932673587904816F, 1.7326412942324216F, 2.7565939323865503F, 0.025704731201978002F, -1.5088389882126936F));
        g.addOrReplaceChild("domo_vapor_54", CubeListBuilder.create().texOffs(510, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.9427501270175533F, -37.51213382602573F, 1.6371675331953874F, 2.76946955357525F, 0.10534592457201518F, -1.3103905649238543F));
        g.addOrReplaceChild("domo_vapor_55", CubeListBuilder.create().texOffs(520, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.488415378342537F, -38.66357051707272F, 1.4485118802195092F, 2.8071146601949457F, 0.1980850433155326F, -1.0601394441913174F));
        g.addOrReplaceChild("domo_vapor_56", CubeListBuilder.create().texOffs(530, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.8179766473460957F, -39.53518865865505F, 1.1701223074533618F, 2.8803492891081763F, 0.29021760450433276F, -0.7565354977812022F));
        g.addOrReplaceChild("domo_vapor_57", CubeListBuilder.create().texOffs(764, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.06769531969999537F, -40.125856218549494F, 0.8023603791553631F, 2.9866585137330612F, 0.362020838022643F, -0.42255977420628105F));
        g.addOrReplaceChild("domo_vapor_58", CubeListBuilder.create().texOffs(460, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.38524713869442F, -35.932673587904816F, 0.6701232372101994F, 3.0625283286993925F, 0.007568466895171513F, -1.5055033477067299F));
        g.addOrReplaceChild("domo_vapor_59", CubeListBuilder.create().texOffs(722, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.1436067952478397F, -37.51213382602573F, 0.6331974257178017F, 3.06530383097271F, 0.031306993980514446F, -1.2974202620126398F));
        g.addOrReplaceChild("domo_vapor_60", CubeListBuilder.create().texOffs(734, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.666126739124913F, -38.66357051707272F, 0.5602322151395751F, 3.073344215636405F, 0.05883628289243028F, -1.0381102813128051F));
        g.addOrReplaceChild("domo_vapor_61", CubeListBuilder.create().texOffs(540, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.9615336525588101F, -39.53518865865505F, 0.45256115689536947F, 3.088699143078998F, 0.086119588015978F, -0.7311282948523556F));
        g.addOrReplaceChild("domo_vapor_62", CubeListBuilder.create().texOffs(550, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.03074264050227432F, -40.125856218549494F, 0.3103240910156149F, 3.1105119867128583F, 0.10625732941734672F, -0.4032363162317356F));
        g.addOrReplaceChild("domo_vapor_63", CubeListBuilder.create().texOffs(502, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.2460513030766598F, -40.42477783884624F, 0.11521324237682537F, 3.1337142313139346F, 0.15090221630807465F, -0.09944184338708852F));
        g.addOrReplaceChild("domo_vapor_64", CubeListBuilder.create().texOffs(474, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.385247138694421F, -35.932673587904816F, -0.6701232371850969F, -3.062528328702342F, -0.007568466894886925F, -1.5055033477067439F));
        g.addOrReplaceChild("domo_vapor_65", CubeListBuilder.create().texOffs(746, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.14360679524784F, -37.51213382602573F, -0.6331974256940824F, -3.0653038309755547F, -0.03130699397933834F, -1.2974202620126958F));
        g.addOrReplaceChild("domo_vapor_66", CubeListBuilder.create().texOffs(758, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.6661267391249135F, -38.66357051707272F, -0.5602322151185892F, -3.0733442156389468F, -0.05883628289022653F, -1.0381102813128993F));
        g.addOrReplaceChild("domo_vapor_67", CubeListBuilder.create().texOffs(560, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.9615336525588104F, -39.53518865865505F, -0.4525611568784167F, -3.088699143080964F, -0.08611958801276695F, -0.7311282948524627F));
        g.addOrReplaceChild("domo_vapor_68", CubeListBuilder.create().texOffs(570, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.030742640502274488F, -40.125856218549494F, -0.31032409100399033F, -3.110511986714011F, -0.10625732941340255F, -0.40323631623181333F));
        g.addOrReplaceChild("domo_vapor_69", CubeListBuilder.create().texOffs(512, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.2460513030766598F, -40.42477783884624F, -0.11521324237250954F, -3.1337142313142294F, -0.15090221630250733F, -0.09944184338708852F));
        g.addOrReplaceChild("domo_vapor_70", CubeListBuilder.create().texOffs(708, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.172677227221469F, -35.932673587904816F, -1.732641294232419F, -2.756593932386551F, -0.025704731201978057F, -1.5088389882126934F));
        g.addOrReplaceChild("domo_vapor_71", CubeListBuilder.create().texOffs(580, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.9427501270175545F, -37.51213382602573F, -1.6371675331953846F, -2.76946955357525F, -0.10534592457201503F, -1.3103905649238543F));
        g.addOrReplaceChild("domo_vapor_72", CubeListBuilder.create().texOffs(590, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.488415378342538F, -38.66357051707272F, -1.448511880219507F, -2.8071146601949453F, -0.19808504331553242F, -1.0601394441913172F));
        g.addOrReplaceChild("domo_vapor_73", CubeListBuilder.create().texOffs(600, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.8179766473460964F, -39.53518865865505F, -1.1701223074533598F, -2.8803492891081763F, -0.29021760450433254F, -0.756535497781202F));
        g.addOrReplaceChild("domo_vapor_74", CubeListBuilder.create().texOffs(772, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.06769531969999482F, -40.125856218549494F, -0.8023603791553616F, -2.9866585137330617F, -0.3620208380226425F, -0.42255977420628094F));
        g.addOrReplaceChild("domo_vapor_75", CubeListBuilder.create().texOffs(720, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.7478278336383797F, -35.932673587904816F, -2.4167617383470543F, -2.4046035160870596F, -0.03585986494326289F, -1.5151335398013277F));
        g.addOrReplaceChild("domo_vapor_76", CubeListBuilder.create().texOffs(610, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.5413112163859584F, -37.51213382602573F, -2.283590877500976F, -2.4246650325185617F, -0.16577293916062452F, -1.3512281294612971F));
        g.addOrReplaceChild("domo_vapor_77", CubeListBuilder.create().texOffs(620, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.1332354597075116F, -38.66357051707272F, -2.0204459522630227F, -2.4856811952247932F, -0.31543781572613916F, -1.1321220697379561F));
        g.addOrReplaceChild("domo_vapor_78", CubeListBuilder.create().texOffs(630, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.5310587755428403F, -39.53518865865505F, -1.6321363407723957F, -2.6275352912557146F, -0.4179824993528923F, -0.8109921012937585F));
        g.addOrReplaceChild("domo_vapor_79", CubeListBuilder.create().texOffs(780, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.2644367465919747F, -40.125856218549494F, -1.1191663682282051F, -2.831821955005205F, -0.5230530415575522F, -0.4641416570750238F));
        g.addOrReplaceChild("domo_vapor_80", CubeListBuilder.create().texOffs(732, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.1072650921605007F, -35.932673587904816F, -2.914977203940961F, -2.0756318143681605F, -0.04326486040386537F, -1.5246322863609685F));
        g.addOrReplaceChild("domo_vapor_81", CubeListBuilder.create().texOffs(640, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.9360454139298287F, -37.51213382602573F, -2.754353168300189F, -2.095336419800935F, -0.2007456916643106F, -1.4108830610693912F));
        g.addOrReplaceChild("domo_vapor_82", CubeListBuilder.create().texOffs(650, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.5977162243381738F, -38.66357051707272F, -2.4369609131058416F, -2.1586010677986858F, -0.3896249557472401F, -1.2441518436459442F));
        g.addOrReplaceChild("domo_vapor_83", CubeListBuilder.create().texOffs(660, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.0984610095645107F, -39.53518865865505F, -1.9686012698666524F, -2.3043140156491684F, -0.60477965969847F, -1.001751844870288F));
        g.addOrReplaceChild("domo_vapor_84", CubeListBuilder.create().texOffs(788, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.5610718122780205F, -40.125856218549494F, -1.3498825304284636F, -2.649950444680113F, -0.67661119719186F, -0.5432236354938453F));
        g.addOrReplaceChild("domo_vapor_85", CubeListBuilder.create().texOffs(488, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.22768166401311474F, -35.932673587904816F, -3.2454156211722522F, -1.8125740919380582F, -0.05065773255015076F, -1.5477091736757027F));
        g.addOrReplaceChild("domo_vapor_86", CubeListBuilder.create().texOffs(670, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.10492968553692755F, -37.51213382602573F, -3.0665834321247636F, -1.8272487889133855F, -0.21315431425808976F, -1.472169579051523F));
        g.addOrReplaceChild("domo_vapor_87", CubeListBuilder.create().texOffs(680, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.1376275825749158F, -38.66357051707272F, -2.713211960933084F, -1.874909787541639F, -0.42106817772254934F, -1.3661203547979406F));
        g.addOrReplaceChild("domo_vapor_88", CubeListBuilder.create().texOffs(690, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.4955570332742483F, -39.53518865865505F, -2.1917596146025184F, -1.994277098367894F, -0.6783745743961306F, -1.198070662053369F));
        g.addOrReplaceChild("domo_vapor_89", CubeListBuilder.create().texOffs(796, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.9683937982288184F, -40.125856218549494F, -1.5029036402333367F, -2.4208179566166352F, -0.839404384008542F, -0.6999681242291399F));
        g.addOrReplaceChild("domo_vapor_90", CubeListBuilder.create().texOffs(408, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.1384129807244465F, -35.932673587904816F, -3.4107477745401047F, -1.619118158394666F, -0.05091190446359042F, -1.5631620890346911F));
        g.addOrReplaceChild("domo_vapor_91", CubeListBuilder.create().texOffs(524, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.185889024072107F, -37.51213382602573F, -3.222805285192764F, -1.6246784377703076F, -0.21502895975395334F, -1.5380791174599884F));
        g.addOrReplaceChild("domo_vapor_92", CubeListBuilder.create().texOffs(770, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.2797014376732605F, -38.66357051707272F, -2.8514319082082658F, -1.6430835082926278F, -0.429786411182394F, -1.50215379265838F));
        g.addOrReplaceChild("domo_vapor_93", CubeListBuilder.create().texOffs(878, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.4181356554166618F, -39.53518865865505F, -2.3034150631012964F, -1.691617973695167F, -0.7112236232710871F, -1.441729657952235F));
        g.addOrReplaceChild("domo_vapor_94", CubeListBuilder.create().texOffs(920, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.6010118829774707F, -40.125856218549494F, -1.5794664981684354F, -1.8264410723358269F, -1.0547580874891926F, -1.304986198325452F));
        g.addOrReplaceChild("domo_vapor_95", CubeListBuilder.create().texOffs(804, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.8518686883717423F, -40.42477783884624F, -0.5864045420514867F, -2.66218373571753F, -1.2947177566733754F, -0.4698739226665782F));
        g.addOrReplaceChild("domo_vapor_96", CubeListBuilder.create().texOffs(424, 225).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.8615870192326858F, -35.932673587904816F, -3.4107477745401047F, -1.522474495197528F, -0.05091190446356607F, -1.5784305645547212F));
        g.addOrReplaceChild("domo_vapor_97", CubeListBuilder.create().texOffs(538, 225).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.8141109758873872F, -37.51213382602573F, -3.2228052851927647F, -1.516914215822167F, -0.21502895975386324F, -1.603513536128174F));
        g.addOrReplaceChild("domo_vapor_98", CubeListBuilder.create().texOffs(782, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.7202985622909015F, -38.66357051707272F, -2.8514319082082658F, -1.4985091453007648F, -0.4297864111822989F, -1.6394388609280062F));
        g.addOrReplaceChild("domo_vapor_99", CubeListBuilder.create().texOffs(888, 242).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.5818643445543876F, -39.53518865865505F, -2.303415063101297F, -1.449974679900587F, -0.711223623271252F, -1.699862995631225F));
        g.addOrReplaceChild("domo_vapor_100", CubeListBuilder.create().texOffs(928, 255).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.398988117002678F, -40.125856218549494F, -1.5794664981684357F, -1.3151515812660333F, -1.0547580874904445F, -1.8366064552518189F));
        g.addOrReplaceChild("domo_vapor_101", CubeListBuilder.create().texOffs(812, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(2.1481313116208876F, -40.42477783884624F, -0.5864045420514868F, -0.47940891789190965F, -1.294717756683749F, -2.671718730903129F));
        g.addOrReplaceChild("domo_vapor_102", CubeListBuilder.create().texOffs(502, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.22768166401311F, -35.932673587904816F, -3.2454156211722536F, -1.3290185616517363F, -0.05065773255015074F, -1.5938834799140906F));
        g.addOrReplaceChild("domo_vapor_103", CubeListBuilder.create().texOffs(700, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.1049296855369235F, -37.51213382602573F, -3.066583432124765F, -1.3143438646764092F, -0.21315431425808967F, -1.6694230745382699F));
        g.addOrReplaceChild("domo_vapor_104", CubeListBuilder.create().texOffs(710, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.8623724174250804F, -38.66357051707272F, -2.7132119609330845F, -1.2666828660481557F, -0.42106817772254956F, -1.7754722987918523F));
        g.addOrReplaceChild("domo_vapor_105", CubeListBuilder.create().texOffs(720, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.5044429667257484F, -39.53518865865505F, -2.1917596146025193F, -1.1473155552219008F, -0.6783745743961307F, -1.9435219915364235F));
        g.addOrReplaceChild("domo_vapor_106", CubeListBuilder.create().texOffs(820, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0316062017711793F, -40.125856218549494F, -1.5029036402333371F, -0.7207746969731591F, -0.8394043840085428F, -2.441624529360652F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("domo_vapor_107", CubeListBuilder.create().texOffs(744, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.107265092160498F, -35.932673587904816F, -2.9149772039409623F, -1.065960839221634F, -0.04326486040386525F, -1.6169603672288244F));
        g.addOrReplaceChild("domo_vapor_108", CubeListBuilder.create().texOffs(730, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.936045413929826F, -37.51213382602573F, -2.75435316830019F, -1.0462562337888597F, -0.20074569166431067F, -1.7307095925204015F));
        g.addOrReplaceChild("domo_vapor_109", CubeListBuilder.create().texOffs(740, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.597716224338172F, -38.66357051707272F, -2.436960913105842F, -0.9829915857911086F, -0.38962495574724043F, -1.897440809943849F));
        g.addOrReplaceChild("domo_vapor_110", CubeListBuilder.create().texOffs(750, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0984610095645095F, -39.53518865865505F, -1.968601269866653F, -0.8372786379406253F, -0.60477965969847F, -2.1398408087195055F));
        g.addOrReplaceChild("domo_vapor_111", CubeListBuilder.create().texOffs(828, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.438928187721978F, -40.125856218549494F, -1.3498825304284638F, -0.4916422089096806F, -0.6766111971918606F, -2.5983690180959473F));
        g.addOrReplaceChild("domo_vapor_112", CubeListBuilder.create().texOffs(756, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.747827833638379F, -35.932673587904816F, -2.416761738347056F, -0.736989137502734F, -0.03585986494326277F, -1.6264591137884654F));
        g.addOrReplaceChild("domo_vapor_113", CubeListBuilder.create().texOffs(760, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.5413112163859575F, -37.51213382602573F, -2.283590877500978F, -0.7169276210712315F, -0.16577293916062463F, -1.7903645241284962F));
        g.addOrReplaceChild("domo_vapor_114", CubeListBuilder.create().texOffs(770, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.13323545970751F, -38.66357051707272F, -2.0204459522630245F, -0.6559114583650014F, -0.31543781572613955F, -2.009470583851837F));
        g.addOrReplaceChild("domo_vapor_115", CubeListBuilder.create().texOffs(780, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.5310587755428395F, -39.53518865865505F, -1.632136340772397F, -0.5140573623340795F, -0.4179824993528924F, -2.3306005522960347F));
        g.addOrReplaceChild("domo_vapor_116", CubeListBuilder.create().texOffs(836, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.7355632534080243F, -40.125856218549494F, -1.119166368228206F, -0.30977069858458894F, -0.5230530415575526F, -2.6774509965147693F));
        g.addOrReplaceChild("domo_vapor_117", CubeListBuilder.create().texOffs(768, 252).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.172677227221468F, -35.932673587904816F, -1.7326412942324225F, -0.38499872120324385F, -0.025704731201978F, -1.6327536653770998F));
        g.addOrReplaceChild("domo_vapor_118", CubeListBuilder.create().texOffs(790, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.942750127017553F, -37.51213382602573F, -1.6371675331953883F, -0.37212310001454457F, -0.10534592457201541F, -1.8312020886659388F));
        g.addOrReplaceChild("domo_vapor_119", CubeListBuilder.create().texOffs(800, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.488415378342537F, -38.66357051707272F, -1.44851188021951F, -0.3344779933948488F, -0.1980850433155328F, -2.0814532093984757F));
        g.addOrReplaceChild("domo_vapor_120", CubeListBuilder.create().texOffs(810, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.817976647346096F, -39.53518865865505F, -1.1701223074533624F, -0.261243364481618F, -0.29021760450433354F, -2.385057155808591F));
        g.addOrReplaceChild("domo_vapor_121", CubeListBuilder.create().texOffs(844, 262).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.932304680300005F, -40.125856218549494F, -0.8023603791553634F, -0.1549341398567327F, -0.36202083802264323F, -2.719032879383512F));
        g.addOrReplaceChild("domo_vapor_122", CubeListBuilder.create().texOffs(516, 242).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.385247138694421F, -35.932673587904816F, -0.6701232372180382F, -0.07906432489132133F, -0.007568466895260304F, -1.6360893058830677F));
        g.addOrReplaceChild("domo_vapor_123", CubeListBuilder.create().texOffs(794, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.143606795247839F, -37.51213382602573F, -0.6331974257252087F, -0.07628882261797156F, -0.03130699398088163F, -1.8441723915771708F));
        g.addOrReplaceChild("domo_vapor_124", CubeListBuilder.create().texOffs(806, 242).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.6661267391249135F, -38.66357051707272F, -0.5602322151461286F, -0.0682484379541817F, -0.058836282893118534F, -2.1034823722770177F));
        g.addOrReplaceChild("domo_vapor_125", CubeListBuilder.create().texOffs(820, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.96153365255881F, -39.53518865865505F, -0.4525611569006634F, -0.05289351051140874F, -0.0861195880169806F, -2.4104643587374706F));
        g.addOrReplaceChild("domo_vapor_126", CubeListBuilder.create().texOffs(830, 255).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.030742640502274F, -40.125856218549494F, -0.31032409101924496F, -0.031080666877294688F, -0.10625732941857803F, -2.738356337358082F));
        g.addOrReplaceChild("domo_vapor_127", CubeListBuilder.create().texOffs(522, 262).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(2.75394869692334F, -40.42477783884624F, -0.1152132423781731F, -0.007878422275950685F, -0.1509022163098132F, -3.042150810202705F));
        g.addOrReplaceChild("valvulas_0", CubeListBuilder.create().texOffs(244, 214).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(774, 169).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(18.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvulas_1", CubeListBuilder.create().texOffs(278, 214).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(808, 169).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(18.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasamanos", CubeListBuilder.create().texOffs(0, 258).addBox(-52.0F, -34.0F, 9.5F, 88.0F, 1.0F, 1.0F).texOffs(178, 258).addBox(-52.0F, -34.0F, -10.5F, 88.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("deflectori", CubeListBuilder.create().texOffs(846, 56).addBox(0.0F, -36.0F, -0.5F, 44.0F, 36.0F, 1.0F), PartPose.offset(-58.0F, -20.0F, -13.0F));
        g.addOrReplaceChild("deflectord", CubeListBuilder.create().texOffs(0, 99).addBox(0.0F, -36.0F, -0.5F, 44.0F, 36.0F, 1.0F), PartPose.offset(-58.0F, -20.0F, 13.0F));
        g.addOrReplaceChild("faro1_0", CubeListBuilder.create().texOffs(966, 238).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(708, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, -8.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro1_1", CubeListBuilder.create().texOffs(990, 238).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(732, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, -8.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro1_2", CubeListBuilder.create().texOffs(0, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(756, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, -8.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro1_3", CubeListBuilder.create().texOffs(24, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(780, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, -8.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro1_vidrio", CubeListBuilder.create().texOffs(352, 190).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-60.22F, -22.0F, -8.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro18_0", CubeListBuilder.create().texOffs(48, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(804, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, 8.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro18_1", CubeListBuilder.create().texOffs(72, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(828, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, 8.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro18_2", CubeListBuilder.create().texOffs(96, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(852, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, 8.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro18_3", CubeListBuilder.create().texOffs(120, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(876, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-59.0F, -22.0F, 8.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro18_vidrio", CubeListBuilder.create().texOffs(396, 190).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-60.22F, -22.0F, 8.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro10_0", CubeListBuilder.create().texOffs(144, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(900, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.6F, -36.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro10_1", CubeListBuilder.create().texOffs(168, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(924, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.6F, -36.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro10_2", CubeListBuilder.create().texOffs(192, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(948, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.6F, -36.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro10_3", CubeListBuilder.create().texOffs(216, 242).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(972, 190).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.6F, -36.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro10_vidrio", CubeListBuilder.create().texOffs(440, 190).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-56.82F, -36.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(168, 169).addBox(41.0F, -38.0F, 11.5F, 19.0F, 18.0F, 1.0F).texOffs(208, 169).addBox(41.0F, -38.0F, -12.5F, 19.0F, 18.0F, 1.0F).texOffs(728, 136).addBox(41.0F, -21.0F, -11.5F, 19.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(90, 99).addBox(0.0F, -9.0F, 0.0F, 1.0F, 9.0F, 25.0F), PartPose.offset(40.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(0, 169).addBox(41.0F, -32.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(722, 214).addBox(43.0F, -26.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(772, 225).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -38.39456479005479F, -11.520978263179149F, -2.7003688404552286F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(824, 225).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -39.239360202900706F, -9.529030799879887F, -2.780591351934236F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(876, 225).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -39.921810987376546F, -7.475790698752359F, -2.860813863413251F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(928, 225).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -40.437527483122615F, -5.3744648120500464F, -2.941036374892263F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(0, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -40.78319249817473F, -3.2385692894462643F, -3.0212588863712795F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(52, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -40.956582645808425F, -1.081842639447839F, -3.101481397850285F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(104, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -40.956582645808425F, 1.0818426394478375F, 3.1014813978502844F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(156, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -40.78319249817473F, 3.2385692894462617F, 3.0212588863712795F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(208, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -40.437527483122615F, 5.374464812050045F, 2.941036374892263F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(260, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -39.921810987376546F, 7.475790698752357F, 2.8608138634132505F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(312, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -39.239360202900706F, 9.529030799879884F, 2.780591351934236F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(364, 230).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -38.39456479005479F, 11.520978263179149F, 2.700368840455229F, 0.0F, 0.0F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(74.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(702, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(88.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(88.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(88.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(120.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(120.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(120.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 225).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(134.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(134.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(134.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(74.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(742, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(88.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(88.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(88.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(752, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(120.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(120.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(120.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(996, 190).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(240, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(762, 225).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(134.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(264, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(134.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(288, 225).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 202).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(134.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_bogies", CubeListBuilder.create().texOffs(312, 214).addBox(69.0F, -9.0F, 7.0F, 24.0F, 6.0F, 1.0F).texOffs(362, 214).addBox(69.0F, -9.0F, -8.0F, 24.0F, 6.0F, 1.0F).texOffs(412, 214).addBox(115.0F, -9.0F, 7.0F, 24.0F, 6.0F, 1.0F).texOffs(462, 214).addBox(115.0F, -9.0F, -8.0F, 24.0F, 6.0F, 1.0F).texOffs(732, 214).addBox(64.0F, -13.0F, 6.0F, 80.0F, 4.0F, 1.0F).texOffs(0, 225).addBox(64.0F, -13.0F, -7.0F, 80.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(636, 56).addBox(64.0F, -30.0F, -12.5F, 80.0F, 17.0F, 25.0F).texOffs(812, 136).addBox(64.0F, -33.0F, -9.5F, 80.0F, 3.0F, 19.0F).texOffs(24, 169).addBox(66.0F, -35.0F, -9.0F, 34.0F, 2.0F, 18.0F).texOffs(114, 136).addBox(144.0F, -14.0F, -12.0F, 2.0F, 6.0F, 24.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(356, 258).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -30.46352549156242F, -12.42658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(518, 258).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -31.34520337000113F, -12.140110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(680, 258).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -32.09520337000113F, -11.59520337000113F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(842, 258).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -32.64011026600515F, -10.845203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(0, 260).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -32.92658477444273F, -9.963525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(162, 260).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -30.46352549156242F, 12.42658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(324, 260).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -31.34520337000113F, 12.140110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(486, 260).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -32.09520337000113F, 11.59520337000113F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(648, 260).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -32.64011026600515F, 10.845203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(810, 260).addBox(-40.0F, -1.0F, -0.5F, 80.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(104.0F, -32.92658477444273F, 9.963525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(64.0F, -30.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(102, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(143.0F, -30.0F, -12.5F));
        g.addOrReplaceChild("boca_agua_0", CubeListBuilder.create().texOffs(46, 214).addBox(-13.0F, -35.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(238, 136).addBox(-3.5F, -35.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(128.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("boca_agua_1", CubeListBuilder.create().texOffs(112, 214).addBox(-13.0F, -35.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(304, 136).addBox(-3.5F, -35.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(128.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("boca_agua_2", CubeListBuilder.create().texOffs(178, 214).addBox(-13.0F, -35.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(370, 136).addBox(-3.5F, -35.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(128.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(958, 99).addBox(146.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(490, 99).addBox(146.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(978, 99).addBox(146.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(548, 99).addBox(146.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(998, 99).addBox(146.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(606, 99).addBox(146.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(878, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(528, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(884, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(550, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(890, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(572, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(896, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(594, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(0, 136).addBox(146.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(664, 99).addBox(146.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(20, 136).addBox(146.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(722, 99).addBox(146.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(40, 136).addBox(146.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(780, 99).addBox(146.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(902, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(616, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(908, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(638, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(914, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(660, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(920, 202).addBox(149.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(682, 202).addBox(149.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "caja_humo_0", 1.0F, 0.4957224306869052F, 0.4957224306869052F);
        escalar(g0, "caja_humo_1", 1.0F, 0.4957224306869052F, 0.4957224306869052F);
        escalar(g0, "caja_humo_2", 1.0F, 0.4957224306869052F, 0.4957224306869052F);
        escalar(g0, "caja_humo_3", 1.0F, 0.4957224306869052F, 0.4957224306869052F);
        escalar(g0, "caja_humo_4", 1.0F, 0.4957224306869052F, 0.4957224306869052F);
        escalar(g0, "caja_humo_5", 1.0F, 0.4957224306869052F, 0.4957224306869052F);
        escalar(g0, "puerta_0", 1.0F, 0.43832299134421093F, 0.43832299134421093F);
        escalar(g0, "puerta_1", 1.0F, 0.43832299134421093F, 0.43832299134421093F);
        escalar(g0, "puerta_2", 1.0F, 0.43832299134421093F, 0.43832299134421093F);
        escalar(g0, "puerta_3", 1.0F, 0.43832299134421093F, 0.43832299134421093F);
        escalar(g0, "puerta_4", 1.0F, 0.43832299134421093F, 0.43832299134421093F);
        escalar(g0, "puerta_5", 1.0F, 0.43832299134421093F, 0.43832299134421093F);
        escalar(g0, "caldera_0", 0.9750288457271405F, 1.0F, 0.9796891659039438F);
        escalar(g0, "caldera_1", 0.9750288457271405F, 1.0F, 0.9964838373194399F);
        escalar(g0, "caldera_2", 0.9750288457271405F, 1.0F, 0.6755190058232906F);
        escalar(g0, "caldera_3", 0.9750288457271405F, 1.0F, 0.6867154534336214F);
        escalar(g0, "caldera_4", 0.9750288457271405F, 1.0F, 0.9796891659039427F);
        escalar(g0, "caldera_5", 0.9750288457271405F, 1.0F, 0.9964838373194392F);
        escalar(g0, "caldera_6", 0.9750288457271405F, 1.0F, 0.6755190058232907F);
        escalar(g0, "caldera_7", 0.9750288457271405F, 1.0F, 0.6867154534336218F);
        escalar(g0, "caldera_8", 0.9750288457271405F, 1.0F, 0.9796891659039454F);
        escalar(g0, "caldera_9", 0.9750288457271404F, 1.0F, 0.9964838373194405F);
        escalar(g0, "caldera_10", 0.9750288457271404F, 1.0F, 0.6755190058232904F);
        escalar(g0, "caldera_11", 0.9750288457271405F, 1.0F, 0.6867154534336217F);
        escalar(g0, "caldera_12", 0.9750288457271404F, 1.0F, 0.9796891659039422F);
        escalar(g0, "caldera_13", 0.9750288457271404F, 1.0F, 0.9964838373194382F);
        escalar(g0, "caldera_14", 0.9750288457271404F, 1.0F, 0.6755190058232912F);
        escalar(g0, "caldera_15", 0.9750288457271404F, 1.0F, 0.6867154534336218F);
        escalar(g0, "caldera_16", 0.9750288457271404F, 1.0F, 0.9796891659039436F);
        escalar(g0, "caldera_17", 0.9750288457271404F, 1.0F, 0.9964838373194415F);
        escalar(g0, "caldera_18", 0.9750288457271404F, 1.0F, 0.675519005823289F);
        escalar(g0, "caldera_19", 0.9750288457271404F, 1.0F, 0.6867154534336212F);
        escalar(g0, "caldera_20", 0.9750288457271405F, 1.0F, 0.9796891659039456F);
        escalar(g0, "caldera_21", 0.9750288457271405F, 1.0F, 0.9964838373194402F);
        escalar(g0, "caldera_22", 0.9750288457271405F, 1.0F, 0.6755190058232908F);
        escalar(g0, "caldera_23", 0.9750288457271405F, 1.0F, 0.6867154534336207F);
        escalar(g0, "caldera_24", 0.9750288457271405F, 1.0F, 0.9796891659039431F);
        escalar(g0, "caldera_25", 0.9750288457271405F, 1.0F, 0.9964838373194391F);
        escalar(g0, "caldera_26", 0.9750288457271405F, 1.0F, 0.6755190058232913F);
        escalar(g0, "caldera_27", 0.9750288457271405F, 1.0F, 0.6867154534336221F);
        escalar(g0, "caldera_28", 0.9750288457271405F, 1.0F, 0.9796891659039431F);
        escalar(g0, "caldera_29", 0.9750288457271405F, 1.0F, 0.9964838373194391F);
        escalar(g0, "caldera_30", 0.9750288457271405F, 1.0F, 0.6755190058232902F);
        escalar(g0, "caldera_31", 0.9750288457271405F, 1.0F, 0.6867154534336208F);
        escalar(g0, "caldera_32", 0.9750288457271405F, 1.0F, 0.9796891659039436F);
        escalar(g0, "caldera_33", 0.9750288457271405F, 1.0F, 0.99648383731944F);
        escalar(g0, "caldera_34", 0.9750288457271405F, 1.0F, 0.6755190058232907F);
        escalar(g0, "caldera_35", 0.9750288457271405F, 1.0F, 0.6867154534336217F);
        escalar(g0, "caldera_36", 0.9750288457271404F, 1.0F, 0.9796891659039418F);
        escalar(g0, "caldera_37", 0.9750288457271404F, 1.0F, 0.9964838373194382F);
        escalar(g0, "caldera_38", 0.9750288457271404F, 1.0F, 0.6755190058232899F);
        escalar(g0, "caldera_39", 0.9750288457271404F, 1.0F, 0.686715453433621F);
        escalar(g0, "caldera_40", 0.9750288457271404F, 1.0F, 0.9796891659039453F);
        escalar(g0, "caldera_41", 0.9750288457271404F, 1.0F, 0.9964838373194413F);
        escalar(g0, "caldera_42", 0.9750288457271404F, 1.0F, 0.6755190058232916F);
        escalar(g0, "caldera_43", 0.9750288457271404F, 1.0F, 0.6867154534336222F);
        escalar(g0, "caldera_44", 0.9750288457271404F, 1.0F, 0.9796891659039434F);
        escalar(g0, "caldera_45", 0.9750288457271404F, 1.0F, 0.9964838373194395F);
        escalar(g0, "caldera_46", 0.9750288457271404F, 1.0F, 0.6755190058232904F);
        escalar(g0, "caldera_47", 0.9750288457271404F, 1.0F, 0.6867154534336213F);
        escalar(g0, "caldera_48", 0.9750288457271405F, 1.0F, 0.9796891659039421F);
        escalar(g0, "caldera_49", 0.9750288457271405F, 1.0F, 0.9964838373194379F);
        escalar(g0, "caldera_50", 0.9750288457271405F, 1.0F, 0.6755190058232893F);
        escalar(g0, "caldera_51", 0.9750288457271405F, 1.0F, 0.6867154534336201F);
        escalar(g0, "caldera_52", 0.9750288457271405F, 1.0F, 0.9796891659039457F);
        escalar(g0, "caldera_53", 0.9750288457271405F, 1.0F, 0.9964838373194417F);
        escalar(g0, "caldera_54", 0.9750288457271405F, 1.0F, 0.675519005823292F);
        escalar(g0, "caldera_55", 0.9750288457271405F, 1.0F, 0.6867154534336227F);
        escalar(g0, "caldera_56", 0.9750288457271405F, 1.0F, 0.979689165903944F);
        escalar(g0, "caldera_57", 0.9750288457271405F, 1.0F, 0.9964838373194399F);
        escalar(g0, "caldera_58", 0.9750288457271405F, 1.0F, 0.6755190058232906F);
        escalar(g0, "caldera_59", 0.9750288457271405F, 1.0F, 0.6867154534336216F);
        escalar(g0, "caldera_60", 0.9750288457271405F, 1.0F, 0.9796891659039433F);
        escalar(g0, "caldera_61", 0.9750288457271405F, 1.0F, 0.9964838373194393F);
        escalar(g0, "caldera_62", 0.9750288457271405F, 1.0F, 0.6755190058232907F);
        escalar(g0, "caldera_63", 0.9750288457271405F, 1.0F, 0.6867154534336213F);
        escalar(g0, "caldera_64", 0.9750288457271404F, 1.0F, 0.979689165903942F);
        escalar(g0, "caldera_65", 0.9750288457271404F, 1.0F, 0.996483837319438F);
        escalar(g0, "caldera_66", 0.9750288457271404F, 1.0F, 0.6755190058232889F);
        escalar(g0, "caldera_67", 0.9750288457271405F, 1.0F, 0.6867154534336204F);
        escalar(g0, "caldera_68", 0.9750288457271404F, 1.0F, 0.9796891659039447F);
        escalar(g0, "caldera_69", 0.9750288457271404F, 1.0F, 0.9964838373194417F);
        escalar(g0, "caldera_70", 0.9750288457271404F, 1.0F, 0.6755190058232919F);
        escalar(g0, "caldera_71", 0.9750288457271404F, 1.0F, 0.6867154534336225F);
        escalar(g0, "caldera_72", 0.9750288457271404F, 1.0F, 0.9796891659039402F);
        escalar(g0, "caldera_73", 0.9750288457271404F, 1.0F, 0.9964838373194355F);
        escalar(g0, "caldera_74", 0.9750288457271404F, 1.0F, 0.6755190058232879F);
        escalar(g0, "caldera_75", 0.9750288457271404F, 1.0F, 0.686715453433619F);
        escalar(g0, "caldera_76", 0.9750288457271405F, 1.0F, 0.9796891659039441F);
        escalar(g0, "caldera_77", 0.9750288457271405F, 1.0F, 0.9964838373194402F);
        escalar(g0, "caldera_78", 0.9750288457271405F, 1.0F, 0.6755190058232908F);
        escalar(g0, "caldera_79", 0.9750288457271405F, 1.0F, 0.6867154534336217F);
        escalar(g0, "caldera_80", 0.9750288457271405F, 1.0F, 0.9796891659039485F);
        escalar(g0, "caldera_81", 0.9750288457271405F, 1.0F, 0.9964838373194445F);
        escalar(g0, "caldera_82", 0.9750288457271405F, 1.0F, 0.6755190058232937F);
        escalar(g0, "caldera_83", 0.9750288457271405F, 1.0F, 0.6867154534336245F);
        escalar(g0, "caldera_84", 0.9750288457271405F, 1.0F, 0.9796891659039431F);
        escalar(g0, "caldera_85", 0.9750288457271405F, 1.0F, 0.9964838373194391F);
        escalar(g0, "caldera_86", 0.9750288457271405F, 1.0F, 0.6755190058232902F);
        escalar(g0, "caldera_87", 0.9750288457271405F, 1.0F, 0.6867154534336208F);
        escalar(g0, "caldera_88", 0.9750288457271405F, 1.0F, 0.9796891659039452F);
        escalar(g0, "caldera_89", 0.9750288457271405F, 1.0F, 0.99648383731944F);
        escalar(g0, "caldera_90", 0.9750288457271405F, 1.0F, 0.6755190058232894F);
        escalar(g0, "caldera_91", 0.9750288457271405F, 1.0F, 0.6867154534336214F);
        escalar(g0, "caldera_92", 0.9750288457271404F, 1.0F, 0.9796891659039442F);
        escalar(g0, "caldera_93", 0.9750288457271404F, 1.0F, 0.9964838373194388F);
        escalar(g0, "caldera_94", 0.9750288457271405F, 1.0F, 0.6755190058232916F);
        escalar(g0, "caldera_95", 0.9750288457271404F, 1.0F, 0.6867154534336216F);
        escalar(g0, "caldera_96", 0.9750288457271404F, 1.0F, 0.9796891659039418F);
        escalar(g0, "caldera_97", 0.9750288457271404F, 1.0F, 0.9964838373194405F);
        escalar(g0, "caldera_98", 0.9750288457271404F, 1.0F, 0.675519005823291F);
        escalar(g0, "caldera_99", 0.9750288457271404F, 1.0F, 0.6867154534336214F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "caldera_100", 0.9750288457271405F, 1.0F, 0.9796891659039404F);
        escalar(g0, "caldera_101", 0.9750288457271404F, 1.0F, 0.9964838373194356F);
        escalar(g0, "caldera_102", 0.9750288457271405F, 1.0F, 0.6755190058232884F);
        escalar(g0, "caldera_103", 0.9750288457271404F, 1.0F, 0.6867154534336186F);
        escalar(g0, "caldera_104", 0.9750288457271405F, 1.0F, 0.9796891659039435F);
        escalar(g0, "caldera_105", 0.9750288457271405F, 1.0F, 0.9964838373194399F);
        escalar(g0, "caldera_106", 0.9750288457271405F, 1.0F, 0.6755190058232903F);
        escalar(g0, "caldera_107", 0.9750288457271405F, 1.0F, 0.6867154534336214F);
        escalar(g0, "caldera_108", 0.9750288457271405F, 1.0F, 0.9796891659039476F);
        escalar(g0, "caldera_109", 0.9750288457271405F, 1.0F, 0.9964838373194436F);
        escalar(g0, "caldera_110", 0.9750288457271405F, 1.0F, 0.6755190058232933F);
        escalar(g0, "caldera_111", 0.9750288457271405F, 1.0F, 0.6867154534336244F);
        escalar(g0, "chimenea_0", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_1", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_2", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_3", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_labio_0", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g0, "chimenea_labio_1", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g0, "chimenea_labio_2", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g0, "chimenea_labio_3", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g0, "domo_arena_0", 0.4300823172919138F, 1.0F, 0.4548214943191063F);
        escalar(g0, "domo_arena_1", 0.41760699697957643F, 1.0F, 0.4301268116601446F);
        escalar(g0, "domo_arena_2", 0.37338891958475734F, 1.0F, 0.3813302477513303F);
        escalar(g0, "domo_arena_3", 0.3628802906078712F, 1.0F, 0.46398545224678134F);
        escalar(g0, "domo_arena_4", 0.3881855619923081F, 1.0F, 0.32130073948296634F);
        escalar(g0, "domo_arena_5", 0.3921947284349721F, 1.0F, 0.2511516803787642F);
        escalar(g0, "domo_arena_6", 0.4301083994747364F, 1.0F, 0.4335210580576002F);
        escalar(g0, "domo_arena_7", 0.41803115404729413F, 1.0F, 0.4101837703998821F);
        escalar(g0, "domo_arena_8", 0.3746677894013309F, 1.0F, 0.3640694119213791F);
        escalar(g0, "domo_arena_9", 0.3653696050840614F, 1.0F, 0.2960207934320253F);
        escalar(g0, "domo_arena_10", 0.3920026518428263F, 1.0F, 0.41225258898601846F);
        escalar(g0, "domo_arena_11", 0.43007729494507585F, 1.0F, 0.4044453758789376F);
        escalar(g0, "domo_arena_12", 0.41752516369303727F, 1.0F, 0.3827102460028414F);
        escalar(g0, "domo_arena_13", 0.37314097428477117F, 1.0F, 0.33976174292983646F);
        escalar(g0, "domo_arena_14", 0.36239428308829935F, 1.0F, 0.276384816594275F);
        escalar(g0, "domo_arena_15", 0.38743582060258114F, 1.0F, 0.3853235581996346F);
        escalar(g0, "domo_arena_16", 0.4299807619068917F, 1.0F, 0.4381587466055038F);
        escalar(g0, "domo_arena_17", 0.41595116788211106F, 1.0F, 0.4145659083213168F);
        escalar(g0, "domo_arena_18", 0.3683629398911991F, 1.0F, 0.3679465831401175F);
        escalar(g0, "domo_arena_19", 0.35300058891667163F, 1.0F, 0.29915281091480556F);
        escalar(g0, "domo_arena_20", 0.37290275238184156F, 1.0F, 0.4165478779810198F);
        escalar(g0, "domo_arena_21", 0.4298353698743429F, 1.0F, 0.3530070218498281F);
        escalar(g0, "domo_arena_22", 0.4135702666160756F, 1.0F, 0.5008839355514942F);
        escalar(g0, "domo_arena_23", 0.36105279233709203F, 1.0F, 0.44431792900720035F);
        escalar(g0, "domo_arena_24", 0.5075622099700196F, 1.0F, 0.36084634389139925F);
        escalar(g0, "domo_arena_25", 0.3498980089502243F, 1.0F, 0.5011551813291033F);
        escalar(g0, "domo_arena_26", 0.4296856735561292F, 1.0F, 0.4362901552936511F);
        escalar(g0, "domo_arena_27", 0.41110657072014795F, 1.0F, 0.4125247669462765F);
        escalar(g0, "domo_arena_28", 0.3533849835386636F, 1.0F, 0.48741931165568236F);
        escalar(g0, "domo_arena_29", 0.4840360684206563F, 1.0F, 0.3950234360868842F);
        escalar(g0, "domo_arena_30", 0.48700653858777254F, 1.0F, 0.4094480954359261F);
        escalar(g0, "domo_arena_31", 0.4238938948821334F, 1.0F, 0.31660417330670504F);
        escalar(g0, "domo_arena_32", 0.4296856735561292F, 1.0F, 0.4362901553035724F);
        escalar(g0, "domo_arena_33", 0.41110657072014795F, 1.0F, 0.4125247669556506F);
        escalar(g0, "domo_arena_34", 0.35338498353866354F, 1.0F, 0.48741931166674096F);
        escalar(g0, "domo_arena_35", 0.4840360684206563F, 1.0F, 0.3950234360958178F);
        escalar(g0, "domo_arena_36", 0.4870065385877727F, 1.0F, 0.4094480954451148F);
        escalar(g0, "domo_arena_37", 0.4238938948821332F, 1.0F, 0.3166041733135291F);
        escalar(g0, "domo_arena_38", 0.4298353698743429F, 1.0F, 0.35300702184982896F);
        escalar(g0, "domo_arena_39", 0.4135702666160756F, 1.0F, 0.5008839355514956F);
        escalar(g0, "domo_arena_40", 0.36105279233709187F, 1.0F, 0.4443179290072004F);
        escalar(g0, "domo_arena_41", 0.5075622099700197F, 1.0F, 0.3608463438913984F);
        escalar(g0, "domo_arena_42", 0.3498980089502244F, 1.0F, 0.5011551813291025F);
        escalar(g0, "domo_arena_43", 0.4299807619068917F, 1.0F, 0.4381587466055034F);
        escalar(g0, "domo_arena_44", 0.4159511678821111F, 1.0F, 0.4145659083213172F);
        escalar(g0, "domo_arena_45", 0.3683629398911991F, 1.0F, 0.36794658314011836F);
        escalar(g0, "domo_arena_46", 0.3530005889166717F, 1.0F, 0.2991528109148064F);
        escalar(g0, "domo_arena_47", 0.37290275238184156F, 1.0F, 0.41654787798102133F);
        escalar(g0, "domo_arena_48", 0.43007729494507585F, 1.0F, 0.4044453758789376F);
        escalar(g0, "domo_arena_49", 0.41752516369303727F, 1.0F, 0.38271024600284115F);
        escalar(g0, "domo_arena_50", 0.37314097428477105F, 1.0F, 0.33976174292983663F);
        escalar(g0, "domo_arena_51", 0.3623942830882996F, 1.0F, 0.27638481659427516F);
        escalar(g0, "domo_arena_52", 0.38743582060258114F, 1.0F, 0.3853235581996344F);
        escalar(g0, "domo_arena_53", 0.4301083994747364F, 1.0F, 0.4335210580576004F);
        escalar(g0, "domo_arena_54", 0.41803115404729424F, 1.0F, 0.41018377039988196F);
        escalar(g0, "domo_arena_55", 0.3746677894013306F, 1.0F, 0.36406941192137876F);
        escalar(g0, "domo_arena_56", 0.36536960508406163F, 1.0F, 0.29602079343202525F);
        escalar(g0, "domo_arena_57", 0.3920026518428264F, 1.0F, 0.4122525889860185F);
        escalar(g0, "domo_arena_58", 0.4300823172919138F, 1.0F, 0.45482149431076585F);
        escalar(g0, "domo_arena_59", 0.41760699697957665F, 1.0F, 0.4301268116522638F);
        escalar(g0, "domo_arena_60", 0.37338891958475706F, 1.0F, 0.3813302477443575F);
        escalar(g0, "domo_arena_61", 0.36288029060787147F, 1.0F, 0.4639854522383322F);
        escalar(g0, "domo_arena_62", 0.3881855619923076F, 1.0F, 0.3213007394771728F);
        escalar(g0, "domo_arena_63", 0.3921947284349723F, 1.0F, 0.2511516803744625F);
        escalar(g0, "domo_arena_64", 0.4300823172919138F, 1.0F, 0.4548214943274466F);
        escalar(g0, "domo_arena_65", 0.41760699697957665F, 1.0F, 0.4301268116680254F);
        escalar(g0, "domo_arena_66", 0.37338891958475706F, 1.0F, 0.38133024775830293F);
        escalar(g0, "domo_arena_67", 0.3628802906078714F, 1.0F, 0.4639854522552301F);
        escalar(g0, "domo_arena_68", 0.3881855619923075F, 1.0F, 0.3213007394887597F);
        escalar(g0, "domo_arena_69", 0.3921947284349723F, 1.0F, 0.2511516803830662F);
        escalar(g0, "domo_arena_70", 0.4301083994747364F, 1.0F, 0.4335210580576002F);
        escalar(g0, "domo_arena_71", 0.41803115404729424F, 1.0F, 0.41018377039988174F);
        escalar(g0, "domo_arena_72", 0.3746677894013306F, 1.0F, 0.36406941192137854F);
        escalar(g0, "domo_arena_73", 0.3653696050840615F, 1.0F, 0.29602079343202503F);
        escalar(g0, "domo_arena_74", 0.3920026518428263F, 1.0F, 0.41225258898601824F);
        escalar(g0, "domo_arena_75", 0.43007729494507585F, 1.0F, 0.4044453758789379F);
        escalar(g0, "domo_arena_76", 0.41752516369303727F, 1.0F, 0.3827102460028421F);
        escalar(g0, "domo_arena_77", 0.37314097428477105F, 1.0F, 0.3397617429298374F);
        escalar(g0, "domo_arena_78", 0.3623942830882995F, 1.0F, 0.2763848165942758F);
        escalar(g0, "domo_arena_79", 0.38743582060258114F, 1.0F, 0.38532355819963526F);
        escalar(g0, "domo_arena_80", 0.4299807619068917F, 1.0F, 0.4381587466055041F);
        escalar(g0, "domo_arena_81", 0.415951167882111F, 1.0F, 0.41456590832131635F);
        escalar(g0, "domo_arena_82", 0.3683629398911991F, 1.0F, 0.36794658314011675F);
        escalar(g0, "domo_arena_83", 0.35300058891667163F, 1.0F, 0.2991528109148047F);
        escalar(g0, "domo_arena_84", 0.37290275238184156F, 1.0F, 0.41654787798101817F);
        escalar(g0, "domo_arena_85", 0.42983536987434284F, 1.0F, 0.3530070218498273F);
        escalar(g0, "domo_arena_86", 0.4135702666160756F, 1.0F, 0.5008839355514938F);
        escalar(g0, "domo_arena_87", 0.36105279233709187F, 1.0F, 0.44431792900720035F);
        escalar(g0, "domo_arena_88", 0.5075622099700197F, 1.0F, 0.3608463438913984F);
        escalar(g0, "domo_arena_89", 0.3498980089502244F, 1.0F, 0.5011551813291024F);
        escalar(g0, "domo_arena_90", 0.4296856735561292F, 1.0F, 0.43629015528790877F);
        escalar(g0, "domo_arena_91", 0.41110657072014795F, 1.0F, 0.4125247669408504F);
        escalar(g0, "domo_arena_92", 0.3533849835386635F, 1.0F, 0.4874193116492809F);
        escalar(g0, "domo_arena_93", 0.4840360684206563F, 1.0F, 0.39502343608171353F);
        escalar(g0, "domo_arena_94", 0.4870065385877727F, 1.0F, 0.409448095430608F);
        escalar(g0, "domo_arena_95", 0.4238938948821334F, 1.0F, 0.3166041733027572F);
        escalar(g0, "domo_arena_96", 0.4296856735561292F, 1.0F, 0.43629015530931536F);
        escalar(g0, "domo_arena_97", 0.41110657072014795F, 1.0F, 0.4125247669610773F);
        escalar(g0, "domo_arena_98", 0.35338498353866354F, 1.0F, 0.48741931167314273F);
        escalar(g0, "domo_arena_99", 0.4840360684206563F, 1.0F, 0.39502343610098906F);
        escalar(g0, "domo_arena_100", 0.48700653858777254F, 1.0F, 0.40944809545043376F);
        escalar(g0, "domo_arena_101", 0.42389389488213336F, 1.0F, 0.3166041733174778F);
        escalar(g0, "domo_arena_102", 0.42983536987434284F, 1.0F, 0.3530070218498278F);
        escalar(g0, "domo_arena_103", 0.4135702666160756F, 1.0F, 0.5008839355514942F);
        escalar(g0, "domo_arena_104", 0.36105279233709203F, 1.0F, 0.4443179290072008F);
        escalar(g0, "domo_arena_105", 0.5075622099700197F, 1.0F, 0.36084634389139925F);
        escalar(g0, "domo_arena_106", 0.34989800895022416F, 1.0F, 0.5011551813291041F);
        escalar(g0, "domo_arena_107", 0.4299807619068917F, 1.0F, 0.438158746605505F);
        escalar(g0, "domo_arena_108", 0.41595116788211106F, 1.0F, 0.414565908321318F);
        escalar(g0, "domo_arena_109", 0.36836293989119917F, 1.0F, 0.3679465831401184F);
        escalar(g0, "domo_arena_110", 0.35300058891667185F, 1.0F, 0.29915281091480606F);
        escalar(g0, "domo_arena_111", 0.3729027523818412F, 1.0F, 0.4165478779810199F);
        escalar(g0, "domo_arena_112", 0.43007729494507585F, 1.0F, 0.4044453758789375F);
        escalar(g0, "domo_arena_113", 0.41752516369303727F, 1.0F, 0.3827102460028413F);
        escalar(g0, "domo_arena_114", 0.37314097428477117F, 1.0F, 0.3397617429298364F);
        escalar(g0, "domo_arena_115", 0.3623942830882996F, 1.0F, 0.27638481659427516F);
        escalar(g0, "domo_arena_116", 0.38743582060258097F, 1.0F, 0.38532355819963504F);
        escalar(g0, "domo_arena_117", 0.43010839947473634F, 1.0F, 0.43352105805759955F);
        escalar(g0, "domo_arena_118", 0.41803115404729424F, 1.0F, 0.4101837703998812F);
        escalar(g0, "domo_arena_119", 0.3746677894013308F, 1.0F, 0.3640694119213782F);
        escalar(g0, "domo_arena_120", 0.3653696050840614F, 1.0F, 0.2960207934320248F);
        escalar(g0, "domo_arena_121", 0.3920026518428264F, 1.0F, 0.4122525889860177F);
        escalar(g0, "domo_arena_122", 0.4300823172919138F, 1.0F, 0.45482149430555757F);
        escalar(g0, "domo_arena_123", 0.41760699697957654F, 1.0F, 0.43012681164734246F);
        escalar(g0, "domo_arena_124", 0.37338891958475723F, 1.0F, 0.38133024774000335F);
        escalar(g0, "domo_arena_125", 0.3628802906078712F, 1.0F, 0.4639854522330563F);
        escalar(g0, "domo_arena_126", 0.3881855619923081F, 1.0F, 0.32130073947355503F);
        escalar(g0, "domo_arena_127", 0.39219472843497216F, 1.0F, 0.25115168037177593F);
        escalar(g0, "domo_vapor_0", 0.47237319647786974F, 1.0F, 0.4548214943191063F);
        escalar(g0, "domo_vapor_1", 0.4551531082454569F, 1.0F, 0.4301268116601446F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "domo_vapor_2", 0.39925995304450385F, 1.0F, 0.3813302477513303F);
        escalar(g0, "domo_vapor_3", 0.37717440570364874F, 1.0F, 0.46398545224678134F);
        escalar(g0, "domo_vapor_4", 0.3932115458811322F, 1.0F, 0.32130073948296634F);
        escalar(g0, "domo_vapor_5", 0.39251166871605825F, 1.0F, 0.25115168037876423F);
        escalar(g0, "domo_vapor_6", 0.4723969185962882F, 1.0F, 0.4335210580576002F);
        escalar(g0, "domo_vapor_7", 0.45554176014608494F, 1.0F, 0.41018377039988196F);
        escalar(g0, "domo_vapor_8", 0.40045458225924446F, 1.0F, 0.3640694119213791F);
        escalar(g0, "domo_vapor_9", 0.37956776365472145F, 1.0F, 0.2960207934320253F);
        escalar(g0, "domo_vapor_10", 0.39697906640561853F, 1.0F, 0.4122525889860185F);
        escalar(g0, "domo_vapor_11", 0.472368628678104F, 1.0F, 0.4044453758789376F);
        escalar(g0, "domo_vapor_12", 0.45507814977494504F, 1.0F, 0.38271024600284154F);
        escalar(g0, "domo_vapor_13", 0.39902854537260096F, 1.0F, 0.33976174292983646F);
        escalar(g0, "domo_vapor_14", 0.3767076252053459F, 1.0F, 0.27638481659427516F);
        escalar(g0, "domo_vapor_15", 0.39247192245341084F, 1.0F, 0.3853235581996345F);
        escalar(g0, "domo_vapor_16", 0.4722808330138556F, 1.0F, 0.4381587466055038F);
        escalar(g0, "domo_vapor_17", 0.4536365602674672F, 1.0F, 0.4145659083213168F);
        escalar(g0, "domo_vapor_18", 0.3945707789707413F, 1.0F, 0.3679465831401175F);
        escalar(g0, "domo_vapor_19", 0.36768984656957154F, 1.0F, 0.2991528109148054F);
        escalar(g0, "domo_vapor_20", 0.3781386877281427F, 1.0F, 0.41654787798101955F);
        escalar(g0, "domo_vapor_21", 0.47214860682455007F, 1.0F, 0.3530070218498281F);
        escalar(g0, "domo_vapor_22", 0.451457562029087F, 1.0F, 0.5008839355514942F);
        escalar(g0, "domo_vapor_23", 0.38776500221021243F, 1.0F, 0.44431792900720035F);
        escalar(g0, "domo_vapor_24", 0.35368793526090525F, 1.0F, 0.3608463438913988F);
        escalar(g0, "domo_vapor_25", 0.3554836762119203F, 1.0F, 0.5011551813291033F);
        escalar(g0, "domo_vapor_26", 0.47201247342437885F, 1.0F, 0.4362901552936512F);
        escalar(g0, "domo_vapor_27", 0.4492047462523845F, 1.0F, 0.41252476694627643F);
        escalar(g0, "domo_vapor_28", 0.3806445181397237F, 1.0F, 0.48741931165568214F);
        escalar(g0, "domo_vapor_29", 0.5080896110250203F, 1.0F, 0.3950234360868842F);
        escalar(g0, "domo_vapor_30", 0.4960369677185125F, 1.0F, 0.40944809543592625F);
        escalar(g0, "domo_vapor_31", 0.42441768888807996F, 1.0F, 0.31660417330670554F);
        escalar(g0, "domo_vapor_32", 0.47201247342437885F, 1.0F, 0.4362901553035723F);
        escalar(g0, "domo_vapor_33", 0.44920474625238443F, 1.0F, 0.4125247669556508F);
        escalar(g0, "domo_vapor_34", 0.3806445181397237F, 1.0F, 0.4874193116667411F);
        escalar(g0, "domo_vapor_35", 0.5080896110250203F, 1.0F, 0.39502343609581764F);
        escalar(g0, "domo_vapor_36", 0.49603696771851247F, 1.0F, 0.4094480954451146F);
        escalar(g0, "domo_vapor_37", 0.42441768888807996F, 1.0F, 0.316604173313528F);
        escalar(g0, "domo_vapor_38", 0.47214860682455007F, 1.0F, 0.35300702184982863F);
        escalar(g0, "domo_vapor_39", 0.4514575620290869F, 1.0F, 0.500883935551495F);
        escalar(g0, "domo_vapor_40", 0.38776500221021254F, 1.0F, 0.4443179290072009F);
        escalar(g0, "domo_vapor_41", 0.3536879352609052F, 1.0F, 0.36084634389139925F);
        escalar(g0, "domo_vapor_42", 0.35548367621192023F, 1.0F, 0.5011551813291042F);
        escalar(g0, "domo_vapor_43", 0.4722808330138556F, 1.0F, 0.43815874660550413F);
        escalar(g0, "domo_vapor_44", 0.4536365602674672F, 1.0F, 0.414565908321317F);
        escalar(g0, "domo_vapor_45", 0.3945707789707413F, 1.0F, 0.36794658314011797F);
        escalar(g0, "domo_vapor_46", 0.36768984656957165F, 1.0F, 0.2991528109148057F);
        escalar(g0, "domo_vapor_47", 0.3781386877281426F, 1.0F, 0.41654787798101967F);
        escalar(g0, "domo_vapor_48", 0.472368628678104F, 1.0F, 0.4044453758789373F);
        escalar(g0, "domo_vapor_49", 0.45507814977494504F, 1.0F, 0.3827102460028413F);
        escalar(g0, "domo_vapor_50", 0.39902854537260085F, 1.0F, 0.3397617429298363F);
        escalar(g0, "domo_vapor_51", 0.37670762520534606F, 1.0F, 0.276384816594275F);
        escalar(g0, "domo_vapor_52", 0.39247192245341084F, 1.0F, 0.38532355819963426F);
        escalar(g0, "domo_vapor_53", 0.4723969185962882F, 1.0F, 0.43352105805760033F);
        escalar(g0, "domo_vapor_54", 0.455541760146085F, 1.0F, 0.4101837703998821F);
        escalar(g0, "domo_vapor_55", 0.4004545822592444F, 1.0F, 0.364069411921379F);
        escalar(g0, "domo_vapor_56", 0.3795677636547215F, 1.0F, 0.2960207934320253F);
        escalar(g0, "domo_vapor_57", 0.3969790664056185F, 1.0F, 0.4122525889860187F);
        escalar(g0, "domo_vapor_58", 0.47237319647786974F, 1.0F, 0.45482149431076585F);
        escalar(g0, "domo_vapor_59", 0.45515310824545696F, 1.0F, 0.4301268116522637F);
        escalar(g0, "domo_vapor_60", 0.39925995304450385F, 1.0F, 0.3813302477443575F);
        escalar(g0, "domo_vapor_61", 0.37717440570364874F, 1.0F, 0.4639854522383323F);
        escalar(g0, "domo_vapor_62", 0.3932115458811321F, 1.0F, 0.3213007394771728F);
        escalar(g0, "domo_vapor_63", 0.39251166871605836F, 1.0F, 0.25115168037446234F);
        escalar(g0, "domo_vapor_64", 0.47237319647786974F, 1.0F, 0.4548214943274466F);
        escalar(g0, "domo_vapor_65", 0.45515310824545696F, 1.0F, 0.4301268116680254F);
        escalar(g0, "domo_vapor_66", 0.39925995304450385F, 1.0F, 0.38133024775830293F);
        escalar(g0, "domo_vapor_67", 0.3771744057036488F, 1.0F, 0.46398545225523014F);
        escalar(g0, "domo_vapor_68", 0.3932115458811321F, 1.0F, 0.3213007394887597F);
        escalar(g0, "domo_vapor_69", 0.39251166871605836F, 1.0F, 0.251151680383066F);
        escalar(g0, "domo_vapor_70", 0.4723969185962882F, 1.0F, 0.4335210580576001F);
        escalar(g0, "domo_vapor_71", 0.455541760146085F, 1.0F, 0.41018377039988174F);
        escalar(g0, "domo_vapor_72", 0.4004545822592444F, 1.0F, 0.36406941192137876F);
        escalar(g0, "domo_vapor_73", 0.3795677636547215F, 1.0F, 0.2960207934320251F);
        escalar(g0, "domo_vapor_74", 0.3969790664056185F, 1.0F, 0.41225258898601824F);
        escalar(g0, "domo_vapor_75", 0.472368628678104F, 1.0F, 0.4044453758789385F);
        escalar(g0, "domo_vapor_76", 0.45507814977494504F, 1.0F, 0.38271024600284237F);
        escalar(g0, "domo_vapor_77", 0.39902854537260085F, 1.0F, 0.3397617429298372F);
        escalar(g0, "domo_vapor_78", 0.376707625205346F, 1.0F, 0.2763848165942757F);
        escalar(g0, "domo_vapor_79", 0.39247192245341084F, 1.0F, 0.3853235581996354F);
        escalar(g0, "domo_vapor_80", 0.4722808330138556F, 1.0F, 0.4381587466055033F);
        escalar(g0, "domo_vapor_81", 0.4536365602674672F, 1.0F, 0.41456590832131635F);
        escalar(g0, "domo_vapor_82", 0.3945707789707413F, 1.0F, 0.36794658314011747F);
        escalar(g0, "domo_vapor_83", 0.3676898465695717F, 1.0F, 0.2991528109148053F);
        escalar(g0, "domo_vapor_84", 0.3781386877281427F, 1.0F, 0.41654787798101905F);
        escalar(g0, "domo_vapor_85", 0.47214860682455007F, 1.0F, 0.35300702184982774F);
        escalar(g0, "domo_vapor_86", 0.4514575620290869F, 1.0F, 0.5008839355514938F);
        escalar(g0, "domo_vapor_87", 0.38776500221021254F, 1.0F, 0.4443179290071998F);
        escalar(g0, "domo_vapor_88", 0.3536879352609053F, 1.0F, 0.36084634389139836F);
        escalar(g0, "domo_vapor_89", 0.3554836762119204F, 1.0F, 0.501155181329103F);
        escalar(g0, "domo_vapor_90", 0.47201247342437885F, 1.0F, 0.43629015528790877F);
        escalar(g0, "domo_vapor_91", 0.4492047462523845F, 1.0F, 0.41252476694085044F);
        escalar(g0, "domo_vapor_92", 0.3806445181397237F, 1.0F, 0.48741931164928115F);
        escalar(g0, "domo_vapor_93", 0.5080896110250204F, 1.0F, 0.39502343608171336F);
        escalar(g0, "domo_vapor_94", 0.4960369677185126F, 1.0F, 0.40944809543060756F);
        escalar(g0, "domo_vapor_95", 0.42441768888808F, 1.0F, 0.3166041733027561F);
        escalar(g0, "domo_vapor_96", 0.47201247342437885F, 1.0F, 0.4362901553093152F);
        escalar(g0, "domo_vapor_97", 0.44920474625238443F, 1.0F, 0.41252476696107726F);
        escalar(g0, "domo_vapor_98", 0.3806445181397238F, 1.0F, 0.4874193116731426F);
        escalar(g0, "domo_vapor_99", 0.5080896110250203F, 1.0F, 0.39502343610098894F);
        escalar(g0, "domo_vapor_100", 0.49603696771851247F, 1.0F, 0.4094480954504336F);
        escalar(g0, "domo_vapor_101", 0.42441768888807996F, 1.0F, 0.31660417331747764F);
        escalar(g0, "domo_vapor_102", 0.47214860682455F, 1.0F, 0.353007021849828F);
        escalar(g0, "domo_vapor_103", 0.4514575620290868F, 1.0F, 0.5008839355514946F);
        escalar(g0, "domo_vapor_104", 0.38776500221021254F, 1.0F, 0.4443179290072008F);
        escalar(g0, "domo_vapor_105", 0.3536879352609053F, 1.0F, 0.36084634389139914F);
        escalar(g0, "domo_vapor_106", 0.35548367621192023F, 1.0F, 0.5011551813291037F);
        escalar(g0, "domo_vapor_107", 0.4722808330138556F, 1.0F, 0.438158746605505F);
        escalar(g0, "domo_vapor_108", 0.4536365602674672F, 1.0F, 0.41456590832131784F);
        escalar(g0, "domo_vapor_109", 0.39457077897074133F, 1.0F, 0.3679465831401184F);
        escalar(g0, "domo_vapor_110", 0.3676898465695717F, 1.0F, 0.29915281091480606F);
        escalar(g0, "domo_vapor_111", 0.3781386877281425F, 1.0F, 0.4165478779810202F);
        escalar(g0, "domo_vapor_112", 0.472368628678104F, 1.0F, 0.40444537587893736F);
        escalar(g0, "domo_vapor_113", 0.45507814977494504F, 1.0F, 0.3827102460028412F);
        escalar(g0, "domo_vapor_114", 0.39902854537260085F, 1.0F, 0.33976174292983624F);
        escalar(g0, "domo_vapor_115", 0.3767076252053461F, 1.0F, 0.27638481659427505F);
        escalar(g0, "domo_vapor_116", 0.3924719224534107F, 1.0F, 0.3853235581996343F);
        escalar(g0, "domo_vapor_117", 0.4723969185962882F, 1.0F, 0.43352105805759955F);
        escalar(g0, "domo_vapor_118", 0.455541760146085F, 1.0F, 0.4101837703998813F);
        escalar(g0, "domo_vapor_119", 0.4004545822592444F, 1.0F, 0.36406941192137826F);
        escalar(g0, "domo_vapor_120", 0.3795677636547215F, 1.0F, 0.2960207934320248F);
        escalar(g0, "domo_vapor_121", 0.39697906640561853F, 1.0F, 0.412252588986018F);
        escalar(g0, "domo_vapor_122", 0.47237319647786974F, 1.0F, 0.45482149430555757F);
        escalar(g0, "domo_vapor_123", 0.45515310824545696F, 1.0F, 0.43012681164734246F);
        escalar(g0, "domo_vapor_124", 0.39925995304450385F, 1.0F, 0.38133024774000335F);
        escalar(g0, "domo_vapor_125", 0.37717440570364863F, 1.0F, 0.4639854522330563F);
        escalar(g0, "domo_vapor_126", 0.3932115458811323F, 1.0F, 0.32130073947355503F);
        escalar(g0, "domo_vapor_127", 0.39251166871605825F, 1.0F, 0.251151680371776F);
        escalar(g0, "valvulas_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "valvulas_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "deflectori", 0.5F, 0.5F, 1.0F);
        escalar(g0, "deflectord", 0.5F, 0.5F, 1.0F);
        escalar(g0, "faro1_0", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro1_1", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro1_2", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro1_3", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro1_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "faro18_0", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro18_1", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro18_2", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro18_3", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro18_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "faro10_0", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro10_1", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro10_2", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro10_3", 0.2550041729048399F, 0.8999999999999999F, 0.2550041729048399F);
        escalar(g0, "faro10_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "cabina_techo_0", 1.0008695652173913F, 1.0F, 0.7284756790091776F);
        escalar(g0, "cabina_techo_1", 1.0008695652173913F, 1.0F, 0.728475679009179F);
        escalar(g0, "cabina_techo_2", 1.0008695652173913F, 1.0F, 0.7284756790091791F);
        escalar(g0, "cabina_techo_3", 1.0008695652173913F, 1.0F, 0.7284756790091782F);
        escalar(g0, "cabina_techo_4", 1.0008695652173913F, 1.0F, 0.7284756790091779F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1) {
        escalar(g0, "cabina_techo_5", 1.0008695652173913F, 1.0F, 0.7284756790091788F);
        escalar(g0, "cabina_techo_6", 1.0008695652173913F, 1.0F, 0.7284756790091778F);
        escalar(g0, "cabina_techo_7", 1.0008695652173913F, 1.0F, 0.7284756790091783F);
        escalar(g0, "cabina_techo_8", 1.0008695652173913F, 1.0F, 0.7284756790091788F);
        escalar(g0, "cabina_techo_9", 1.0008695652173913F, 1.0F, 0.7284756790091779F);
        escalar(g0, "cabina_techo_10", 1.0008695652173913F, 1.0F, 0.7284756790091795F);
        escalar(g0, "cabina_techo_11", 1.0008695652173913F, 1.0F, 0.7284756790091781F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "boca_agua_0", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g1, "boca_agua_1", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g1, "boca_agua_2", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g1, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
